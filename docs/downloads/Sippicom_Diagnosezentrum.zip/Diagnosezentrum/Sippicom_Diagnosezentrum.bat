@echo off
REM Copyright (c) 2026 Nick Truschin. Alle Rechte vorbehalten.
REM Die bat selbst fragt NICHT nach Administratorrechten (keine UAC-Abfrage nach dem Doppelklick).
REM Ablauf: 1) Doppelklick auf die bat (Parameter first): Desktop-Verknuepfung anlegen und die Verknuepfung
REM            sofort starten. Die Verknuepfung traegt "Als Administrator ausfuehren", das Programm laeuft
REM            damit mit Administratorrechten (die UAC-Abfrage kommt von der Verknuepfung).
REM         2) Start ueber die Verknuepfung (Parameter run): Programm starten, auf das Ende warten und
REM            danach die Desktop-Verknuepfung wieder loeschen.
REM         Ist die Verknuepfung nicht vorhanden oder nicht startbar, startet die bat das Programm direkt.
REM Die Dateien Sippicom_Diagnosezentrum.ps1, Sippicom_Verknuepfung.ps1 und der Ordner assets
REM muessen im selben Ordner wie diese Datei liegen. Protokoll: C:\SippicomInstall\start.log
set "SIPBAT=%~f0"
set "SIPARG=%~1"
if "%SIPARG%"=="" set "SIPARG=first"
if not exist "C:\SippicomInstall" mkdir "C:\SippicomInstall" >nul 2>&1
fltmc >nul 2>&1
if errorlevel 1 (
    echo %date% %time% Start ohne Administratorrechte ^(Parameter %SIPARG%^) >> "C:\SippicomInstall\start.log"
) else (
    echo %date% %time% Start mit Administratorrechten ^(Parameter %SIPARG%^) >> "C:\SippicomInstall\start.log"
)
if /i "%SIPARG%"=="run" goto :programm

REM --- Doppelklick: Verknuepfung anlegen und starten ---
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Sippicom_Verknuepfung.ps1" -Bat "%~f0"
echo %date% %time% Verknuepfung angelegt ^(Code %errorlevel%^) >> "C:\SippicomInstall\start.log"
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "$l = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Sippicom Diagnosezentrum.lnk'; if (Test-Path $l) { Start-Process -FilePath $l; exit 0 } else { exit 1 }"
if errorlevel 1 goto :programm
echo %date% %time% Verknuepfung gestartet ^(Administrator^) >> "C:\SippicomInstall\start.log"
exit

:programm
cd /d "%~dp0"
echo %date% %time% starte Diagnosezentrum >> "C:\SippicomInstall\start.log"
start "Sippicom Diagnosezentrum" /wait /min conhost.exe powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File "%~dp0Sippicom_Diagnosezentrum.ps1"
echo %date% %time% Programm beendet, entferne Desktop-Verknuepfung >> "C:\SippicomInstall\start.log"
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Sippicom_Verknuepfung.ps1" -Remove
echo %date% %time% Verknuepfung entfernt ^(Code %errorlevel%^) >> "C:\SippicomInstall\start.log"
exit

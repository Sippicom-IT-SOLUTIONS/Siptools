@echo off
REM Copyright (c) 2026 Nick Truschin. Alle Rechte vorbehalten.
REM Startet das Diagnosezentrum: Die Konsole oeffnet minimiert in der Taskleiste
REM (ueber conhost, damit auch Windows Terminal sie nicht in den Vordergrund holt)
REM und schliesst sich automatisch, sobald das Programm beendet wird.
start "Sippicom Diagnosezentrum" /min conhost.exe powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File "%~dp0Sippicom_Diagnosezentrum.ps1"
exit

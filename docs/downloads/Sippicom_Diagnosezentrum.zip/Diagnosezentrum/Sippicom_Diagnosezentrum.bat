@echo off
REM Copyright (c) 2026 Nick Truschin. Alle Rechte vorbehalten.
REM Startet das Diagnosezentrum immer mit Administratorrechten (UAC-Abfrage, falls noetig).
REM Ablauf: 1) Ohne Adminrechte startet sich die bat selbst neu als Administrator.
REM         2) Mit Adminrechten wird (ausser beim Start ueber die Verknuepfung, Parameter run)
REM            die Desktop-Verknuepfung angelegt und danach SOFORT das Programm als Administrator gestartet.
REM Die Dateien Sippicom_Diagnosezentrum.ps1, Sippicom_Verknuepfung.ps1 und der Ordner assets
REM muessen im selben Ordner wie diese Datei liegen. Protokoll: C:\SippicomInstall\start.log
set "SIPBAT=%~f0"
set "SIPARG=%~1"
if "%SIPARG%"=="" set "SIPARG=first"
if not exist "C:\SippicomInstall" mkdir "C:\SippicomInstall" >nul 2>&1
fltmc >nul 2>&1
if errorlevel 1 (
    echo %date% %time% kein Admin, starte neu als Administrator ^(Parameter %SIPARG%^) >> "C:\SippicomInstall\start.log"
    powershell -NoProfile -WindowStyle Hidden -Command "Start-Process -FilePath $env:SIPBAT -ArgumentList $env:SIPARG -Verb RunAs"
    exit
)
echo %date% %time% Admin ok ^(Parameter %SIPARG%^) >> "C:\SippicomInstall\start.log"
if /i not "%SIPARG%"=="run" (
    powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Sippicom_Verknuepfung.ps1" -Bat "%~f0"
    echo %date% %time% Verknuepfung angelegt ^(Code %errorlevel%^) >> "C:\SippicomInstall\start.log"
)
cd /d "%~dp0"
echo %date% %time% starte Diagnosezentrum als Administrator >> "C:\SippicomInstall\start.log"
start "Sippicom Diagnosezentrum" /wait /min conhost.exe powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File "%~dp0Sippicom_Diagnosezentrum.ps1"
echo %date% %time% Programm beendet, entferne Desktop-Verknuepfung >> "C:\SippicomInstall\start.log"
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Sippicom_Verknuepfung.ps1" -Remove
exit

# Gemini-Aufträge (Nano Banana) für das Sippicom Diagnosezentrum

Stand: 05.11.2026. Arbeitsanweisung für Nick: Diese Datei in Gemini hochladen (oder Aufträge einzeln einfügen), die Aufträge **einzeln** abrufen, **ein Bild pro Antwort**. Jedes Ergebnis mit Auftragsnummer an Rolf schicken (z. B. "A3 Sheet Status"). Rolf legt es sofort unter eindeutigem Namen in `Diagnosezentrum/assets/` ab und baut es ein. Das Programm bleibt ohne Bilder voll lauffähig (Zeichnung wie bisher als Rückfall).

## Allgemeine Regeln (gelten für jeden Auftrag)

1. **Kein Text, keine Buchstaben, keine Zahlen, keine Logos** im Bild. Beschriftungen setzt das Programm.
2. Marke: dunkles Anthrazit (#18181A bis #252220), Akzent **Sippicom-Orange #F28C28** (Verlauf bis #FFB05A), Weiß für Highlights. Keine weiteren Buntfarben, außer wo ausdrücklich genannt (Grün #2E9F5B, Rot #E5484D nur für Status).
3. Stil: modern, ruhig, hochwertig, "Tech-Werkzeug": feine Linien, weiches Leuchten, dezente Schärfentiefe. Kein Kitsch, keine Cartoons, keine 3D-Figuren, keine Gesichter, keine Marken oder Produktlogos Dritter.
4. **Freisteller** (Aufträge A3, A4, A6): einfarbig **cremefarbener Hintergrund #F2E9D8**, gleichmäßig, ohne Verlauf, Schatten oder Boden. Das Motiv hat mindestens 8 % Abstand zum Rand. Der Hintergrund ist die Farbe, die das Programm entfernt; darum darf **keine Motivfläche** diese Cremefarbe haben.
5. **Hintergründe** (A1, A2, A5, A7): vollflächig, sehr dunkel und ruhig, in der Mitte kein starkes Motiv (Oberfläche liegt darüber). Keine Rasterlinien, keine Ränder, kein Text.
6. Seitenverhältnis wie angegeben, möglichst hoch aufgelöst. Dateiformat JPG oder PNG ist egal.
7. Für einen einheitlichen Stil **einen Chat** verwenden und das erste gelungene Bild (A1) als Referenz anhängen ("gleicher Stil wie das Referenzbild").

**Stilblock** (an jeden Auftrag anhängen):
> Stil: dunkles Anthrazit (#18181A bis #252220), Akzent leuchtendes Orange (#F28C28, Verlauf bis #FFB05A), feine Linien, weiches Leuchten, modern, hochwertig, ruhig, Software-Oberfläche für IT-Diagnose. Kein Text, keine Buchstaben, keine Zahlen, keine Logos, keine Gesichter, keine Cartoon-Optik.

---

## A1 Seitenleisten-Hintergrund (Hochformat)

Seitenverhältnis **9:16**. Dateiname bei Lieferung: `diag-seitenleiste`.

> Erstelle einen vollflächigen, sehr dunklen Hintergrund für eine schmale Seitenleiste einer Windows-Diagnose-Software. Grundfarbe tiefes Anthrazit (#1B1B1D) mit sehr feinem, kaum sichtbarem Verlauf nach oben (#252220). Unten links ein weicher, großer Schein in Orange (#F28C28), der nach oben sanft ausläuft. Darüber, sehr dezent und nur zu etwa 6 bis 8 Prozent Deckkraft, feine technische Linien wie Leiterbahnen einer Platine und kleine Knotenpunkte, die vom unteren Rand nach oben ausdünnen. Oben und in der Mitte bleibt die Fläche ruhig und dunkel, damit Schaltflächen und Text gut lesbar sind. Keine Motive, kein Text. [Stilblock]

## A2 Hauptfenster-Hintergrund

Seitenverhältnis **16:9**. Dateiname: `diag-hauptfenster`.

> Erstelle einen vollflächigen, sehr ruhigen dunklen Hintergrund für das Hauptfenster einer Diagnose-Software. Grundfarbe Anthrazit (#1A1A1C). Unten rechts ein großer, weicher orangefarbener Schein (#F28C28, geringe Intensität), oben links ein kaum sichtbarer, kühler grauer Lichtschimmer. Dazu feine, kaum sichtbare Wellen- bzw. Konturlinien (wie Höhenlinien oder Signalwellen) zu etwa 5 Prozent Deckkraft, die diagonal von unten rechts nach oben links auslaufen. Die Mitte ist fast einfarbig dunkel, damit weiße Kacheln und Text darauf lesbar bleiben. Keine Motive, kein Text, keine Ränder. [Stilblock]

## A3 Statuskarten-Sheet (Freisteller, 4 Zustände)

Seitenverhältnis **1:1**, Raster 2 x 2, Dateiname: `diag-status-sheet`.

> Erstelle ein Sheet mit **vier** gleich großen Illustrationen in einem 2-mal-2-Raster auf einfarbig cremefarbenem Hintergrund (#F2E9D8, ohne Schatten, ohne Verlauf, ohne Rasterlinien). Jede Illustration steht frei in ihrer Zelle mit mindestens 10 Prozent Abstand zum Zellenrand. Alle im gleichen Stil: moderne, leicht isometrische Icon-Illustration aus dunklem Anthrazit mit leuchtenden orangefarbenen Kanten und weichem Glühen, hochwertig, klar lesbar auch in klein.
> 1) oben links "Bereit": ein stilisierter Bildschirm mit einer Lupe davor, ruhiges orangefarbenes Leuchten.
> 2) oben rechts "Läuft": ein Zahnrad, das von einem kreisförmigen orangefarbenen Scan-Ring umgeben ist, mit einem Lichtstreifen wie bei einem Radar.
> 3) unten links "Alles in Ordnung": ein Schild bzw. Schutzschild mit großem Haken in Grün (#2E9F5B) mit dezentem grünem Leuchten.
> 4) unten rechts "Auffälligkeit": ein Schild mit Warndreieck und Ausrufezeichen-Form (nur als Symbol, ohne Zeichen aus dem Alphabet) in Orange (#F28C28) mit dezentem Leuchten.
> Kein Text, keine Buchstaben, keine Zahlen. Keine Zelle darf die Cremefarbe #F2E9D8 als Motivfarbe enthalten. [Stilblock]

## A4 Kategorie-Icon-Sheet (Freisteller, 12 Icons)

Seitenverhältnis **4:3**, Raster 4 Spalten x 3 Zeilen, Dateiname: `diag-icons-sheet`.

> Erstelle ein Sheet mit **zwölf** gleich großen Icons in einem sauberen Raster mit 4 Spalten und 3 Zeilen auf einfarbig cremefarbenem Hintergrund (#F2E9D8, ohne Schatten). Jedes Icon steht mittig in seiner Zelle und füllt etwa 60 Prozent der Zellenhöhe. Einheitlicher Stil: einfarbige Linien-Icons in leuchtendem Orange (#F28C28) mit gleichmäßiger Strichstärke, abgerundeten Enden und kleinem weißem Glanzpunkt, wie ein modernes Icon-Set einer Windows-11-Anwendung. Reihenfolge von links nach rechts, oben nach unten:
> 1 Laptop, 2 Netzwerk (drei verbundene Knoten), 3 Schreibtisch-Arbeitsplatz mit Monitor, 4 Werkzeugkoffer, 5 Schraubenschlüssel mit Zahnrad (Reparatur), 6 Datensicherung (Pfeil in Festplatte), 7 Windows-Fenster (vier Quadrate), 8 Drucker, 9 Schutzschild mit Schloss, 10 Zertifikat mit Siegel, 11 Uhr, 12 Berichtsblatt mit Diagramm.
> Kein Text, keine Buchstaben, keine Zahlen. Kein Icon darf die Cremefarbe #F2E9D8 als Motivfarbe enthalten. [Stilblock]

## A5 Berichts-Kopfbild für den HTML-Bericht

Seitenverhältnis **16:9** (Rolf schneidet auf ein schmales Banner zu, wichtige Motive daher in der Mitte-Höhe), Dateiname: `diag-bericht-kopf`.

> Erstelle ein breites, dunkles Kopfbild für einen IT-Diagnosebericht. Hintergrund Anthrazit (#1C1B1D) mit orangefarbenem Verlauf (#F28C28 bis #FFB05A, weich) von rechts. In der Mitte auf waagerechter Linie ein abstraktes Netzwerk aus feinen Linien und kleinen Knoten, die sich nach rechts verdichten und leuchten. Links ist die Fläche ruhig und dunkel (dort steht später Text). Oben und unten je ein dünner orangefarbener Lichtstreifen. Kein Text, keine Logos. [Stilblock]

## A6 Leerzustand Protokoll (Freisteller)

Seitenverhältnis **4:3**, Dateiname: `diag-leer`.

> Erstelle eine einzelne Illustration auf einfarbig cremefarbenem Hintergrund (#F2E9D8, ohne Schatten): ein stilisierter Monitor mit einem schlichten Diagramm-Fenster (nur Balken und Linie, ohne Beschriftung), davor eine große Lupe; im Hintergrund kleine, schwebende Kacheln als Symbol für Diagnosen. Dunkles Anthrazit, leuchtende orangefarbene Kanten, weiches Glühen, leicht isometrisch, hochwertig. Das Motiv füllt etwa 70 Prozent der Bildhöhe, mittig. Kein Text, keine Buchstaben, keine Zahlen. [Stilblock]

## A7 Startbild (optional)

Seitenverhältnis **16:9**, Dateiname: `diag-start`.

> Erstelle ein dunkles, stimmungsvolles Startbild: Anthrazit-Hintergrund, in der Bildmitte ein weicher orangefarbener Lichtkern (#F28C28), von dem feine konzentrische Ringe und Signallinien nach außen laufen, wie ein Radar oder eine Schallwelle. Am Rand sehr dunkel. In der Mitte bleibt eine freie Fläche für ein später eingesetztes Logo. Kein Text, keine Logos. [Stilblock]

---

---

# Runde 2 (05.11.2026): Aufträge B1 bis B5

Es gelten dieselben **Allgemeinen Regeln** und derselbe **Stilblock** wie oben (Freisteller auf Creme #F2E9D8, kein Text, Orange #F28C28). Für gleichen Stil im selben Chat bleiben und A4 (Icon-Sheet) als Referenz anhängen ("gleicher Strich, gleiche Farben wie das Referenzbild"). Je Auftrag ein Bild, Ergebnis mit Nummer schicken (z. B. "B1").

## B1 Kachel-Icons Diagnosen (Freisteller, 18 Icons)

Seitenverhältnis **3:2**, Raster 6 Spalten x 3 Zeilen, Dateiname: `diag-kacheln-diagnosen`.

> Erstelle ein Sheet mit **achtzehn** gleich großen Linien-Icons in einem sauberen Raster mit 6 Spalten und 3 Zeilen auf einfarbig cremefarbenem Hintergrund (#F2E9D8, ohne Schatten). Jedes Icon steht mittig in seiner Zelle und füllt etwa 55 Prozent der Zellenhöhe. Stil wie im Referenzbild: einfarbige Linien-Icons in leuchtendem Orange (#F28C28), gleichmäßige Strichstärke, abgerundete Enden, kleiner weißer Glanzpunkt, sehr gut lesbar auch in 18 Pixel Größe, daher wenig Details. Reihenfolge von links nach rechts, oben nach unten:
> 1 Computer mit Prozessor-Chip (System), 2 Arbeitsspeicher-Riegel (Hardware), 3 Schutzschild mit Häkchen (Sicherheit), 4 kreisförmige Pfeile mit Download-Pfeil (Updates), 5 Festplatte mit Pfeil nach oben (Backup), 6 Liste mit Warndreieck (Ereignisse), 7 drei verbundene Knoten (Netzwerk), 8 WLAN-Wellen (WLAN), 9 Schild mit Tunnel/Pfeil (VPN), 10 Zahnrad mit Globus (Proxy), 11 Uhr mit Pfeil (Uhrzeit), 12 Wolke mit Schlüssel (Microsoft 365 / Anmeldung), 13 Briefumschlag (Outlook / Teams), 14 Drucker (Drucker), 15 Siegel mit Band (Zertifikate), 16 Radar mit Wellen (Netz-Tools), 17 Globus mit Lupe (Webseiten-Test), 18 leer lassen (nur ein kleiner Kreis als Platzhalter).
> Kein Text, keine Buchstaben, keine Zahlen. Kein Icon darf die Cremefarbe als Motivfarbe enthalten. [Stilblock]

## B2 Kachel-Icons Reparatur (Freisteller, 18 Icons)

Seitenverhältnis **3:2**, Raster 6 x 3, Dateiname: `diag-kacheln-reparatur`.

> Wie B1, gleicher Stil, gleiches Raster, gleiche Größe. Reihenfolge von links nach rechts, oben nach unten:
> 1 Schutzschild mit Schraubenschlüssel (SFC), 2 Datenträger-Abbild mit Pfeil (DISM), 3 Festplatte mit Lupe (CHKDSK), 4 kreisförmiger Pfeil um Zahnrad (Update-Reset), 5 Mülleimer mit Funken (Temp bereinigen), 6 Einkaufstasche mit Haken (Store-Apps), 7 Globus mit Besen (DNS leeren), 8 Drucker mit Pfeil im Kreis (Spooler leeren), 9 zwei Pfeile im Kreis mit Netzwerksymbol (DHCP erneuern), 10 Uhr mit Pfeil im Kreis (Zeit-Sync), 11 Schlüsselbund mit Pfeil nach unten (OneAuth sichern), 12 Schlüsselbund mit Pfeil im Kreis (OneAuth-Reset), 13 Briefumschlag mit Pfeil nach unten (Outlook sichern), 14 Datenbank-Zylinder mit Zahnrad (OST neu aufbauen), 15 WLAN-Wellen mit Pfeil nach unten (WLAN sichern), 16 WLAN-Wellen mit Pfeil nach oben (WLAN-Restore), 17 Browserfenster mit Stern (Browser sichern), 18 zwei Laufwerke mit Pfeil (Laufwerke sichern).
> Kein Text, keine Buchstaben, keine Zahlen. [Stilblock]

## B3 Schweregrad-Symbole (Freisteller, 4 Zustände)

Seitenverhältnis **4:1**, Raster 4 x 1, Dateiname: `diag-schweregrad`.

> Erstelle vier gleich große runde Status-Symbole in einer Reihe auf einfarbig cremefarbenem Hintergrund (#F2E9D8, ohne Schatten), je 70 Prozent der Zellenhöhe: 1) neutral: heller grauer Kreis mit Haken (in Weiß), 2) normal: orangefarbener Kreis (#E08A00) mit Ausrufezeichen-Form, 3) schwerwiegend: roter Kreis (#E5484D) mit Ausrufezeichen-Form und feinem Leuchtring, 4) Information: blauer Kreis (#4A7FB5) mit "i"-Form. Flach, modern, leichter Glanz, wenig Details, gut lesbar in 16 Pixel. Ausrufezeichen und i nur als Form, keine Schrift. [Stilblock]

## B4 Illustrationen für das Hilfe-Fenster (Freisteller, 12 Motive)

Seitenverhältnis **4:3**, Raster 4 x 3, Dateiname: `diag-hilfe-sheet`.

> Erstelle ein Sheet mit **zwölf** gleich großen, leicht isometrischen Mini-Illustrationen im Stil von Auftrag A3 (dunkles Anthrazit mit leuchtenden orangefarbenen Kanten, weiches Glühen) auf einfarbig cremefarbenem Hintergrund (#F2E9D8), je 70 Prozent der Zellenhöhe, gleiche Größe: 1 Schnellstart (Rakete), 2 Diagnosen (Monitor mit Lupe), 3 Auffälligkeiten (Schild mit Warndreieck), 4 Bericht (Blatt mit Diagramm), 5 Reparatur (Schraubenschlüssel und Zahnrad), 6 Sicherung (Festplatte mit Pfeil), 7 Netzwerk (Knoten), 8 Mitschnitt (Radar mit Wellen), 9 Anmeldung (Schlüssel und Schild), 10 Outlook (Briefumschlag), 11 Drucker, 12 Support (Headset). Kein Text, keine Zahlen. [Stilblock]

## B5 Programm-Symbol und Heller Seitenhintergrund

Zwei getrennte Bilder, je eines pro Antwort.

**B5a Programm-Symbol** (Freisteller), Seitenverhältnis **1:1**, Dateiname `diag-appicon`:

> Erstelle ein quadratisches App-Symbol auf einfarbig cremefarbenem Hintergrund (#F2E9D8): eine abgerundete dunkle Kachel (Anthrazit #1B1B1D, Eckenradius etwa 22 Prozent, 80 Prozent der Bildbreite, leichter Verlauf nach #2C2926, feiner orangefarbener Rand), darin ein stilisiertes Schutzschild mit einer Herzschlag-/Pulslinie in leuchtendem Orange (#F28C28), dezentes Leuchten. Sehr einfach, sofort erkennbar auch in 32 Pixel. Kein Text, keine Buchstaben, kein Schatten außerhalb der Kachel. [Stilblock]

**B5b Hellmodus-Seitenleiste**, Seitenverhältnis **9:16**, Dateiname `diag-seitenleiste-hell`:

> Wie A1 (Seitenleisten-Hintergrund), aber für ein helles Design: Grundfarbe sehr helles Warmgrau (#F4F1EE) mit feinem Verlauf nach #E8E4E0, unten links ein weicher, großer Schein in zartem Orange (#F28C28 bei geringer Intensität), darüber kaum sichtbare feine Leiterbahnen-Linien in Hellgrau. Oben und in der Mitte ruhig und hell, damit dunkler Text gut lesbar bleibt. Kein Text, keine Motive. [Stilblock]

---

# Runde 3 (05.11.2026): Aufträge C1 bis C5

Es gelten die **Allgemeinen Regeln** und der **Stilblock** von oben. Im selben Chat bleiben, A4 und B1 als Referenz anhängen ("gleicher Strich, gleiche Farben"). Je Auftrag ein Bild, Ergebnis mit Nummer schicken. Wichtig: Gemini hat bei B1 Beschriftungen unter die Icons geschrieben, daher in jedem Auftrag der Zusatz "ohne jede Beschriftung".

## C1 Dialog-Symbole (Freisteller, 4 Motive)

Seitenverhältnis **4:1**, Raster 4 x 1, Dateiname: `diag-dialog-symbole`.

> Erstelle vier gleich große Symbole in einer Reihe auf einfarbig cremefarbenem Hintergrund (#F2E9D8, ohne Schatten), je 70 Prozent der Zellenhöhe, im Stil von Auftrag A3 (dunkles Anthrazit, leuchtende Kanten, weiches Glühen, leicht isometrisch): 1) Fragezeichen-Form in einer Sprechblase (orange Kante), 2) Warndreieck mit Ausrufezeichen-Form (gelb-orange Kante), 3) Kreis mit Haken (grüne Kante #2E9F5B), 4) Kreis mit Kreuz (rote Kante #E5484D). Fragezeichen und Ausrufezeichen nur als Form, keine Buchstaben. Ohne jede Beschriftung. [Stilblock]

## C2 Titelleisten- und Reiter-Icons (Freisteller, 8 Icons)

Seitenverhältnis **2:1**, Raster 4 x 2, Dateiname: `diag-titelleiste`.

> Erstelle **acht** gleich große, sehr einfache Linien-Icons in einem Raster mit 4 Spalten und 2 Zeilen auf einfarbig cremefarbenem Hintergrund (#F2E9D8), Stil wie Referenzbild B1 (einfarbig leuchtend orange #F28C28, gleichmäßige Strichstärke, abgerundete Enden), je 55 Prozent der Zellenhöhe, gut lesbar in 16 Pixel. Reihenfolge: 1 Lupe über Monitor (Reiter Diagnosen), 2 Schraubenschlüssel (Reiter Reparatur), 3 Fragezeichen im Kreis (Hilfe), 4 Sonne (Hellmodus), 5 Mond (Dunkelmodus), 6 Stecknadel (Verknüpfung), 7 Blitz (Schnell-Check), 8 Blatt mit Haken (Kundenbericht). Ohne jede Beschriftung, keine Buchstaben, keine Zahlen. [Stilblock]

## C3 Hauptfenster-Hintergrund neu (dunkel) und hell

Zwei getrennte Bilder, je eines pro Antwort, Seitenverhältnis **16:9**.

**C3a** Dateiname `diag-haupt-dunkel` (ersetzt A2, das zu hell war):

> Erstelle einen sehr dunklen Hintergrund (nahezu schwarzes Anthrazit #141416) für die Hauptfläche einer Windows-Anwendung: ganz feine, kaum sichtbare Leiterbahn-Linien und ein dezentes Punktraster, unten rechts ein weicher, sehr zarter orangefarbener Schein (#F28C28, geringe Intensität), oben links bewusst KEIN Schein. Die Mitte und der obere Bereich bleiben ruhig und gleichmäßig dunkel, damit weißer Text gut lesbar ist. Keine Motive, kein Text. [Stilblock]

**C3b** Dateiname `diag-haupt-hell`:

> Wie C3a, aber für ein helles Design: Grundfarbe sehr helles Warmgrau (#F4F1EE), feine hellgraue Leiterbahn-Linien, unten rechts ein zarter orangefarbener Schein (geringe Intensität). Mitte und oben ruhig, damit dunkler Text gut lesbar ist. Keine Motive, kein Text. [Stilblock]

## C4 Kundenbericht-Kopfbild

Seitenverhältnis **16:9** (wird auf Banner 4:1 zugeschnitten), Dateiname: `diag-kundenbericht-kopf`.

> Erstelle ein dezentes, professionelles Kopfbild für ein Kundendokument: heller Hintergrund (#FAF8F5), links ein großer ruhiger freier Bereich für Text, rechts eine stilisierte, leicht isometrische Illustration aus einem Monitor, einem Schutzschild mit Haken und einem Zahnrad in Anthrazit mit orangefarbenen Kanten (#F28C28), dahinter weiche orangefarbene Kreise. Wirkt vertrauenswürdig und aufgeräumt. Kein Text, keine Buchstaben, keine Zahlen. [Stilblock]

## C5 Kachel-Hintergründe (Freisteller, 2 Zustände)

Seitenverhältnis **4:1**, Raster 2 x 1 (je Zelle 2:1), Dateiname: `diag-kachel-hintergrund`.

> Erstelle zwei gleich große, abgerundete, breite Kachel-Flächen nebeneinander auf einfarbig cremefarbenem Hintergrund (#F2E9D8, ohne Schatten), ohne Inhalt, je 85 Prozent der Zellenbreite und 60 Prozent der Zellenhöhe, Seitenverhältnis etwa 3,6:1. Links: normale Kachel in dunklem Anthrazit (#2C2926) mit sehr feinem grauem Rand und leichtem Verlauf. Rechts: gewählte Kachel, gleiche Form, mit feinem orangefarbenem Rand (#F28C28) und weichem orangefarbenem Glühen am linken Rand. Keine Symbole, kein Text. [Stilblock]

## Lieferstand Runde 3 (05.11.2026 11:24)

C1, C2, C3a, C3b, C4, C5 geliefert und als assets/C1.jpg usw. abgelegt. C3a und C3b sind im Hauptfenster eingebaut (Form-Paint, Fallback auf den Schein). C1, C2, C4 und C5 folgen.

## Ablauf für Nick

1. Gemini-Chat öffnen, diese Datei hochladen, schreiben: "Bearbeite die Aufträge einzeln, wenn ich die Nummer nenne. Gleicher Stil in allen Bildern. Ein Bild pro Antwort."
2. Reihenfolge Runde 1: A1 (Referenz), A3, A4, A2, A6, A5, A7. Runde 2: B1, B2, B3, B5a, B5b, B4 (B1 und B2 zuerst, sie bringen den größten Gewinn).
3. Jedes Ergebnis mit Auftragsnummer an Rolf schicken (eines pro Nachricht, nie denselben Dateinamen zweimal). Wenn ein Bild Text oder Buchstaben enthält, neu anfordern: "Entferne alle Buchstaben und Zahlen".

## Einbau (Rolf)

- Ablage unter `Diagnosezentrum/assets/`, Dateien neben der `.ps1` (Starter-ZIP enthält den Ordner `assets`).
- Das Skript lädt Bilder beim Start mit `[Drawing.Image]::FromFile`, schneidet Freisteller aus dem Sheet (Cremefarbe #F2E9D8 wird per Pixelabgleich transparent gemacht) und zeichnet sie im Paint-Handler. Fehlt eine Datei, bleibt die bisherige Zeichnung.
- Bilder werden beim Laden auf Zielgröße verkleinert (Seitenleiste 264 px, Status 64 px, Kachel-Icons 18 px), damit Speicher und Startzeit klein bleiben.

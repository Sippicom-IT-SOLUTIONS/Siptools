# Bilder des Diagnosezentrums (Gemini, 05.11.2026)

Dateinamen entsprechen den Auftragsnummern in docs/ASSET-PROMPTS.md. Nicht unter gleichem Namen überschreiben, neue Fassungen als A1_v2.jpg usw. ablegen.

| Datei | Inhalt | Verwendung (geplant) |
| --- | --- | --- |
| A1.jpg | Seitenleisten-Hintergrund, Hochformat 9:16, Orange-Schein unten links, Leiterbahnen | Hintergrund der Seitenleiste (264 px breit, oben ruhig) |
| A2.jpg | Hauptfenster-Hintergrund 16:9, Orange-Schein unten rechts, grauer Schein oben links (heller als gewünscht) | Hintergrund der Hauptfläche, abgedunkelt |
| A3.jpg | Status-Sheet 2x2: Bereit (Monitor mit Lupe), Läuft (Zahnrad mit Ring), Alles in Ordnung (Schild mit grünem Haken), Auffälligkeit (Schild mit Warndreieck), Freisteller auf Creme | Illustration in der Statuskarte |
| A4.jpg | Icon-Sheet 4x3: Laptop, Netzwerk, Arbeitsplatz, Werkzeugkoffer / Reparatur, Sicherung, Windows, Drucker / Schild mit Schloss, Zertifikat, Uhr, Bericht | Kachel- und Gruppen-Icons |
| A5.jpg | Berichts-Kopfbild 16:9, links ruhig, rechts Orange-Schein | Kopf des HTML-Berichts, zuschneiden auf Banner |
| A6.jpg | Leerzustand: Monitor mit Diagramm und Lupe, Freisteller auf Creme | Protokollfeld vor dem ersten Lauf |
| A7.jpg | Startbild 16:9, orange Ringe, Mitte frei | Startbild |

﻿# Sippicom IT-Solutions - Diagnosezentrum (Diagnosen nur lesend; Reparatur-Werkzeuge nur nach Bestätigung)
# Copyright (c) 2026 Nick Truschin. Alle Rechte vorbehalten.
# Vervielfältigung, Weitergabe und Änderung nur mit ausdrücklicher Zustimmung des Urhebers.
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = 'SilentlyContinue'
$script:selfSrc = $MyInvocation.MyCommand.Definition
Add-Type -Namespace Sip -Name Win -MemberDefinition '[DllImport("user32.dll")] public static extern bool ReleaseCapture(); [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h,int m,int w,int l); [DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr h,int a,ref int v,int s);'

# ---------- Sippicom-Design (dunkel / hell umschaltbar) ----------
function Hx($h) { [Drawing.ColorTranslator]::FromHtml($h) }
function Cl($r, $g, $b) { [Drawing.Color]::FromArgb(255, $r, $g, $b) }
$or = Hx '#F28C28'; $orH = Hx '#FFA54A'
$cWhite = [Drawing.Color]::White
# Zusätzliche Fensterhöhe (0 = Originalhöhe 780; der Reiter REPARATUR hat mehr Kacheln und braucht mehr Platz)
$dh = 92
# Designfarben: werden ausschließlich in ApplyTheme gesetzt (Skript-Variablen)
function ApplyTheme([bool]$lt) {
    $script:light = $lt
    if ($lt) {
        $script:bg = Hx '#F2F2F5'; $script:tb = Hx '#E6E6EA'; $script:sb = Hx '#FAFAFB'; $script:pn = Hx '#FFFFFF'
        $script:tx = Hx '#1C1C1E'; $script:mu = Hx '#5C5C66'; $script:cTxt = Hx '#1C1C1E'
        $script:gr = Hx '#1E8449'; $script:rd = Hx '#D13438'; $script:am = Hx '#B86A00'
        $script:cOffBg = Hx '#ECECF0'; $script:cOffHv = Hx '#DEDEE4'; $script:cOffBd = Hx '#B8B8C0'; $script:cOffFg = Hx '#2A2A30'
        $script:sbA = Cl 250 244 238; $script:sbB = Cl 238 236 236
        $script:tileA = Cl 255 255 255; $script:tileB = Cl 240 240 243; $script:tileHot = Cl 255 240 224; $script:tileBd = Cl 200 196 196; $script:tileRing = Cl 110 110 118
        $script:btnBg = Cl 255 255 255; $script:sepCol = [Drawing.Color]::FromArgb(60, 0, 0, 0)
        $script:hdrA = Cl 255 240 224; $script:hdrB = Cl 255 255 255; $script:cardA = Cl 255 250 244; $script:cardB = Cl 255 255 255
    } else {
        $script:bg = Hx '#161617'; $script:tb = Hx '#101011'; $script:sb = Hx '#1F1F21'; $script:pn = Hx '#27272A'
        $script:tx = Hx '#ECECEC'; $script:mu = Hx '#B4B4BC'; $script:cTxt = [Drawing.Color]::White
        $script:gr = Hx '#2E9F5B'; $script:rd = Hx '#E5484D'; $script:am = Hx '#E08A00'
        $script:cOffBg = Hx '#2A2A2E'; $script:cOffHv = Hx '#34343A'; $script:cOffBd = Hx '#55555C'; $script:cOffFg = Hx '#D8D8DE'
        $script:sbA = Cl 37 34 32; $script:sbB = Cl 24 24 26
        $script:tileA = Cl 50 48 50; $script:tileB = Cl 32 32 34; $script:tileHot = Cl 66 62 62; $script:tileBd = Cl 78 74 74; $script:tileRing = Cl 160 160 164
        $script:btnBg = Cl 36 35 37; $script:sepCol = [Drawing.Color]::FromArgb(50, 255, 255, 255)
        $script:hdrA = Cl 48 38 28; $script:hdrB = Cl 28 28 31; $script:cardA = Cl 44 40 36; $script:cardB = Cl 31 31 34
    }
}
ApplyTheme $false
$fN = New-Object Drawing.Font('Segoe UI', 9); $fB = New-Object Drawing.Font('Segoe UI Semibold', 9)
$fH = New-Object Drawing.Font('Segoe UI Semibold', 16); $fX = New-Object Drawing.Font('Segoe UI Semibold', 20)
$fS = New-Object Drawing.Font('Segoe UI', 9); $fSB = New-Object Drawing.Font('Segoe UI Semibold', 9)
$fG = New-Object Drawing.Font('Segoe MDL2 Assets', 10); $fT = New-Object Drawing.Font('Segoe UI', 9)
$fL = New-Object Drawing.Font('Segoe UI Light', 20); $fM = New-Object Drawing.Font('Consolas', 10)
$fMB = New-Object Drawing.Font('Consolas', 10, [Drawing.FontStyle]::Bold)
$fSm = New-Object Drawing.Font('Segoe UI', 8); $fXs = New-Object Drawing.Font('Segoe UI', 7)
$appA = 'Diagnose'; $appB = 'zentrum'; $appName = 'Diagnosezentrum'
# Version und Update-Hinweis: Auf $updUrl liegt eine Textdatei, deren erste Zeile die aktuelle Versionsnummer enthält (z. B. 1.2.0).
# Ist die Datei nicht erreichbar oder nicht vorhanden, bleibt der Hinweis still.
$appVer = '1.9.2'; $appVerDate = '05.11.2026'
$updUrl = 'https://scripthost.ncscript.xyz/Diagnosezentrum_version.txt'
$outDir = 'C:\SippicomInstall\diagnose'; $telefon = '09421 8699380'; $mail = 'support@sippicom.com'
$cpy = ([string][char]0xA9) + ' ' + (Get-Date).Year + ' Sippicom IT-Solutions'
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$script:lastNf = 0; $script:sevMax = 0; $script:lastTxt = $null; $script:lastHtml = $null; $script:lastBody = ''; $script:notSel = ''; $script:hdrLine = ''; $script:finds = @(); $script:checked = @()
$script:sections = @(); $script:busy = $false; $script:run = $false
$script:ph = 0.0; $script:cur = 0.0; $script:prog = 0.0; $script:acc = $or
$script:tagTxt = 'BEREIT'; $script:tagCol = $script:gr; $script:hot = $null; $script:fy = 664 + $dh
$script:msgAm = $false; $script:obtns = @(); $script:lbls = @(); $script:lastTb = $null; $script:toolCode = 0
$script:tab = 'diag'
$script:oemEnc = [Text.Encoding]::GetEncoding([Globalization.CultureInfo]::CurrentCulture.TextInfo.OEMCodePage)
$script:logBuf = New-Object Collections.ArrayList
$dash = [string][char]0x2013

function ImgFromB64($b) { $ms = New-Object IO.MemoryStream(, [Convert]::FromBase64String($b)); $i = [Drawing.Image]::FromStream($ms); New-Object Drawing.Bitmap($i) }

# ---------- Bilder aus dem Ordner assets (neben dem Skript; fehlt eine Datei, bleibt die bisherige Zeichnung) ----------
# Sip.Img.Cell: schneidet eine Zelle aus einem Bildraster, entfernt die cremefarbene Hintergrundfläche (Flutfüllung von den Rändern,
# weicher Übergang) und liefert ein quadratisches Bild mit Transparenz. Sip.Img.Cover: füllt eine Fläche (Zuschnitt mit Ankerpunkt).
try {
    Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Collections.Generic;
namespace Sip {
    public static class Img {
        public static Bitmap Cell(string path, int cols, int rows, int idx, int size, bool fit) {
            return Cell(path, cols, rows, idx, size, fit, 1.0f);
        }
        // topFrac: nur der obere Teil der Zelle wird verwendet (z. B. 0,73, um eine Beschriftung unter dem Symbol abzuschneiden)
        public static Bitmap Cell(string path, int cols, int rows, int idx, int size, bool fit, float topFrac) {
            using (Bitmap src = new Bitmap(path)) {
                int cw = src.Width / cols, chF = src.Height / rows;
                int ch = (int)(chF * topFrac);
                Rectangle rc = new Rectangle((idx % cols) * cw, (idx / cols) * chF, cw, ch);
                Bitmap cell = new Bitmap(cw, ch, PixelFormat.Format32bppArgb);
                using (Graphics g0 = Graphics.FromImage(cell)) g0.DrawImage(src, new Rectangle(0, 0, cw, ch), rc, GraphicsUnit.Pixel);
                int n = cw * ch; int[] px = new int[n];
                BitmapData bd = cell.LockBits(new Rectangle(0, 0, cw, ch), ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
                System.Runtime.InteropServices.Marshal.Copy(bd.Scan0, px, 0, n);
                // Hintergrundfarbe aus den vier Ecken (5x5 Pixel)
                long sr = 0, sg = 0, sb = 0; int cnt = 0;
                int[] xs = { 0, cw - 5 }; int[] ys = { 0, ch - 5 };
                foreach (int x0 in xs) foreach (int y0 in ys)
                    for (int y = y0; y < y0 + 5; y++) for (int x = x0; x < x0 + 5; x++) {
                        int p = px[y * cw + x]; sr += (p >> 16) & 255; sg += (p >> 8) & 255; sb += p & 255; cnt++;
                    }
                int br = (int)(sr / cnt), bgc = (int)(sg / cnt), bb = (int)(sb / cnt);
                bool[] seen = new bool[n]; Stack<int> st = new Stack<int>();
                for (int x = 0; x < cw; x++) { st.Push(x); st.Push((ch - 1) * cw + x); }
                for (int y = 0; y < ch; y++) { st.Push(y * cw); st.Push(y * cw + cw - 1); }
                int minX = cw, minY = ch, maxX = -1, maxY = -1;
                while (st.Count > 0) {
                    int i = st.Pop(); if (seen[i]) continue;
                    int p = px[i];
                    int d = Math.Max(Math.Abs(((p >> 16) & 255) - br), Math.Max(Math.Abs(((p >> 8) & 255) - bgc), Math.Abs((p & 255) - bb)));
                    if (d >= 48) continue;
                    seen[i] = true;
                    int a = d < 10 ? 0 : (d >= 44 ? 255 : (d - 10) * 255 / 34);
                    px[i] = (a << 24) | (p & 0xFFFFFF);
                    int xx = i % cw, yy = i / cw;
                    if (xx > 0) st.Push(i - 1); if (xx < cw - 1) st.Push(i + 1);
                    if (yy > 0) st.Push(i - cw); if (yy < ch - 1) st.Push(i + cw);
                }
                if (cols == 1 && rows == 1) {
                    // Einzelbild: auch eingeschlossene Flächen (z. B. Innenflächen von Rahmen) mit Hintergrundfarbe entfernen
                    for (int i = 0; i < n; i++) {
                        if (seen[i]) continue;
                        int p = px[i];
                        int d = Math.Max(Math.Abs(((p >> 16) & 255) - br), Math.Max(Math.Abs(((p >> 8) & 255) - bgc), Math.Abs((p & 255) - bb)));
                        if (d >= 48) continue;
                        int a = d < 10 ? 0 : (d >= 44 ? 255 : (d - 10) * 255 / 34);
                        px[i] = (a << 24) | (p & 0xFFFFFF);
                    }
                }
                for (int i = 0; i < n; i++) {
                    if (((uint)px[i] >> 24) > 24) { int xx = i % cw, yy = i / cw; if (xx < minX) minX = xx; if (xx > maxX) maxX = xx; if (yy < minY) minY = yy; if (yy > maxY) maxY = yy; }
                }
                System.Runtime.InteropServices.Marshal.Copy(px, 0, bd.Scan0, n);
                cell.UnlockBits(bd);
                Rectangle crop = new Rectangle(0, 0, cw, ch);
                if (fit && maxX > minX && maxY > minY) {
                    int side = Math.Max(maxX - minX + 1, maxY - minY + 1); side += side / 25;
                    int cxm = (minX + maxX) / 2, cym = (minY + maxY) / 2;
                    crop = new Rectangle(cxm - side / 2, cym - side / 2, side, side);
                } else {
                    int side = Math.Min(cw, ch); crop = new Rectangle((cw - side) / 2, (ch - side) / 2, side, side);
                }
                Bitmap outB = new Bitmap(size, size, PixelFormat.Format32bppArgb);
                using (Graphics g = Graphics.FromImage(outB)) {
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic; g.PixelOffsetMode = PixelOffsetMode.HighQuality; g.SmoothingMode = SmoothingMode.AntiAlias;
                    using (ImageAttributes ia = new ImageAttributes()) {
                        ia.SetWrapMode(WrapMode.TileFlipXY);
                        g.DrawImage(cell, new Rectangle(0, 0, size, size), crop.X, crop.Y, crop.Width, crop.Height, GraphicsUnit.Pixel, ia);
                    }
                }
                cell.Dispose();
                return outB;
            }
        }
        public static Bitmap Cover(string path, int w, int h, float ax, float ay) {
            using (Bitmap src = new Bitmap(path)) {
                float sc = Math.Max((float)w / src.Width, (float)h / src.Height);
                float rw = w / sc, rh = h / sc;
                float rx = (src.Width - rw) * ax, ry = (src.Height - rh) * ay;
                Bitmap outB = new Bitmap(w, h, PixelFormat.Format32bppArgb);
                using (Graphics g = Graphics.FromImage(outB)) {
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic; g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                    g.DrawImage(src, new RectangleF(0, 0, w, h), new RectangleF(rx, ry, rw, rh), GraphicsUnit.Pixel);
                }
                return outB;
            }
        }
    }
}
'@
} catch {}
$script:imgOk = [bool]('Sip.Img' -as [type])
$script:assetDir = $PSScriptRoot; if (-not $script:assetDir) { $script:assetDir = Split-Path -Parent $script:selfSrc }
$script:assetDir = Join-Path $script:assetDir 'assets'
function AssetPath([string]$an) { foreach ($ae in @('jpg', 'png')) { $ap = Join-Path $script:assetDir "$an.$ae"; if (Test-Path -LiteralPath $ap) { return $ap } }; return $null }
# Zustandsbilder der Statuskarte (A3, 2x2: 0 Bereit, 1 Läuft, 2 Alles in Ordnung, 3 Auffälligkeit)
$script:siStat = $null
function StatusImg([int]$k) {
    if ($null -eq $script:siStat) {
        $script:siStat = New-Object object[] 4
        $sp = AssetPath 'A3'
        if ($sp -and $script:imgOk) { for ($q = 0; $q -lt 4; $q++) { try { $script:siStat[$q] = [Sip.Img]::Cell($sp, 2, 2, $q, 128, $true) } catch {} } }
    }
    return $script:siStat[$k]
}
# Gruppen-Symbole (A4, 4x3, Zählung von links oben): 0 Laptop, 1 Netzwerk, 2 Arbeitsplatz, 3 Werkzeugkoffer, 4 Reparatur, 5 Sicherung, 7 Drucker, 8 Schild mit Schloss
$script:siIco = @{}
function GroupImg([int]$k) {
    if (-not $script:siIco.ContainsKey($k)) {
        $script:siIco[$k] = $null
        if ($k -eq 6) {
            # Windows-Symbol: eigene Datei (A4_windows), das Symbol im Sheet ist zu blass
            $sw = AssetPath 'A4_windows'
            if ($sw -and $script:imgOk) { try { $script:siIco[$k] = [Sip.Img]::Cell($sw, 1, 1, 0, 48, $true) } catch {} }
        }
        if ($null -eq $script:siIco[$k]) {
            $sp = AssetPath 'A4'
            if ($sp -and $script:imgOk) { try { $script:siIco[$k] = [Sip.Img]::Cell($sp, 4, 3, $k, 48, $true) } catch {} }
        }
    }
    return $script:siIco[$k]
}
$script:siGroupMap = @{ 'GERÄT' = 0; 'NETZWERK' = 1; 'ARBEITSPLATZ' = 2; 'WERKZEUGE' = 3; 'WINDOWS' = 6; 'NETZ UND DRUCKER' = 7; 'ANMELDUNG UND OUTLOOK' = 8; 'SICHERUNG' = 5 }
# Seitenleisten-Hintergrund (A1), wird beim ersten Zeichnen auf die Größe der Seitenleiste zugeschnitten
$script:siSide = $null; $script:siSideTried = $false; $script:siSideAttr = $null
$script:siStart = $null; $script:siStartTried = $false
$script:siSideL = $null; $script:siSideLTried = $false
# Kachel-Symbole (B1 Diagnosen, B2 Reparatur; je 6 x 3, die Beschriftung unter den Symbolen wird abgeschnitten)
$script:siTileMap = @{
    'system' = 'B1:0'; 'hardware' = 'B1:1'; 'sicherheit' = 'B1:2'; 'security' = 'B1:2'; 'updates' = 'B1:3'; 'backup' = 'B1:4'; 'eventlogs' = 'B1:5'
    'netzwerk' = 'B1:6'; 'wlan' = 'B1:7'; 'vpn' = 'B1:8'; 'proxy' = 'B1:9'; 'zeit' = 'B1:10'; 'm365' = 'B1:11'; 'office' = 'B1:12'; 'drucker' = 'B1:13'
    'ablauf' = 'B1:14'; 'nettools' = 'B1:15'; 'web' = 'B1:16'; 'packetcapture' = 'B1:15'
    'sfc' = 'B2:0'; 'dism' = 'B2:1'; 'chkdsk' = 'B2:2'; 'wureset' = 'B2:3'; 'tempclean' = 'B2:4'; 'storereg' = 'B2:5'; 'dnsflush' = 'B2:6'; 'spoolerfix' = 'B2:7'
    'dhcprenew' = 'B2:8'; 'timesync' = 'B2:9'; 'oneauthbackup' = 'B2:10'; 'oneauthreset' = 'B2:11'; 'outlookbackup' = 'B2:12'; 'ostreset' = 'B2:13'
    'wlanbackup' = 'B2:14'; 'wlanrestore' = 'B2:15'; 'browserbackup' = 'B2:16'; 'netdrivebackup' = 'B2:17'
    'altdaten' = 'B6:0'
}
$script:siTileImg = @{}
function TileImg([string]$spec) {
    if (-not $spec) { return $null }
    if (-not $script:siTileImg.ContainsKey($spec)) {
        $script:siTileImg[$spec] = $null
        $tp = $spec.Split(':'); $tf = AssetPath $tp[0]
        if ($tf -and $script:imgOk) {
            try {
                if ($tp[0] -eq 'B6') { $script:siTileImg[$spec] = [Sip.Img]::Cell($tf, 1, 1, 0, 40, $true) }
                else { $script:siTileImg[$spec] = [Sip.Img]::Cell($tf, 6, 3, [int]$tp[1], 40, $true, [single]0.73) }
            } catch {}
        }
    }
    return $script:siTileImg[$spec]
}
# Schweregrad-Symbole (B3, 4 x 1): 0 neutral, 1 normal (orange), 2 schwerwiegend (rot), 3 Information
$script:siSev = @{}
function SevImg([int]$k) {
    if (-not $script:siSev.ContainsKey($k)) {
        $script:siSev[$k] = $null
        $sf = AssetPath 'B3'
        if ($sf -and $script:imgOk) { try { $script:siSev[$k] = [Sip.Img]::Cell($sf, 4, 1, $k, 32, $true) } catch {} }
    }
    return $script:siSev[$k]
}
$script:siDim = $null
function DimAttr { if (-not $script:siDim) { $dm = New-Object Drawing.Imaging.ColorMatrix; $dm.Matrix33 = 0.55; $script:siDim = New-Object Drawing.Imaging.ImageAttributes; $script:siDim.SetColorMatrix($dm) }; return $script:siDim }
$logoImg = ImgFromB64 "iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKL2lDQ1BJQ0MgUHJvZmlsZQAASMedlndUVNcWh8+9d3qhzTDSGXqTLjCA9C4gHQRRGGYGGMoAwwxNbIioQEQREQFFkKCAAaOhSKyIYiEoqGAPSBBQYjCKqKhkRtZKfHl57+Xl98e939pn73P32XuftS4AJE8fLi8FlgIgmSfgB3o401eFR9Cx/QAGeIABpgAwWempvkHuwUAkLzcXerrICfyL3gwBSPy+ZejpT6eD/0/SrFS+AADIX8TmbE46S8T5Ik7KFKSK7TMipsYkihlGiZkvSlDEcmKOW+Sln30W2VHM7GQeW8TinFPZyWwx94h4e4aQI2LER8QFGVxOpohvi1gzSZjMFfFbcWwyh5kOAIoktgs4rHgRm4iYxA8OdBHxcgBwpLgvOOYLFnCyBOJDuaSkZvO5cfECui5Lj25qbc2ge3IykzgCgaE/k5XI5LPpLinJqUxeNgCLZ/4sGXFt6aIiW5paW1oamhmZflGo/7r4NyXu7SK9CvjcM4jW94ftr/xS6gBgzIpqs+sPW8x+ADq2AiB3/w+b5iEAJEV9a7/xxXlo4nmJFwhSbYyNMzMzjbgclpG4oL/rfzr8DX3xPSPxdr+Xh+7KiWUKkwR0cd1YKUkpQj49PZXJ4tAN/zzE/zjwr/NYGsiJ5fA5PFFEqGjKuLw4Ubt5bK6Am8Kjc3n/qYn/MOxPWpxrkSj1nwA1yghI3aAC5Oc+gKIQARJ5UNz13/vmgw8F4psXpjqxOPefBf37rnCJ+JHOjfsc5xIYTGcJ+RmLa+JrCdCAACQBFcgDFaABdIEhMANWwBY4AjewAviBYBAO1gIWiAfJgA8yQS7YDApAEdgF9oJKUAPqQSNoASdABzgNLoDL4Dq4Ce6AB2AEjIPnYAa8AfMQBGEhMkSB5CFVSAsygMwgBmQPuUE+UCAUDkVDcRAPEkK50BaoCCqFKqFaqBH6FjoFXYCuQgPQPWgUmoJ+hd7DCEyCqbAyrA0bwwzYCfaGg+E1cBycBufA+fBOuAKug4/B7fAF+Dp8Bx6Bn8OzCECICA1RQwwRBuKC+CERSCzCRzYghUg5Uoe0IF1IL3ILGUGmkXcoDIqCoqMMUbYoT1QIioVKQ21AFaMqUUdR7age1C3UKGoG9QlNRiuhDdA2aC/0KnQcOhNdgC5HN6Db0JfQd9Dj6DcYDIaG0cFYYTwx4ZgEzDpMMeYAphVzHjOAGcPMYrFYeawB1g7rh2ViBdgC7H7sMew57CB2HPsWR8Sp4sxw7rgIHA+XhyvHNeHO4gZxE7h5vBReC2+D98Oz8dn4Enw9vgt/Az+OnydIE3QIdoRgQgJhM6GC0EK4RHhIeEUkEtWJ1sQAIpe4iVhBPE68QhwlviPJkPRJLqRIkpC0k3SEdJ50j/SKTCZrkx3JEWQBeSe5kXyR/Jj8VoIiYSThJcGW2ChRJdEuMSjxQhIvqSXpJLlWMkeyXPKk5A3JaSm8lLaUixRTaoNUldQpqWGpWWmKtKm0n3SydLF0k/RV6UkZrIy2jJsMWyZf5rDMRZkxCkLRoLhQWJQtlHrKJco4FUPVoXpRE6hF1G+o/dQZWRnZZbKhslmyVbJnZEdoCE2b5kVLopXQTtCGaO+XKC9xWsJZsmNJy5LBJXNyinKOchy5QrlWuTty7+Xp8m7yifK75TvkHymgFPQVAhQyFQ4qXFKYVqQq2iqyFAsVTyjeV4KV9JUCldYpHVbqU5pVVlH2UE5V3q98UXlahabiqJKgUqZyVmVKlaJqr8pVLVM9p/qMLkt3oifRK+g99Bk1JTVPNaFarVq/2ry6jnqIep56q/ojDYIGQyNWo0yjW2NGU1XTVzNXs1nzvhZei6EVr7VPq1drTltHO0x7m3aH9qSOnI6XTo5Os85DXbKug26abp3ubT2MHkMvUe+A3k19WN9CP16/Sv+GAWxgacA1OGAwsBS91Hopb2nd0mFDkqGTYYZhs+GoEc3IxyjPqMPohbGmcYTxbuNe408mFiZJJvUmD0xlTFeY5pl2mf5qpm/GMqsyu21ONnc332jeaf5ymcEyzrKDy+5aUCx8LbZZdFt8tLSy5Fu2WE5ZaVpFW1VbDTOoDH9GMeOKNdra2Xqj9WnrdzaWNgKbEza/2BraJto22U4u11nOWV6/fMxO3Y5pV2s3Yk+3j7Y/ZD/ioObAdKhzeOKo4ch2bHCccNJzSnA65vTC2cSZ79zmPOdi47Le5bwr4urhWuja7ybjFuJW6fbYXd09zr3ZfcbDwmOdx3lPtKe3527PYS9lL5ZXo9fMCqsV61f0eJO8g7wrvZ/46Pvwfbp8Yd8Vvnt8H67UWslb2eEH/Lz89vg98tfxT/P/PgAT4B9QFfA00DQwN7A3iBIUFdQU9CbYObgk+EGIbogwpDtUMjQytDF0Lsw1rDRsZJXxqvWrrocrhHPDOyOwEaERDRGzq91W7109HmkRWRA5tEZnTdaaq2sV1iatPRMlGcWMOhmNjg6Lbor+wPRj1jFnY7xiqmNmWC6sfaznbEd2GXuKY8cp5UzE2sWWxk7G2cXtiZuKd4gvj5/munAruS8TPBNqEuYS/RKPJC4khSW1JuOSo5NP8WR4ibyeFJWUrJSBVIPUgtSRNJu0vWkzfG9+QzqUvia9U0AV/Uz1CXWFW4WjGfYZVRlvM0MzT2ZJZ/Gy+rL1s3dkT+S453y9DrWOta47Vy13c+7oeqf1tRugDTEbujdqbMzfOL7JY9PRzYTNiZt/yDPJK817vSVsS1e+cv6m/LGtHlubCyQK+AXD22y31WxHbedu799hvmP/jk+F7MJrRSZF5UUfilnF174y/ariq4WdsTv7SyxLDu7C7OLtGtrtsPtoqXRpTunYHt897WX0ssKy13uj9l4tX1Zes4+wT7hvpMKnonO/5v5d+z9UxlfeqXKuaq1Wqt5RPXeAfWDwoOPBlhrlmqKa94e4h+7WetS212nXlR/GHM44/LQ+tL73a8bXjQ0KDUUNH4/wjowcDTza02jV2Nik1FTSDDcLm6eORR67+Y3rN50thi21rbTWouPguPD4s2+jvx064X2i+yTjZMt3Wt9Vt1HaCtuh9uz2mY74jpHO8M6BUytOdXfZdrV9b/T9kdNqp6vOyJ4pOUs4m3924VzOudnzqeenL8RdGOuO6n5wcdXF2z0BPf2XvC9duex++WKvU++5K3ZXTl+1uXrqGuNax3XL6+19Fn1tP1j80NZv2d9+w+pG503rm10DywfODjoMXrjleuvyba/b1++svDMwFDJ0dzhyeOQu++7kvaR7L+9n3J9/sOkh+mHhI6lH5Y+VHtf9qPdj64jlyJlR19G+J0FPHoyxxp7/lP7Th/H8p+Sn5ROqE42TZpOnp9ynbj5b/Wz8eerz+emCn6V/rn6h++K7Xxx/6ZtZNTP+kv9y4dfiV/Kvjrxe9rp71n/28ZvkN/NzhW/l3x59x3jX+z7s/cR85gfsh4qPeh+7Pnl/eriQvLDwG/eE8/s3BCkeAAAACXBIWXMAAC4iAAAuIgGq4t2SAAACnGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4NCjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iPg0KICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPg0KICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSJ1dWlkOmZhZjViZGQ1LWJhM2QtMTFkYS1hZDMxLWQzM2Q3NTE4MmYxYiIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiAvPg0KICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSJ1dWlkOmZhZjViZGQ1LWJhM2QtMTFkYS1hZDMxLWQzM2Q3NTE4MmYxYiIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIj4NCiAgICAgIDxkYzpjcmVhdG9yPg0KICAgICAgICA8cmRmOlNlcSB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPg0KICAgICAgICAgIDxyZGY6bGk+YXJkaTwvcmRmOmxpPg0KICAgICAgICA8L3JkZjpTZXE+DQogICAgICA8L2RjOmNyZWF0b3I+DQogICAgPC9yZGY6RGVzY3JpcHRpb24+DQogIDwvcmRmOlJERj4NCjwveDp4bXBtZXRhPg0KPD94cGFja2V0IGVuZD0iciI/Ps2RS+oAAB+4SURBVHhe7Z0JfBRFusCr+pieM5MMISAQEEJAkEMOgRCQW1FYXXffruu5q7vre/p8KkJAwQsJV4Louurb/b31573r+nwe64HugoioIHIIaOQKh3IlgSSTuY/uevV19WRuMoFMCNJ/6Mz01zV9fN9XXx1dXY1RB+WFson2oTZvkd0k9iYhZ3+bJOaLnKwgRP+j6GljAn/Y97OGdg5E/YeQjA24yRvwiwbrjka/fOSEIXfn5LmrnWraDkaHcoB/Pjy24EJLaLqdD04XUWCcgOQePFYwVo0OJ8s+Oz5YdQSC6BXQvwoyHAkT4Wu3bFhd5+ffu/SRTftYurNPh3CATY+NH1Ague7JEQLXGlCwgEdhTYXs77kOXAVch4J4FCIGbwCZ/q8maHxuyPyN61iKs8dZdYA1S6/IGyDUPmDCvruN2C9BDmcG71CBqU0BZ1Do3zAyII9ieaOO5M0fMnftXm1zu3PWNL23csxPHFzTH0zI15uj6iCI07acH6iOQAu3EDG7nYr1oZ5lXz2pbWpXzooD/LBixLIczjXPQHx07cdk+NgCKzPVgiPINBq4ie2tnUrX306du6pB29QutKsDrLxrnOOXPd0v5fGuGRwK0oPD5ac/BdgKQBqW7qz4a6th583OGjjVNQJQ9Cm0wugm1qodjeYbppZ/uV3blHXaTaOL77ws75Zeje93ElwlmPp8S4eGCpOMeXdQ4avDirCHJt/Bi6YmQjjqN+y3atWqI/kEwYgDmyteIRSWhxow6SsIcrFIgvmcWvLDGTO3iD9t5iggbZJtNdub7NMuL/98pybMKu2mviOVl7yVxzl/2lJ5H0YiCiHDeo9s+msDMX40ZN7YQwhVnivtvyQ2VUzonI/ck004cKuFC0wRUVBgBo9XfcQtwEE8KGfHQa7bpJGzPqxnW7NHuzjAwYoRT+YLjfcISpBmEjhk7GGZ90Ob2U0s253E+kBx2YZVqvBHxncVJcNysW+RjXPPEGgRGC0aog4Bf0F+Usld1+ODgVPR2r+G1Q1ZItYSWeHbpaN+3sPgfENCfs3U8YDP03YxaVSsi3oduKgcPftqSNv0o2X/8tE32oWmpy3Im5taJwqNhBKqCecuL5q3+X5NnBWy6gBrF1+ZO8R0ZJOZOIs1URwYE+RTzO4jgZzbBi3Y9L+a+Lzgy8XjhlxoaHzLznn6QDsg0RSQMfzYHDgidym9uGzdFk3c5mS1DdbbUPeIkbip8eP9PBL0PbLFX6PkTT3fjA+MXvDZjr1C4SgXsm1LND7TD0YS8UoO5Mxq/0DWHGDz8sl9cjjf73gCRViidyu0omeWj4XtN180d8OXmvi8Y9ysVSe/dVlu8iHbMVYJZIC2YA0+rZxv3N6KcT8FeTbImgM4sGuWEXmtCbZXkWlNv5FYygc9sPENTXTeMvHRDVW1ivX3tB5E1yI3vRhQGRRo3cmK3XMRKkuhyTMnKw7wfvn0PDvn/QW0feODP8OLrVt71hcv1lbPey4q2/i+i1ieg5YQJqAzcATQHLiAgsycr+TbZV+UqonbmKw4wABT0wSRC3ZBJN78EOagdnsiaFmKlrz2o6/tt4aD/pxlTZyjys/b9/u53H1+zq4tefsUTjpqlsThWtI2JSth5ciK4S/l4fqbwXuZj0VCG0ZNJHdrwVMzL0XfLz5nO3eyxTMvzBaLQ8d5Ly8SljNp+4AIqGvIhzvLLqXvf74bVMVtSJs7wOLyW4z/btq2w4qcxdGOjkjuF9CRUN78/vdvWaqJdc4ybV4ETMP7+wlE7qOtajBHCCIpfCJsfk9d0ekQtHkE2LVs1DXdxca3ofYav3uCXCRvV8HBoqHo6TfVUHZg5cSJVs49hVZ8YuoD8Js2P61zC1p1UjWgdpvDuAEBuQMkLArBHY1B/nh1MLf6mkdWt8lt4zPS9JqFEwq6WYVhKKfb2gG/f1k16t6KsXO78bXLOdrSjwADNwk9Uj1xvNF9zrZfaGJ0dMXwVbm4YTqrK0ROJVW74XwjogvmAPAJf2FRCEfCSKzxE2F7gJjeqQ2Jq0Yt+OIg3XRanFYRsLl87EWHlw/94whrzbf52PnioTBv0DYhm4SprRPqd9QD4A6gIHLVmgShP5RzBk7uwW4NA5FL1InqAvTIPkGn0KwWcQibsKdrHue6ooA/+Wx/6eTO4xVDXv9m8ejLaMJW0yoHWL1kWqdDy4c929d0cqtDcN5lQu58Gr0Dm48Hmy3HEz/93ryqApVBWLxB3Hy8kgvoxaCw3hJoJUyXnKphjmYeCfmsdt75i55S47ojFYPe27Jk7ECWMjMydoCqJSNvGG48trmz0HCHhPwm8EjWTYFIyBvbpIeB0KmRYVi/xmGi2/5MAT2z2+sIGbAXOXjXjCJjw5dHHr90lirMgIwc4ODyYf/dQ3K+aiauC8H/kgwcKbIArQWbCu1cVfoHdAdoSyAqgG2MxGPNQydXHqkYunrdkmmdtc1pOaUD/Pes0s5HK4etKhCc/2EggWbDq3aMtWYc0N2TAlUYdR2jDAJsYhv0peUlgprv2dcEWPEARg3RaOCccrF09NOPHxw9gm1NTeye43h61sSCn3Zt/MAhNI5gffoJSekqJgQ1Esf3f67rP/CR5X/3gLjuieFzLEpDZWJFEMb4HQ/bK4vmbZsL63e+vBQ/fPLd20Xi7Ub3FKkJ6lDidQealxV/iO8n8UoRT4IDORzOhWeOwCKpXQGALRg1KbaTVW7LVZMWfrmJyeNJ7QBPvYKP+h//KJdvnMbBzYmUqZhL1Cudji6pGVj89IpXvSDN1AF0To9Ny0q7ObB/sl0I/kJCgRkiCvKR+lgyLB64FMvhg6jHqFFlHx1j8igpi4DDoT+stAtN06CWGWt89UFMeiAINDISkFOxbncpxtsixmewMJREalfTaSWj7v/8aN95W17pPHvnNT8E80c3Kvb3gsigaT2V5hVk4909CnHNW3fd+xO45xxHkln2VZb8sgtX/3eB1ioR4akkfqfQAPEhE2mQLQt7b+u5FP3t7bgbFBABzDQCQLERix4BMuMfK37OdTGGDAasEI4DLSrogAfhn815D7pWU7K7YtT1nXjXMxbkzdNEcagZFosQrSsL52yK039cBPh40aRudux6RoRuXDXrxxofggyGkbvuH/x51/aeu3VhovFVWJhIRo8AGdEzeHxqcaB6T3Fg9zdFvl3fFPv2fDMF7/32eMWgLYceL71dSxZH/7mb/rbPnz+uUbHujXQfJ1qOJyFkQ01lO5eWTtXEKnEOUCQ1LbJgb37k57F/Ybd+ZK49yXUaO3jBxndUYUrSWDqNX+jEw6GwTSDBQoEE+vLET5dAXwn5+9gF13Ab9lytJUtizIL1VV8Hu41pkm3bwQasqygKOIER+1C+6K5At9zY3HPb7ACbl00YksP7boYHN5gR4SkX2Anke4WGfYvyQyD3tn73fXbqJ1ZS1xjT+oVOIjT2Nzex2SdYgbDBNQH4k44rF/yrfqcz7zoPyTmaKr9BxrZi77A9gw5cr4miDtCF99wjIa8YW5uEE4HyA0bx1IdtDw+e/8X72qb04DQdPKnOSCcJ0H7qvALSlpU4tfzT3cdCOb8LIjPNionpMRKpD9k57yx01d1QwWMOsH7JpAusnPeaxLDBTgQjL7KuL5q36czG8KW+Kp0WaX3OGfzA56vcyPIHeOA01e/N2Dd096StE+G76gDdJf+VIgp1SkwMISOAjOhEyFquiVomXVdw66/jvATUFK+qSM5J3nIqqn25lT5krFcfVqW/i+6F0PZYAFk4369gXbWWifh+xiOo0CdmU0zLfvMnA+//7J+aIAMyP0md7HHZg2uOehXLczKGKBBrFaggyjRbBy7/84PX2rh3yqfnGbA8gvUmxQJlvwE1BaW/aYLM0JuBZwSoKVlVqaUtURswvhYkkmaQiF3YvkQU7lliOzGIKzJ6igQU7BJ/ABYyQsjgPi6bW5H7T0Eav9DJHiNeGLjdjyW1WRhvXURrByGUw4WGciZMijlM1DE7UWANJjISdl724MetG26Urg7Qegc+LwErJOeV1NIW2fdnOYTE9WwASawBqEPQ1prAEbix5B2C1fF78QngRz4Zt34+u3RFwGmcv04U1TqnkYl8IfSdTG2Z2CRU1xXvxZxVEgyJzT+2GSNeNJ3GNCVpLK1HgAyBOXBAh9GFWYMuUIFvJQaDqYpakn6DfUEfDSywLwVZBM7E8UTWon+shUAANyKMrb9Pn64nUD2GTksoyOAJYXNdCFsP0+WHMF2C2EIX24kQNtVqyTLGzzu8Qc56NMiZ1f2xxQJLbRiJR2MyfyrDnU62TfOb09nVecgPhl6rq6V+RXuliwbsk/oP3Ge4aGA1/dxjGNiHft6tJcuYaq5w6z5jcf9DUjHd34CBkaXa0L/vD1Kfm3HtEyNXWJUTs6Nhh1kKok09Lnigx30bl6mCDKl7ctgcs9yo3w4+R+CaArICI85Z3S2aTaFfQA4FhmirZ44eATokHOLMO+G59OTaO6GVBKW7tpI5pxgVrNPx4Nwyt49NYRgPSDgSGrlm0cTemihDEvekkUasc3bh9vn4vUEk1mnrzYC9DDhkLjL5xzNJhqTrB9CLgA4J92+PfXJCJsKGZAtB6zEEo0hu0wQZksbSegTokKgFtlM2/BOmaE0uCBRkxv7Ldq0ozTwK6COCzilUB6iXc98II2PKeWkNxIftyF2J0POZmVAfEXROoTpAyfx/1viR6TVoq8fDYkIO9oz+vvLZOUx2mugRoEPS3GbzcDkrQ9joSS4GEHWLILJzTUuqHy+doInSk64I0OmQNDtA31lrqt2K9QWYxDHeCWANIwPyCQ7U+FZVxbgSbUNKCMYiuAD7VfxCaT6eTscgziAHQrmLaFFwnJk/MRJgZESuvK58/fu7KsZergmTcCPrRhexfuxRjLvdsrnRo1jqPYqp3itb/F5FcmvJdDoISfF61/KxN3cTTrxEczx1gcQMy5wiSIykUbY91mtP8WL0XJoJH2+YZHy1J7ZbjDzN/pDEgOvDgue2RR/oTtCBSFlgH6685JlcrulOAcHbPZKTQDiHh0N9xPpVvWxc2G/eppafF9DpkKR0gMIbZxo3DTv2jh3XX36q9/uANASPGhDpK58ivtiomFcN3j3mEHp+pf68/zlCastS1jx1nWmovOcts9J4BYwOhNvDWkUuARYjZLpdJoI3jAz7FYx3eoPIoxD5kN0s/kBTdIzKX8zcxZFvaRVwlomeKUYKlpA3LHK+QOAHP+YP3OsZdPCTxc+lLnpbySmv/x9P3Wi6NFj1Zg52Todu4eQ6QTzgIPFFRvR7R1N4rCt3NCeIPTdGpB1F4zHhAwoSq0OY3+hRpPf3Os2fX16+rkZL2GpavvarrxMPj99bkYPd9xowvPenLdSVfIk6scTqmOkqKoFvLKNBx12QSLW0dfVmA7I9OWju+t0sTeZkbM1dy0Zf11lwP27kvN0FItODt4Uj6JwZLC5A8RxEks+tWF7Z6zEtn/jo59EJOVugVVZcs3hKp2LDiYdtnP92IwoY2cHBQ3VnOFuA9uExfuiABXfwIVNjg2x5oO/cLX9iKU7NaVnuq/Ix/buI/lk5fPBqWixcAC0FcAYgGtx1p2h/WESAx/ldJOev6+Ret/9q3lvq7G3pOCMrrV16eW4/yXmZqHh/LpDwBJ4L96BtAZ5VFcEVou6gkznJRmF6jGay9GaLRGUoFqgTbN3pyrlu6sLP0j7g02bZdOnsmdaZ+bW9JCz3s4uok9PrGWwQsIXHnHp/OHLyOq0DY4yMBk4h4XBX+vViAYV7CzhMM1lknsB0JgR9c+AE+/f6HVeUPvhJSidoMwfQyT533HWl8TddTxZ3N8olRhy8yUD840UMj/VHMle8OZmDINSg2Ku3egrGzHx09Ql1Qwy6A5zD7Ci/dGYXY+B+K/aWwuv4GalMyqEmlLOqy+yrZyC0KC4Ut7kDVD17rdkb4mwbquvQooPhptp/fOHTNulkieplI+52iL7FRuSxRnJ9FLYGk/PXKI7yPmVfPaQKNNrcAWqeLL3LqLgqgyG/n8OkRhIIhB2sEN50PGx/rt+8Tc+wlDptyZby8WMuNDa8bMLuvtBFlGhaqIPBTG+H/PaJlyzYuF4Tt9C3expwJGAWictoE3y5Fj7QnyfBUoEEx/IoOIxDoSItmU4bM+LB9RvrDV3H+TnrdpbnE+MAjOfwcp0NvkqEVjV7RzZu0qi1ftYiZUQ+6VGz+i78853iu1fX7HHnXO8lOfWpQjtYJIfzjd5f+Vjzu4iz4ACsb5CFoMRFJ9uMeeiL704Sy29hdrckjRP2LmIz9s5D6D9U22cjAuicZfqXffm2k1hfUB/61WQAdBfDuhEHRu9ctkN9yVT7OYAeANqVAz7zYh8xelgBHFMYEw4ZaBToZJCvBUnbO4A+R1CHYMJDn+1zE8tLEAVicx/B7BV0EvFdufTR601ZiABpLK1HgHbnRMDwShBJ9BvYBBYwApv/WUCh4p+YDg9sewdI92CIHgHanRF7emz2E+N3zCIxUYB+hxEEFiEwJAsRII0DpBHrZJGXXg+GkPgpe+QvNgfCdLEgJSOyUAfQHw7tSPhD+FtWD4hH7aUJ+wdnIQKkQY8AZwVetHxLsKitxaIgi8Rj/PLy6yVBCRpkFKalN203cmApggjhcVPQGrjj4ReS3wt0CuqeGDHHrNTrs4SdJk8v/I2QY3DT2nmIxUxqjjAPb2/hcBgLodvKXk/78qhU7H1yxriu8oH1InJRq8bndz9nW89NFg+VXSHuPnCVYU/VVeKeqiv5XXTZXTVd2HNgivXor7W0rUCP9WdCibB/6hXi3uoZ4p7vrhL3Vl0l7K26mttTNZPfvX86f/ApLVnmEHiXc6R3Nh4oBjgDH3IYsbuTCbkLTdhFF+2Tc3Uycy6HljZz9DmCzggJBywm7O1M7dDDTG2hLshDF1e+CfsKtGQZI6AABxNDp+rygWFjXJMvrM0TyCYNZTdxaGK6Eg54L2ZJW0MaS+uBISOo/qm1QIdgh4SFtP4Vu0Gf+2KIAslWwcgTIjBgT6qKzhMYTQa9RSYe9dVWMyddP0AasU48LBMmki6It4xZIAN49dG++N+DQynYuItzKzBPYIRoIvA5AcuD1j46uYcmygy9GXhGsLyfSGppy7yPRS5cCrZM/D1E/YDM7+bq+ZydMjIcBw/BMbkXfmJAAVsfW2A0k5whp3P+OmfEzhVPFBlxcAC85T0WcAh4o5gsiJ9xU+Z92BAkwte0NKDROzYhphEgiETiuUMTZIbeFXxGgJqSVZVa2hIWpem3IgqYmEnifx9G4qHtwYJv1aphQ9j4sULgbaLxicBzTMg/ZfPCkrRTwiSTxgH0CNCuvLFgXDcb5/13eKqbKT9qAKjke4j42XXz/8+lOkCjbHk9iAyuRCtBRUHifKi7OXC/JmoZvQ5wRsSbKkJq6akYnusvM2NvHtgwFgj/8DY4j2x8DdZVByhZsOaQl0hvp2orQhSwca5J+5aPuUcT6XRwti4unZiH3fdA7T8RyIcBYvrm3+oK/wXrzRZv4myVQWQKsRpjFKgYCiiAOgmuip3Lx4/RxOnR3xp2RoD2k4Nlamkq1iyd3KlQcv7FhH20RpeodJjbSUJebK38ZsXr6ouom6018L51O93ErM4WGvszqEDAoY3IbSgUGl77ZuXU/mxLamhyEbqUwJHgJdiYngasw0L3k8Y7dCKA7mP13xreePyXlqFS/d+t2F2Uyl1gKIiH5v573P3U8A/EGeSQ3/aoH1nqkz2OnZKEm3p1RzUfbVtSUqoKUuAkFupI1q0BZDzoDRsCnrAUdquLAdHWxikfVdZJZ/yW3eKjh8b3nIB2v2cmzinswZBECKIRHp2UbfPfeuT55ht8cQ4w9sFP9tcrOfeH1CHF4AAJB6UiI2nqdaFUv+bAipG3a9I4iu779L3Oc74ZsSnc8+KPj+YMWV+TN2R9rW3Ip7W2i3c4pZVaMp00gOmSc29ihoxnT2XJlBH2+vVW1DgRnhpOrvjBfgXUSGz/M3De5+8yKSOlWx2uHP6Sg2u8mVO7EBN3Bu8Yhpu9AnIp5k9cyDa3uOyLr7TNOmfIjiVjru0l1b8pofj5mKAA9ePcNx337fi5JkI7Kif3dJD6x3J4769hpG+irQDo2iG0LHaRnG3v1zkm37r8k0Ztk0rKMvmp2sI7GmXbZrhbxHwSdhzxQPYTjrYv7VzTxK5c7YbjFYPX7F868qb1iyZ0UzfqnDag6RRm1JZ4coj7KQfv/LWoGj8N9GcexXpyly/npkTjA8l71Vi3dFrniwx1q3JQo/pmcRhMnCpxpKiQiYBCWGgMK4YqGoS+Jhx3tMET4hUFtrM7jVHSHva8QL16qhDCyVhGxqCHy3t27ENrnSDeqUWA+BwNWoYIYI+LAN9XjHyvM183Q1tNAn7lRTknj8uOqwbO/XSTJo7jlJb41+KpnQeKNe/l8e5RqcqWVLBThb9sUUlwz5b38uNH1Q01fxiZURNf0Lvw3nXqS7pTOwCkTy4CDlVe+m4BVztTW21GLaYxh1yyteZYKO/qofM/S2l84JTNsmkLVtctOt5jYr2S+0IIJXcVpyJy0mB+qCmoC71QfUlYaIZiulG8fOLdmhSkzjTJPwPjy9RWTsW+oTrsGHUq4wOndADgTytX+XqUbbu1TnH8JoAsdWBgdr6tyceQNrrAPs73Bf5rf1rIV5GNEf1F4WJ+B3sFgsgcrid55aXH+k0qeWD996rwFLToABH6lG168Ttfl5FO5PifIDLK6kVQb9M5Q6jdSEwAELQ51qLE1L2gZy0GmECKGZ7QKrkBeZB91dGQY1zhnM0PVT/+htrT1xIZOwBQ8uAn318we+vtu7yO8TTEPO9HFjcEejgB5p8xLqnTImoWwjz2IKnZsjaJUzjadotokn0yI7MHPKIIgiD5iZE28ewfHAg4rs2fveOqi+7f8KW2OSNa5QARRj28ccMFZV/ftsPbdfCJsONOp2L7yItMNUHqhVDqM6dI3WrQoUDjnCoHNBRQsH/TsYBL24L8gWBfTKJT9MNfZn6aNhw/6/oJ2fLM/lDepQVzds4YMn/T25q4VbSZjT4sn9SpUGgYYMao2CiKPbHit7h9wUHqAdrsKD8uqFpEN87ZMmTBV8232w9WjPhrAX/y+thoCnUuGinQScWxtLBsy3xN3CbopulI3DuXryv8cJsVOQdrkmbgZV414fxbi+ZtfEETtQmnVQToZIfvum24xIBCF0dK/ggQDWQsBv2ipVXleyZkxQHeXHaDdPfDtxjRuJ9IaPh0CQ2aJqH+V0hoCF06XQ0PrOukwIK9N4sokGQTqBIGkVj9jKtr2jl/T5esFAFbKyZfewHX8Ecc9vgUdUQiK9HoNyxjgTup2G6/ZP6G1WpiHZUtlTPz+/AHdhiJ64JYs4DmFFr3qw3l/+XCeZt/r4nbjKxEAF8YfyFxQXOe6O/byeDr6zB46acXPos6i67eXUTvUi2pjkZndPQRiXip8ZOB1pUXGV7UVtuUrDhA6fw1NV5ieQXarez+NosArLcA5qrzjKxePqpNa7PnMtsXl0y3c5474fZ77LMZAOgsqJg2DJz3+881UZuStUpgE29/MoiNbmjyMtiFwQVxKIAcQtOib5aOnawKz2M+fvSybt0M7r9IyM+pGSWqMAqM4aO5n7NVIHRrfM2wjciaAwy891/73cj8vIIFupZ47hwyIh9XaGh8ec/KyYM04XnHh09enTM4x/l3K+fqHtUQi5JswciDzBsvvO+z0+rkyYSsOQCwz5O7zIcsx7TVGFgftoQ83QpQ7YdVy0vGaxvOG9YtHN/rUuXgBxbiHBcdw8eiJPyFBcbwHQ9ZFqjCLMGOmEWqK0t+lc/V/01S30XMuocj3s6+E+RH5rCLWP+r55zNGb3o6Fxn3+MlU/NI04tm7OnGhtglmoE9u3dScazsWbZ5tibMCll3AODwihF/zuMabucIPKaUGHTUko89rULMn3iIraxP2RebtY0/KnYsG9c7n3c9YuV8v6btffW6k41PoSKnkvfFigPdLl/xzAdZHUndLg6A7v6Z4Ujh/jV5XOM4jsBolVSHZWVeGEkhnyJ+7FYszx8NWdaOe3BtLdt+bvLuY1fYBkiNo03Y+1sLF7hGwgETy/WxGYFde+TTTeyHD+KCUZfOXp2i+Gxb2scBKB9VXJM3jD/4vhU7S1QnSHtopgR4O3mYGE6EEb8jTNA2njcdavDLXCjccccgKNSxBcyhXJOkhEPOC0086c9zZIiIgoXwmFYkx0dMHUvEKbzIWvN9KH/6sPvXfa1tyirt5gDA2mXT8i7ia9+1c65SyOstHZ4pLPKNLglt5I4GnB604tS8rTbnWPGW3tkjQFoO0ah39IjSacYl8z5tF+MD7a7RSf91rfHVnof+SJs+v2MDH7PaEGlnYvN1ZqoFB4Fo10Ry1u8N5txw2fxPD2ub2oWzlqX2V4y5JY9vqjQib0HqmvCPHRYZoM7jVKzLplQXlu/50zutmpOxLTirWt+w+LKeF0pND9Na8Y0CgXcRgyMAP15niBQJMhaRj1g+rAmaHx30QOuGcbUlHULTB5+YOMAiN8wWUOAGA60lR96KydR17hO5ChnxKERolRAZV4V40/Lus75cp244i3SorPbpI2P6FprDM83Yf43EhYYIWHZAVGALnGzHH4UMuRtu6ChqJRBuhkGY591BRdwdUMRVdQHpneEPf9lh+jk6bKxdv7C04AJTqC+Sw5eY+VBfm0EJe/yhC9xB1BuzqS87FrQ2K/Co0WEi3yEkYp/Cc84Ad5w3mLfWh5XdIx+4iVbu7upgAQ2h/wdwU8ilzdUriQAAAABJRU5ErkJggg=="
$wideImg = ImgFromB64 "iVBORw0KGgoAAAANSUhEUgAAANYAAABACAYAAABm3IlwAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKL2lDQ1BJQ0MgUHJvZmlsZQAASMedlndUVNcWh8+9d3qhzTDSGXqTLjCA9C4gHQRRGGYGGMoAwwxNbIioQEQREQFFkKCAAaOhSKyIYiEoqGAPSBBQYjCKqKhkRtZKfHl57+Xl98e939pn73P32XuftS4AJE8fLi8FlgIgmSfgB3o401eFR9Cx/QAGeIABpgAwWempvkHuwUAkLzcXerrICfyL3gwBSPy+ZejpT6eD/0/SrFS+AADIX8TmbE46S8T5Ik7KFKSK7TMipsYkihlGiZkvSlDEcmKOW+Sln30W2VHM7GQeW8TinFPZyWwx94h4e4aQI2LER8QFGVxOpohvi1gzSZjMFfFbcWwyh5kOAIoktgs4rHgRm4iYxA8OdBHxcgBwpLgvOOYLFnCyBOJDuaSkZvO5cfECui5Lj25qbc2ge3IykzgCgaE/k5XI5LPpLinJqUxeNgCLZ/4sGXFt6aIiW5paW1oamhmZflGo/7r4NyXu7SK9CvjcM4jW94ftr/xS6gBgzIpqs+sPW8x+ADq2AiB3/w+b5iEAJEV9a7/xxXlo4nmJFwhSbYyNMzMzjbgclpG4oL/rfzr8DX3xPSPxdr+Xh+7KiWUKkwR0cd1YKUkpQj49PZXJ4tAN/zzE/zjwr/NYGsiJ5fA5PFFEqGjKuLw4Ubt5bK6Am8Kjc3n/qYn/MOxPWpxrkSj1nwA1yghI3aAC5Oc+gKIQARJ5UNz13/vmgw8F4psXpjqxOPefBf37rnCJ+JHOjfsc5xIYTGcJ+RmLa+JrCdCAACQBFcgDFaABdIEhMANWwBY4AjewAviBYBAO1gIWiAfJgA8yQS7YDApAEdgF9oJKUAPqQSNoASdABzgNLoDL4Dq4Ce6AB2AEjIPnYAa8AfMQBGEhMkSB5CFVSAsygMwgBmQPuUE+UCAUDkVDcRAPEkK50BaoCCqFKqFaqBH6FjoFXYCuQgPQPWgUmoJ+hd7DCEyCqbAyrA0bwwzYCfaGg+E1cBycBufA+fBOuAKug4/B7fAF+Dp8Bx6Bn8OzCECICA1RQwwRBuKC+CERSCzCRzYghUg5Uoe0IF1IL3ILGUGmkXcoDIqCoqMMUbYoT1QIioVKQ21AFaMqUUdR7age1C3UKGoG9QlNRiuhDdA2aC/0KnQcOhNdgC5HN6Db0JfQd9Dj6DcYDIaG0cFYYTwx4ZgEzDpMMeYAphVzHjOAGcPMYrFYeawB1g7rh2ViBdgC7H7sMew57CB2HPsWR8Sp4sxw7rgIHA+XhyvHNeHO4gZxE7h5vBReC2+D98Oz8dn4Enw9vgt/Az+OnydIE3QIdoRgQgJhM6GC0EK4RHhIeEUkEtWJ1sQAIpe4iVhBPE68QhwlviPJkPRJLqRIkpC0k3SEdJ50j/SKTCZrkx3JEWQBeSe5kXyR/Jj8VoIiYSThJcGW2ChRJdEuMSjxQhIvqSXpJLlWMkeyXPKk5A3JaSm8lLaUixRTaoNUldQpqWGpWWmKtKm0n3SydLF0k/RV6UkZrIy2jJsMWyZf5rDMRZkxCkLRoLhQWJQtlHrKJco4FUPVoXpRE6hF1G+o/dQZWRnZZbKhslmyVbJnZEdoCE2b5kVLopXQTtCGaO+XKC9xWsJZsmNJy5LBJXNyinKOchy5QrlWuTty7+Xp8m7yifK75TvkHymgFPQVAhQyFQ4qXFKYVqQq2iqyFAsVTyjeV4KV9JUCldYpHVbqU5pVVlH2UE5V3q98UXlahabiqJKgUqZyVmVKlaJqr8pVLVM9p/qMLkt3oifRK+g99Bk1JTVPNaFarVq/2ry6jnqIep56q/ojDYIGQyNWo0yjW2NGU1XTVzNXs1nzvhZei6EVr7VPq1drTltHO0x7m3aH9qSOnI6XTo5Os85DXbKug26abp3ubT2MHkMvUe+A3k19WN9CP16/Sv+GAWxgacA1OGAwsBS91Hopb2nd0mFDkqGTYYZhs+GoEc3IxyjPqMPohbGmcYTxbuNe408mFiZJJvUmD0xlTFeY5pl2mf5qpm/GMqsyu21ONnc332jeaf5ymcEyzrKDy+5aUCx8LbZZdFt8tLSy5Fu2WE5ZaVpFW1VbDTOoDH9GMeOKNdra2Xqj9WnrdzaWNgKbEza/2BraJto22U4u11nOWV6/fMxO3Y5pV2s3Yk+3j7Y/ZD/ioObAdKhzeOKo4ch2bHCccNJzSnA65vTC2cSZ79zmPOdi47Le5bwr4urhWuja7ybjFuJW6fbYXd09zr3ZfcbDwmOdx3lPtKe3527PYS9lL5ZXo9fMCqsV61f0eJO8g7wrvZ/46Pvwfbp8Yd8Vvnt8H67UWslb2eEH/Lz89vg98tfxT/P/PgAT4B9QFfA00DQwN7A3iBIUFdQU9CbYObgk+EGIbogwpDtUMjQytDF0Lsw1rDRsZJXxqvWrrocrhHPDOyOwEaERDRGzq91W7109HmkRWRA5tEZnTdaaq2sV1iatPRMlGcWMOhmNjg6Lbor+wPRj1jFnY7xiqmNmWC6sfaznbEd2GXuKY8cp5UzE2sWWxk7G2cXtiZuKd4gvj5/munAruS8TPBNqEuYS/RKPJC4khSW1JuOSo5NP8WR4ibyeFJWUrJSBVIPUgtSRNJu0vWkzfG9+QzqUvia9U0AV/Uz1CXWFW4WjGfYZVRlvM0MzT2ZJZ/Gy+rL1s3dkT+S453y9DrWOta47Vy13c+7oeqf1tRugDTEbujdqbMzfOL7JY9PRzYTNiZt/yDPJK817vSVsS1e+cv6m/LGtHlubCyQK+AXD22y31WxHbedu799hvmP/jk+F7MJrRSZF5UUfilnF174y/ariq4WdsTv7SyxLDu7C7OLtGtrtsPtoqXRpTunYHt897WX0ssKy13uj9l4tX1Zes4+wT7hvpMKnonO/5v5d+z9UxlfeqXKuaq1Wqt5RPXeAfWDwoOPBlhrlmqKa94e4h+7WetS212nXlR/GHM44/LQ+tL73a8bXjQ0KDUUNH4/wjowcDTza02jV2Nik1FTSDDcLm6eORR67+Y3rN50thi21rbTWouPguPD4s2+jvx064X2i+yTjZMt3Wt9Vt1HaCtuh9uz2mY74jpHO8M6BUytOdXfZdrV9b/T9kdNqp6vOyJ4pOUs4m3924VzOudnzqeenL8RdGOuO6n5wcdXF2z0BPf2XvC9duex++WKvU++5K3ZXTl+1uXrqGuNax3XL6+19Fn1tP1j80NZv2d9+w+pG503rm10DywfODjoMXrjleuvyba/b1++svDMwFDJ0dzhyeOQu++7kvaR7L+9n3J9/sOkh+mHhI6lH5Y+VHtf9qPdj64jlyJlR19G+J0FPHoyxxp7/lP7Th/H8p+Sn5ROqE42TZpOnp9ynbj5b/Wz8eerz+emCn6V/rn6h++K7Xxx/6ZtZNTP+kv9y4dfiV/Kvjrxe9rp71n/28ZvkN/NzhW/l3x59x3jX+z7s/cR85gfsh4qPeh+7Pnl/eriQvLDwG/eE8/s3BCkeAAAACXBIWXMAAC4jAAAuIwF4pT92AAAGmWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4NCjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NjcyOSwgMjAxMi8wNS8wMy0xMzo0MDowMyAgICAgICAgIj4NCiAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4NCiAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0ZURhdGU9IjIwMTYtMDgtMjlUMTQ6NTE6MjYrMDI6MDAiIHhtcDpNb2RpZnlEYXRlPSIyMDE3LTAxLTA1VDIxOjQ2OjMyKzAxOjAwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDE3LTAxLTA1VDIxOjQ2OjMyKzAxOjAwIiBkYzpmb3JtYXQ9ImltYWdlL2pwZWciIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RUQyMjNCMEE4OEQzRTYxMUFFNTFCRTQ4MEYzMkFEMUMiIHhtcE1NOkRvY3VtZW50SUQ9IjFDRkJEQUFGMUY0RDRENDNFMEEzRDI3OEExNzAyQURGIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9IjFDRkJEQUFGMUY0RDRENDNFMEEzRDI3OEExNzAyQURGIiBwaG90b3Nob3A6RGF0ZUNyZWF0ZWQ9IjIwMTYtMDgtMjlUMTQ6NTE6MjYuMDA4IiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiPg0KICAgICAgPGRjOmNyZWF0b3I+DQogICAgICAgIDxyZGY6U2VxPg0KICAgICAgICAgIDxyZGY6bGk+YXJkaTwvcmRmOmxpPg0KICAgICAgICA8L3JkZjpTZXE+DQogICAgICA8L2RjOmNyZWF0b3I+DQogICAgICA8eG1wTU06SGlzdG9yeT4NCiAgICAgICAgPHJkZjpTZXE+DQogICAgICAgICAgPHJkZjpsaSBzdEV2dDphY3Rpb249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOkVDMjIzQjBBODhEM0U2MTFBRTUxQkU0ODBGMzJBRDFDIiBzdEV2dDp3aGVuPSIyMDE3LTAxLTA1VDIxOjQ2OjMyKzAxOjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgRWxlbWVudHMgMTIuMCBXaW5kb3dzIiBzdEV2dDpjaGFuZ2VkPSIvIiAvPg0KICAgICAgICAgIDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpFRDIyM0IwQTg4RDNFNjExQUU1MUJFNDgwRjMyQUQxQyIgc3RFdnQ6d2hlbj0iMjAxNy0wMS0wNVQyMTo0NjozMiswMTowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIEVsZW1lbnRzIDEyLjAgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIgLz4NCiAgICAgICAgPC9yZGY6U2VxPg0KICAgICAgPC94bXBNTTpIaXN0b3J5Pg0KICAgIDwvcmRmOkRlc2NyaXB0aW9uPg0KICA8L3JkZjpSREY+DQo8L3g6eG1wbWV0YT4NCjw/eHBhY2tldCBlbmQ9InIiPz5rydblAAAW/klEQVR4Xu2dCXxVxbnA5yz33HuTm33F7CQhEPZNxAUrUjfaaqVordZXLD+rdBFLWI2KQSAhIGqV11f0aZVaW1ttbbXoU5YqBVlkk7Bng4Ts5OYmdz3nTL+ZTFIiN7lLbiD65p/f+d2Zb+ZsM/PN982cOSeIw+FwOBwOh8PhcDgcDofD4XA4HA6HwxmECOy332yaEy1MzEkdESO7JoQJrhSDFNyhMUaoXZWsHZrhaLNb/tekp454WBKH85UhJIpVV5x1t0VGiyWkjUdCyHQVqVhoVnXxxXbdtCZtSVkHE3M4g55+acFnizItefHot0YJ38lEIQLM1gWXpmJU7vGg22OXVn3BRBzOoCZoxTq8fJIxzdy42Sijb5C4hlGHB0svdWjKewcalBa7SwUpUZDAEMDijRoiKwlyx7UGUX1IEdFQIvfoyGp1oqvTHq8qoxk5nEFM0IplLc1apYj6UhJ2aWh/eQu6a0Jx1SmaGCL+9tAV5muyDCVmGf2cxN0aOmJE9nGmRY1EazmcQYvEfgOifnVmqlnGb4BWyjoWjp9ulaZNWF1Zy5JDxu/32tTcCOc/RqRakiQBTZZElNiuGhpKP7buYVk4nEGJyH4DwiCiB0GpTMTVs3nER8evLD/PkkLO3Hdc6KwzbLETKxs9gullyWgOY0kczqAlKFewrTRjByjX1ZouVH9e784qEyfHiaKqsOQBgVyogAXUYHO6lm34qKlTyuEMTvxWrIqi7HEY6dcMfaLiRVtpZqMs4ngVi29HFFTM6libYZcEbGZZBxAMfyJy62KbjvE/3br8v9trw9+96/mDGsvA4QwKfLqCZ54Za2pfl/lsUri2NzkcTyMyUCpqnWQBtz3+TUsi6KcZg45eio2giHqkScLfijR43r41ve2T6qKMXJrA4QwS+rRYe5/IDc8Od/2fSRamkjhG6I9hC6rudqzLsEI0EnZ/deUHdQ8/cE3SKoH4aQMMOUWEEWyWKI80Svp1oGowzkNIx6i5zYVvGfJY9V6akcO5zPSqDMX3TRZ+MqbhLZOEZpG4hoUv2j2GB5KXntzTpVhgQV4NW1A5h6QPNOfWj4yIwB2pjR0G5ylpVFWqVpGcYrYWGwT9hyQdlOucA4tj4xdWNNIdAuT48ePZMTExI51OZwx5lhYk9rS0tLdI4I033hCmTJlyv6J0Dj1Pnjz59+nTpzcfOnTIAuehZRoMZrO51Wq1HsvOzj7ORJSjR49Ot1gsaSwaEB6PR4uPjy8/e/bsvvz8fBcTo+rq6gQoi9tYtAPu7U8sTNm5c6cF8k9oaWnJkGU54Imw9vb23SNGjDjKopTnnntOvO2224ZHRkbmulyuaF91oeu6Oy4urmr//v2HrrvuunYmvgi4l9TExMRrNU2Tamtrd+Xm5p5mSX4D++VHR0dPgqCzsrJyG9x7Q2dKAJxblXknKBAm2/mSjL0Hl6SDheqEKBaR29dlvsJEA471meHf6TxnBm55Ju8GIntnrlFoKUlf1X2dazJfp5kDABTJ4nA4/g4FjkNANTss2rZtmwgNg4kxhoY/kcibmpoymShooDFhOPaH+/btS6AnAxoaGj5gyUHjdrub4fq6lR7OM4UlEbrvjQD55kCZnWdpQdHW1vYLdjiKzWa7Ae6rjCUHhKqq7XC8tX/4wx+M7HDdwH3Ng2vtrgwIa1DnG9577z3q8fjiyJEjUXa7/U9QHjC074Sd726W5SK89jLvPByPzDJaRMJgCRw2j/i9scXVbTTxMkP6L1HQ6XV/9yUXfm5bx+Oqjj4lcaOE76lenX8FCfsLFNByk8k0UxSDevIQMP2wht2QY4Al/GZeXt5KJgoJBoMhFnj11KlT0STe27VWVFRkQM+9EcqM5gsFdXV1Y8LCwt6H+xrBRAEhSVJ4RETEgm9/+9vFTESpqakZA2kvwLV2z1pDWIQ6f/iGG274NRP1ClhxMSsr623wFGZBeXQXCDkf8EpVVVUSE/XAa8mdWJ2flGZor4OSRW5N3Bi1qOJBlkQB63DJXUFisRTs+CsJu0RlRvSjJz+mCUBTSdbN4bK+mYTtKvpp3OKqDTTBD6A32w0NajIJg5KdhgLb1o/Gfx72XUgCxGJNnTpV63IFjx07Ngncnn3Nzc1x0HhLqDAIwMJeD40ih4WPQYXThggW69GEhISRJBwo4ArGgiv33a77hkZ+y5AhQ4gFnALRXVSI0BlITycB6KknQSN+iEr7AVio34PLR+sRLMJGuJe5JAyGQYN62Qb3WUnifQF1FgbXeSPUYSKJE2O0Y8eOhOuvv54u2j5//nwBdAKlJAzsgXsNh7z5JEIsz7lz52akpKRsoaleADf3h+C6v8aipL3sg7IKB90cTuJQB7Pgut+mib6wlmbe3OVetZRkfJeJuyGKRdIuhyvoWJeOW9fn3sjElH8UjDWDi+gg6W2lGb9hYr+Ast1LCpgAhXbRvQZLb65gf4FGN5MdEoM7FtR40hvQsM+yw+LGxka6qBqCvbqCoQbKfhc7D4ax15NM7BdlZWWpUC5utjsuLy8fy5IQWJRiJiYsAkUxg3KdYHEMyv2vefPmee1JP/zwQxnq8CTLStzvT+E8EgTXd0oo32PZe+DV/1FEHMGCyGMwD4qHsTZVPtumKpvaVOOmdo+xjokpt649CO6q4WWbathkV+X9TBwwHR0dtNcbzEDFslDIGbAD+wNYke7GDS7WQRb0i/z8/LPw0z3pAq5qHAteBHgLDqvVWsSiyGKxTC0sLLyJRXtw9dVX3wseB/UOiAaBt7EMLJVfz0y9aur5NVm3myT9L2SC3aFLt8YurKBuVhfEYsHPJXUFBwpwJXaD+0ddQeKCQG/WBmVI0/wB9iczdeXwu6W+vn5NRkYG7Yh6cwVhIBy0K0hcNdh3IjTCcSQOPegxcJeoKwjH/0VUVNQYEg4UaFxmaMzfh+PTjhbGJTNTU1Pfh3Lw6grW1tZOgnCXK3ga3MbVLBw0cK7P4OfKzhgibim0P/+BurPBPhYS3rp1643Tp0+n7h2xWOnp6YtJGFgMeda8/vrr0uzZs/cbjcbRRAju3C6oQ/pIqYvq6moZ7usouH1UsaB+34dyn0nCcK3r4Wc+CQOz4Zg9Zkt75dTTw4cRl4u6VmuzLhogE8UiaZfSFRwoHA7HCqgUKKv+A8c6ApVGNak3VxB6vX7PCnYBDeJlckxCKGYFCdCAXPv376eWG6JeXUEIz+4UUXYwcb+A43zWeTjKHUzsN0Sx2L54y5Yt05n4IleQiYnr+52ueie/UC+3sCQK1N0cmgjAuA1Dp9ml9FSxOlMo/ruCx2s6Trp1kc7zS0h/4JMFw6JowtcQaJxF4NOvggZVSQqQiYMCrEf+zJkzr2bRAQXGJHvg2pexaEgAa22Hspg7fvz4wJ/PfMU4ffr0u6A8+0gYLA6KiIh4cseOHdSDg3IF42ToLlvoMP+WlJS0m0X9wqtizfzvM1jTxedJWBRQ8qhE94Z3Fkzx6jZ+1YmJifFERkY+BgWZtXPnzkjogaIC2cAtSoMej/j4lOjo6BgW9AnsR2bYyLOcH/m7QaXfD2OEieCuTYFz1YPMG2SWyuv+vW1g8e4A9ycFjhnws8CvIqNHjyZWfjnUIY2Dy3fVhAkTbiZh6Fx+AspGXUCoIw2GCl2uZP/ZunSM0r42Yx9x+chmXZPxZvXqfNpoGkpHzDxamD6/rDDT66Dv/xtQ+Be6MXRm0R9XkFjIZ599NiQTJl9yBQuZuF/AcXy6gnDvIXEFoSy6y9Bms81jYr84ePBgOOzvZLvjAwcO0DEzoTdXkNDU1ETGTh+zNFIfu7Zv3x4GnVctExH3/ncsezcg9ukK9mmFap5OHRpjNmwXkJ5K4hoWWz268Ga7ZtgTrzhraKZLjMODUbOYXL55T3nFz99q6vebxBUVFaPArQr6mx1g8ZTY2NgF0KvRp/jkWDAofqeP51iZkL+CyIjF+tWvfpU0f/78frteRLESEhK6OrrHocd9moWDBhqN18kLaICzRVH8Iwu74Z7Wtba2Okk8QDbn5eVRFwvGPG+azWa6kgGO2Qpu6UbomKqjoqIcRNYbjY2NKeBxzIQyp2MgYmEOHz6cPG7cODqJ5G3ygoUpsP+0uLi47cQdJIC1+ofFYrmVhOE6NHAZR8M19lh2BeXic/LCp3t35unsrAhFe8so4ZA8hwkNGHl0qU7Dwmv1DsPa4U8eD/p5DlTgf4Eb8CqL9guiKHV1ddkpKSnlX2fFAvd3VHJy8uGuxtgPHoFj0CEHKObNoCCb+3tMsDZ/AQXtfh7pS7EIYCG3gDLRZXIXAvXza+gwH2bRbvxRLJ/reNIKT1ecCJ842YEND3h08SC4pP0a4IcGARlEPdkkaYtSzM5TNasyA55FCjVQ2Dr0diuIUjHR15YrrrjiC7Ama+CeQ9YWYGz3AYw3C8isJBMFBLkU6CQ/BMtFxowBAQr0M9h6fF4PjtUEnWTQnVPA3cPuJyempZqs2dGKaux3fxUEzW5DjFnS8wyCdpdBxJ1LU8Bqd6jS/QmLy9+gmQIACnAsWKzbWTQoQKHaoKF9EB8f3+0ybN26VQCL9ThUNI3DGGtjfn7+uZaWlmhwH+niU/A00AsvvLAOLFa/v5kIFutesFjZLLoVetFPWDhooLGlwHF+zKJWCD/HwhSwXGPAVZsRFhZGnx8FAbFQPWbbKisr4+E+ZkCdDOuy9r6wWq02sHiffvTRR3vmzqWroroBi3UjWKxrWPQjON+/WLgH9fX1k8BiPmkymVLB6h2vqalZnpOTc4wl9wCUmHgGV7HwW+AW93AVCUHpRmNJ5rzmdlXRdLFs5MrqD5n4krK7aJKYa255yChq6+EmFFAux3m3ODVlaUVAT+05nIEgKMWyr8uwwo6DYuVFQ8nQWRGyRn1cpyrseHW/+9pH3wz5B6M4nIDwOcbyxuVwAXsjcXH5n926sImETTK+5v5JEUGt8OZwQklQijXYaHciOrNEkHX3t1iQw7lsfC0U6wt3yuc6RvS1bAHp3GJxLjtevbqakmFXSoh81hkjJzI8lbm4rMeno8kiXPi5tN+8KB05VtA9BXQOUJRXJi882mPGxlaa0SSLKA7Sf2deUH0fE/ukoihrhiLhO1Meq+z1aX/tyswVWNfpzBIpsK45ZodunJPz5MkqFg2YX8/7hnBHxpn1mtvTvSrdqEgNDg+en1ZY2ePVmAvZ9dRV5lxTwwan25NxYRUqinQoYXFF1/MVrxxYkj4r3iJMSS2s6rEKoS9qns58WROl19OXnd5G4tUrskdqmnt11vIz36EZvHDqqaxCs6h1L4btQhTUnw0prPX6/f0TyzMnhRvQL6EufsBEXrGWpk9xqVKhR9XCmQjJkug0SOjF2MWV7zGRV2pWDX1eQvoHycv+k69qxdDXJKOpKHVRz3Z+Ic/dm2y4f3z4OrtDHdXVAkyKdK6iFc+ftLryoueoXi1WuOiJiZJd95EtEnXQpfWXmzBJy+i8Jvd94ZKawsSUDwrGmCUR0UL26KKdCv0k0qinRJsE8iC0V9qV5Nft5sQl5jDzVpNRTLebk5bYTUlLal2Wfr1o6G45GR8paz+u02OXNOgxS+r1+CVYkI6LRlMyy+KVYeaGsTCe/L7TlLzEaUqkGzJHl1hk9ZGtK2b0uUQqQsGZsWbU/SKgP8SY0ZUWA+r+5EFsmBQZZRIueqB6IXp4/GukjBSjsikmTBxGyswBcasprdcXJiMUlBhrEq5l0V4xiNJd0LgFB6kHtikG+ahJRj471GgjmhJuwH9tKcl69JX7ZdorRRn1a8yK3udnBu4ZHZbqcXvm1NF6Ilv0EhUpjUkWIZZl6YFXxWpQww4g+uxPgB5GoMs7BhPal+zspATbNBDRJUUeHR2gQr8R6F9fDFu460Ruwd7dJuQ6jXXkyC3Yszt34Z7d01bt96rE1tKsobZncjbb1uVsLn9+Wnev+mViLEq7pmM5O8JelGVxFA2NsBXJAh6DNHef3xcxQ61hQdCz4RqyF+6lW7xg+5x0pBFhfX+8A7wMsjOL+U+Xle4CC1+W9GRYwZ5qUkaxQtshAWEXKbMciA8v+KzXLylBa2MhH8C5dU1rzCH1wDaj6DkNwwCWoW9a3coig6j//I6RaRtPr59ooG1A7/vfGNjcQrvJIMg5UFdDSV1ZnFBXaka7S/C6lMvrnRw+3VTv0gXy4hn0Dvi+qhWZmTSB0XeRXlqW3xYrKaJOF53CdWkOPSygF+QGAkn21EtYXenR9GI7lnpdSeCIGeusd5umuV1qqRG5VyrIs1JCmlnGuu8JmIsqofPFVvKlYJ8Erlewz3920qFhX4LPSPYOufegTy8gWRbKTp03XiVLOCfe07xF1bHF1/E+9UxsanQqN7hYXZHNJKqW9Ci9e8HvhXithVkv1SOnp3NNlSggc5QR/6ludd4FPW9nd3UZi5by1j1Rwi+mRayAsRV1H9ya8PvUpWUBP8Tyt6PwN5/l0bMdMPb8JHZR+bZRj2ztdaHwTTEnpiYZPX/WBGmW1aPcY3Ub7tGxkAmV0qc72+aWHNA7K3XFwzZ0bVbVWAKNX2ttc/pcxaFjNOJcSS7bN3dDbXEeuFa9o2PsAGMwh+Q/B5tb1QsEQSDj7AHAdymDV6IqsnTVhffv0sQf6Fj0/W91SacA5xi/6kTD57WIvCZy3GLQfb5hcGP4gVtiFPWPuiB31hVsOpLSXBr2Wr+9dm+vHUl8B26ArmA2SmhiuMG1q3HNUKqdX7RG5umClK+KQkhftAuEc6tTY2+aGPtbswHR/9Gl6qhexdIvaWJgfAqVuZyF+wQa2E74CckrGYQ6t7QLrNqCGIP7syiD8zPyK4q4yOl2X/SqwoV49LqDTo9+V5TBQfcjW4Ts2t7ukW765lPbbCxbb2yWBPx4tOyi+5HfaIO7zwmYDhd+IExyb6L54Zwwxn3Xpcv+fniHLDimX67yg0MwAvFZhzUO0zqDoBd33TvZTKK+sd6uPMGy9AocvwjK/DAJX/9MpStqUeVct4ZuBxe/zy9CSc7zH4FCLrrwnC5VK2rwhL/PsvSgT6OzdWFG5LgE9L5JQl1rrbBTEw5jLO5qd6n20C3B7JtWVXozM8aYdOHnz0yaKxHGGXRtIFxHk9Wp3zak8Az/v1mcQYFPb+5M6WRTjNBULAr4Z6CxQf2juv5Sb5cejglXarsUS0PKDBl3KpaOhE9tHvlHyUtOBfzJYA5noPB7mNRYmpcvY/WngqDPVEScIYKfSgwW8VcHGrsu3SogMRYGi9RFsmnGaeTtXFk2JFYqY/4ydcHbl/XTXRzOlwlq/mH5j64KT42PiDaA/dJgmCbqAzuNoSOx4c6EslKjhB8BNcbVNmPq8OUn+EpbzqAlKI2oLRlxc7iizybGyubUXktdduqfLGlAKCsaEZFmtpfLIorXsXAgvKByPEvicAYlfjz0uBhZdxxRdMe9Cnb+OEZRf7PvsWy/v0wUKK9+T0GpZnsJUSoSd2n4f2gChzOICUqxEpdWnnXrEnnvH4kCzhsaqX589ImsLJoYQurX5hnuuPKK9QYR0e8OuDV0xCx4XqKJHM4gJujB0ScFI42jE9s3w7jnG+QwGkYdLk16xYWN737eILfYXcF9QEmEKxo1RFbiZPu1JlF7UBYx/b6bpqOWFod4XfoTFV4XcHI4g4l+zTrsXZRhyYkXf2uU9KA/H+YPqo7K3Sq6PW5p1RdMxOEMakIynVdbnH23RdKXGUQ9qI/y94aKhWYPFl+0qvKarKUn+v3BFQ7nUhESxSL89cE4YXh64ogISZtsFt3JSueK/IAhqzk6VMHa5lFOtHuET8YXHfW9/ovD4XA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4PkDo39tI1kg+4QY3AAAAAElFTkSuQmCC"
$ico = $null; try { $ico = [Drawing.Icon]::FromHandle($logoImg.GetHicon()) } catch {}

# Scharfe Schrift: GDI-Textausgabe mit ClearType
$tf = [Windows.Forms.TextFormatFlags]'NoPadding, NoPrefix, SingleLine'
$tfC = [Windows.Forms.TextFormatFlags]'HorizontalCenter, VerticalCenter, NoPadding, NoPrefix, SingleLine'
function DT($g, [string]$t, $f, $col, $x, $y) { if ($t) { [Windows.Forms.TextRenderer]::DrawText($g, $t, $f, (New-Object Drawing.Point([int]$x, [int]$y)), $col, $tf) } }
function DTC($g, [string]$t, $f, $col, $rect) { if ($t) { [Windows.Forms.TextRenderer]::DrawText($g, $t, $f, $rect, $col, $tfC) } }
function TW($g, [string]$t, $f) { [Windows.Forms.TextRenderer]::MeasureText($g, $t, $f, (New-Object Drawing.Size(4000, 200)), $tf).Width }

function DB($c) { try { $c.GetType().GetProperty('DoubleBuffered', [Reflection.BindingFlags]'Instance,NonPublic').SetValue($c, $true, $null) } catch {} }
function RR($r, $rad) {
    $p = New-Object Drawing.Drawing2D.GraphicsPath; $d = $rad * 2
    $p.AddArc($r.X, $r.Y, $d, $d, 180, 90); $p.AddArc($r.Right - $d, $r.Y, $d, $d, 270, 90)
    $p.AddArc($r.Right - $d, $r.Bottom - $d, $d, $d, 0, 90); $p.AddArc($r.X, $r.Bottom - $d, $d, $d, 90, 90)
    $p.CloseFigure(); $p
}
function Rnd($c, [int]$r) { $c.Region = New-Object Drawing.Region (RR (New-Object Drawing.Rectangle(0, 0, $c.Width, $c.Height)) $r) }
function SideBg($y) {
    $t = [math]::Min(1.0, [math]::Max(0.0, $y / (740.0 + $dh))); $ca1 = $script:sbA; $cb1 = $script:sbB
    [Drawing.Color]::FromArgb(255, [int]($ca1.R + ($cb1.R - $ca1.R) * $t), [int]($ca1.G + ($cb1.G - $ca1.G) * $t), [int]($ca1.B + ($cb1.B - $ca1.B) * $t))
}
function DwmRound($h) { try { $v = 2; [void][Sip.Win]::DwmSetWindowAttribute($h, 33, [ref]$v, 4) } catch {} }
function Dur($ts) { if ($ts.TotalSeconds -lt 60) { "$([int]$ts.TotalSeconds) s" } else { '{0}:{1:00} min' -f [int][math]::Floor($ts.TotalMinutes), $ts.Seconds } }
function Hz($t) { [Net.WebUtility]::HtmlEncode("$t") }

# ---------- Eigene Dialoge (statt MessageBox) ----------
# Dialog-Symbole (C1, 4 x 1): 0 Frage, 1 Warnung, 2 Erfolg, 3 Fehler
$script:siDlg = @{}
function DlgImg([int]$dik) {
    if (-not $script:siDlg.ContainsKey($dik)) {
        $script:siDlg[$dik] = $null
        $dif = AssetPath 'C1'
        if ($dif -and $script:imgOk) { try { $script:siDlg[$dik] = [Sip.Img]::Cell($dif, 4, 1, $dik, 64, $true) } catch {} }
    }
    return $script:siDlg[$dik]
}
function SipBox([string]$text, [string]$head = 'Hinweis', [bool]$yn = $false) {
    $sbIco = $null
    if ($yn) { $sbIco = DlgImg 0 }
    elseif ($head -match 'Fehler|fehlgeschlagen') { $sbIco = DlgImg 3 }
    elseif ($head -match 'erfolg|fertig|erstellt|gespeichert') { $sbIco = DlgImg 2 }
    $mz =[Windows.Forms.TextRenderer]::MeasureText($text, $fN, (New-Object Drawing.Size(428, 2000)), 'WordBreak')
    $th = [int]$mz.Height + 6
    $dlg = New-Object Windows.Forms.Form
    $dlg.FormBorderStyle = 'None'; $dlg.StartPosition = 'CenterParent'; $dlg.Size = New-Object Drawing.Size(480, ($th + 160))
    $dlg.BackColor = $sb; $dlg.ShowInTaskbar = $false; $dlg.TopMost = $true
    Rnd $dlg 14
    $dlg.Add_Paint({ param($s, $e)
            $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
            $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 0, 0, 480, 4)
            $g.InterpolationMode = 'HighQualityBicubic'
            if ($sbIco) { $g.DrawImage($sbIco, 22, 16, 44, 44) } else { $g.DrawImage($logoImg, 24, 22, 36, 36) }
            DT $g $head $fH $cTxt 76 22
            [Windows.Forms.TextRenderer]::DrawText($g, $text, $fN, (New-Object Drawing.Rectangle(26, 76, 428, $th)), $tx, 'WordBreak')
        })
    $by2 = 76 + $th + 20
    $dg = { [void][Sip.Win]::ReleaseCapture(); [void][Sip.Win]::SendMessage($dlg.Handle, 0xA1, 2, 0) }
    $dlg.Add_MouseDown($dg)
    function MkB($t, $x, $res, $prim) {
        $b = New-Object Windows.Forms.Button; $b.Text = $t; $b.SetBounds($x, $by2, 90, 40); $b.FlatStyle = 'Flat'; $b.Cursor = 'Hand'
        $b.Font = $fB; $b.ForeColor = $cWhite; $b.DialogResult = $res
        if ($prim) { $b.FlatAppearance.BorderSize = 0; $b.BackColor = $or; $b.Add_MouseEnter({ param($s, $e) $s.BackColor = $orH }); $b.Add_MouseLeave({ param($s, $e) $s.BackColor = $or }) }
        else { $b.FlatAppearance.BorderColor = $cOffBd; $b.BackColor = $cOffBg; $b.ForeColor = $cOffFg; $b.Add_MouseEnter({ param($s, $e) $s.BackColor = $cOffHv }); $b.Add_MouseLeave({ param($s, $e) $s.BackColor = $cOffBg }) }
        Rnd $b 10; $dlg.Controls.Add($b); $b
    }
    if ($yn) { $ok = MkB 'Ja' 266 'Yes' $true; $cn = MkB 'Nein' 364 'No' $false; $dlg.AcceptButton = $ok; $dlg.CancelButton = $cn }
    else { $ok = MkB 'OK' 364 'OK' $true; $dlg.AcceptButton = $ok; $dlg.CancelButton = $ok }
    $r = $dlg.ShowDialog($form); $dlg.Dispose()
    return ($r -eq 'Yes' -or $r -eq 'OK')
}
# Eingabedialog für das VPN-Gateway (nur wenn in den VPN-Profilen keines gefunden wurde)
function AskGateway {
    $dlg = New-Object Windows.Forms.Form
    $dlg.FormBorderStyle = 'None'; $dlg.StartPosition = 'CenterParent'; $dlg.Size = New-Object Drawing.Size(480, 250)
    $dlg.BackColor = $sb; $dlg.ShowInTaskbar = $false; $dlg.TopMost = $true
    Rnd $dlg 14
    $dlg.Add_Paint({ param($s, $e)
            $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
            $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 0, 0, 480, 4)
            $g.DrawImage($logoImg, 24, 24, 40, 40)
            DT $g 'VPN-Gateway eingeben' $fH $cTxt 76 22
            DT $g 'Es wurde kein VPN-Gateway gefunden.' $fS $mu 78 56
            DT $g 'Gateway (z. B. vpn.kunde.de) - leer lassen zum Überspringen:' $fN $tx 26 100
        })
    $dlg.Add_MouseDown({ [void][Sip.Win]::ReleaseCapture(); [void][Sip.Win]::SendMessage($dlg.Handle, 0xA1, 2, 0) })
    $pw = New-Object Windows.Forms.Panel; $pw.SetBounds(26, 130, 428, 40); $pw.BackColor = $cOffBg; Rnd $pw 8; $dlg.Controls.Add($pw)
    $tbx = New-Object Windows.Forms.TextBox; $tbx.SetBounds(14, 10, 400, 24); $tbx.BorderStyle = 'None'; $tbx.BackColor = $cOffBg; $tbx.ForeColor = $cTxt; $tbx.Font = $fN; $pw.Controls.Add($tbx)
    $ok = New-Object Windows.Forms.Button; $ok.Text = 'Übernehmen'; $ok.SetBounds(246, 190, 110, 40); $ok.FlatStyle = 'Flat'; $ok.FlatAppearance.BorderSize = 0
    $ok.BackColor = $or; $ok.ForeColor = $cWhite; $ok.Font = $fB; $ok.Cursor = 'Hand'; $ok.DialogResult = 'OK'; Rnd $ok 10
    $ok.Add_MouseEnter({ param($s, $e) $s.BackColor = $orH }); $ok.Add_MouseLeave({ param($s, $e) $s.BackColor = $or })
    $cn = New-Object Windows.Forms.Button; $cn.Text = 'Abbrechen'; $cn.SetBounds(364, 190, 90, 40); $cn.FlatStyle = 'Flat'; $cn.FlatAppearance.BorderColor = $cOffBd
    $cn.BackColor = $cOffBg; $cn.ForeColor = $cOffFg; $cn.Font = $fN; $cn.Cursor = 'Hand'; $cn.DialogResult = 'Cancel'; Rnd $cn 10
    $cn.Add_MouseEnter({ param($s, $e) $s.BackColor = $cOffHv }); $cn.Add_MouseLeave({ param($s, $e) $s.BackColor = $cOffBg })
    $dlg.Controls.Add($ok); $dlg.Controls.Add($cn); $dlg.AcceptButton = $ok; $dlg.CancelButton = $cn; $dlg.ActiveControl = $tbx
    $r = $dlg.ShowDialog($form); $v = ''
    if ($r -eq 'OK') { $v = ($tbx.Text.Trim() -replace '^https?://', '' -replace '[/:].*$', '') }
    $dlg.Dispose(); return $v
}
# Abfrage von Kunde bzw. Ticket vor dem Start (erscheint nur, wenn das Feld noch leer ist; Eingabe landet im Feld KUNDE / TICKET und im Bericht)
function AskCustomer {
    $akDlg = New-Object Windows.Forms.Form
    $akDlg.FormBorderStyle = 'None'; $akDlg.StartPosition = 'CenterParent'; $akDlg.Size = New-Object Drawing.Size(480, 270)
    $akDlg.BackColor = $sb; $akDlg.ShowInTaskbar = $false; $akDlg.TopMost = $true
    Rnd $akDlg 14
    $akDlg.Add_Paint({ param($s, $e)
            $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
            # Startbild (A7) als Banner oben im Dialog, abgedunkelt, damit Logo und Titel lesbar bleiben
            if (-not $script:siStartTried) {
                $script:siStartTried = $true
                $a7P = AssetPath 'A7'
                if ($a7P -and $script:imgOk) { try { $script:siStart = [Sip.Img]::Cover($a7P, 480, 92, 0.5, 0.5) } catch {} }
            }
            if ($script:siStart) {
                $g.DrawImage($script:siStart, 0, 0, 480, 92)
                $g.FillRectangle((New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(150, 20, 20, 22))), 0, 0, 480, 92)
                $g.FillRectangle((New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(90, 242, 140, 40))), 0, 90, 480, 2)
            }
            $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 0, 0, 480, 4)
            $g.DrawImage($logoImg, 24, 24, 40, 40)
            DT $g 'Kunde / Ticket' $fH ([Drawing.Color]::White) 76 22
            DT $g 'Für wen wird die Diagnose durchgeführt?' $fS ([Drawing.Color]::FromArgb(220, 220, 226)) 78 56
            DT $g 'Kundenname oder Ticketnummer (erscheint im Bericht und im Dateinamen):' $fN $tx 26 100
        })
    $akDlg.Add_MouseDown({ [void][Sip.Win]::ReleaseCapture(); [void][Sip.Win]::SendMessage($akDlg.Handle, 0xA1, 2, 0) })
    $akPw = New-Object Windows.Forms.Panel; $akPw.SetBounds(26, 130, 428, 40); $akPw.BackColor = $cOffBg; Rnd $akPw 8; $akDlg.Controls.Add($akPw)
    $akTb = New-Object Windows.Forms.TextBox; $akTb.SetBounds(14, 10, 400, 24); $akTb.BorderStyle = 'None'; $akTb.BackColor = $cOffBg; $akTb.ForeColor = $cTxt; $akTb.Font = $fN; $akTb.MaxLength = 80; $akPw.Controls.Add($akTb)
    $akTb.Text = $tkb.Text
    $akLb = New-Object Windows.Forms.Label; $akLb.Text = 'Ohne Angabe wird der Bericht ohne Kunde/Ticket erstellt.'; $akLb.SetBounds(26, 176, 428, 20); $akLb.BackColor = $sb; $akLb.ForeColor = $mu; $akLb.Font = $fS; $akDlg.Controls.Add($akLb)
    $akOk = New-Object Windows.Forms.Button; $akOk.Text = 'Übernehmen'; $akOk.SetBounds(226, 210, 120, 40); $akOk.FlatStyle = 'Flat'; $akOk.FlatAppearance.BorderSize = 0
    $akOk.BackColor = $or; $akOk.ForeColor = $cWhite; $akOk.Font = $fB; $akOk.Cursor = 'Hand'; $akOk.DialogResult = 'OK'; Rnd $akOk 10
    $akOk.Add_MouseEnter({ param($s, $e) $s.BackColor = $orH }); $akOk.Add_MouseLeave({ param($s, $e) $s.BackColor = $or })
    $akCn = New-Object Windows.Forms.Button; $akCn.Text = 'Ohne Angabe'; $akCn.SetBounds(354, 210, 100, 40); $akCn.FlatStyle = 'Flat'; $akCn.FlatAppearance.BorderColor = $cOffBd
    $akCn.BackColor = $cOffBg; $akCn.ForeColor = $cOffFg; $akCn.Font = $fN; $akCn.Cursor = 'Hand'; $akCn.DialogResult = 'Cancel'; Rnd $akCn 10
    $akCn.Add_MouseEnter({ param($s, $e) $s.BackColor = $cOffHv }); $akCn.Add_MouseLeave({ param($s, $e) $s.BackColor = $cOffBg })
    $akDlg.Controls.Add($akOk); $akDlg.Controls.Add($akCn); $akDlg.AcceptButton = $akOk; $akDlg.CancelButton = $akCn; $akDlg.ActiveControl = $akTb
    $akR = $akDlg.ShowDialog($form)
    if ($akR -eq 'OK') { $tkb.Text = $akTb.Text.Trim() }
    $akDlg.Dispose()
}
# Eingabedialog für den Webseiten-Test: Adressen durch Komma, Semikolon oder Leerzeichen getrennt; Rückgabe = Liste der Hostnamen (leer = Standardliste)
function AskSites {
    $wsDlg = New-Object Windows.Forms.Form
    $wsDlg.FormBorderStyle = 'None'; $wsDlg.StartPosition = 'CenterParent'; $wsDlg.Size = New-Object Drawing.Size(480, 270)
    $wsDlg.BackColor = $sb; $wsDlg.ShowInTaskbar = $false; $wsDlg.TopMost = $true
    Rnd $wsDlg 14
    $wsDlg.Add_Paint({ param($s, $e)
            $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
            $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 0, 0, 480, 4)
            $g.DrawImage($logoImg, 24, 24, 40, 40)
            DT $g 'Webseiten-Test' $fH $cTxt 76 22
            DT $g 'Welche Seiten lassen sich nicht öffnen?' $fS $mu 78 56
            DT $g 'Adressen (z. B. www.kunde.de), mehrere mit Komma getrennt:' $fN $tx 26 100
        })
    $wsDlg.Add_MouseDown({ [void][Sip.Win]::ReleaseCapture(); [void][Sip.Win]::SendMessage($wsDlg.Handle, 0xA1, 2, 0) })
    $wsPw = New-Object Windows.Forms.Panel; $wsPw.SetBounds(26, 130, 428, 40); $wsPw.BackColor = $cOffBg; Rnd $wsPw 8; $wsDlg.Controls.Add($wsPw)
    $wsTb = New-Object Windows.Forms.TextBox; $wsTb.SetBounds(14, 10, 400, 24); $wsTb.BorderStyle = 'None'; $wsTb.BackColor = $cOffBg; $wsTb.ForeColor = $cTxt; $wsTb.Font = $fN; $wsTb.MaxLength = 300; $wsPw.Controls.Add($wsTb)
    $wsLb = New-Object Windows.Forms.Label; $wsLb.Text = 'Leer lassen: Es wird eine Standardliste (Google, Microsoft, Sippicom) geprüft.'; $wsLb.SetBounds(26, 176, 428, 20); $wsLb.BackColor = $sb; $wsLb.ForeColor = $mu; $wsLb.Font = $fS; $wsDlg.Controls.Add($wsLb)
    $wsOk = New-Object Windows.Forms.Button; $wsOk.Text = 'Prüfen'; $wsOk.SetBounds(246, 210, 110, 40); $wsOk.FlatStyle = 'Flat'; $wsOk.FlatAppearance.BorderSize = 0
    $wsOk.BackColor = $or; $wsOk.ForeColor = $cWhite; $wsOk.Font = $fB; $wsOk.Cursor = 'Hand'; $wsOk.DialogResult = 'OK'; Rnd $wsOk 10
    $wsOk.Add_MouseEnter({ param($s, $e) $s.BackColor = $orH }); $wsOk.Add_MouseLeave({ param($s, $e) $s.BackColor = $or })
    $wsCn = New-Object Windows.Forms.Button; $wsCn.Text = 'Standardliste'; $wsCn.SetBounds(364, 210, 90, 40); $wsCn.FlatStyle = 'Flat'; $wsCn.FlatAppearance.BorderColor = $cOffBd
    $wsCn.BackColor = $cOffBg; $wsCn.ForeColor = $cOffFg; $wsCn.Font = $fS; $wsCn.Cursor = 'Hand'; $wsCn.DialogResult = 'Cancel'; Rnd $wsCn 10
    $wsCn.Add_MouseEnter({ param($s, $e) $s.BackColor = $cOffHv }); $wsCn.Add_MouseLeave({ param($s, $e) $s.BackColor = $cOffBg })
    $wsDlg.Controls.Add($wsOk); $wsDlg.Controls.Add($wsCn); $wsDlg.AcceptButton = $wsOk; $wsDlg.CancelButton = $wsCn; $wsDlg.ActiveControl = $wsTb
    $wsR = $wsDlg.ShowDialog($form); $wsList = @()
    if ($wsR -eq 'OK') {
        foreach ($wsP in ($wsTb.Text -split '[,;\s]+')) {
            $wsH1 = ($wsP.Trim() -replace '^https?://', '' -replace '[/:?#].*$', '')
            if ($wsH1 -match '^[A-Za-z0-9][A-Za-z0-9.\-]*\.[A-Za-z]{2,}$') { $wsList += $wsH1 }
        }
    }
    $wsDlg.Dispose(); return $wsList
}

# ---------- Kennwort-Export (nur Hilfe) ----------
# Der Export der Kennwörter wird im Browser selbst ausgelöst und mit der Windows-Abfrage bestätigt.
# Das Diagnosezentrum liest keine Kennwörter aus und fragt keine Zugangsdaten ab: Es öffnet nur die Browser-Seite
# und prüft anhand von Dateiname und Zeitpunkt, ob eine frisch gespeicherte Kennwort-CSV vorhanden ist (Inhalt wird nicht gelesen).
$script:pxMsg = ''; $script:pxOk = $false; $script:pxPath = $null; $script:pxDlg = $null; $script:pxBack = $null
function PxFind {
    $pxRoots = @("$env:USERPROFILE\Downloads", [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments'))
    $pxCut = (Get-Date).AddHours(-24)
    $pxHit = @()
    foreach ($pxR in $pxRoots) {
        if ($pxR -and (Test-Path -LiteralPath $pxR)) {
            $pxHit += @(Get-ChildItem -LiteralPath $pxR -Filter *.csv -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -gt $pxCut -and $_.Name -match '(?i)passw|kennw' })
        }
    }
    $pxHit | Sort-Object LastWriteTime -Descending | Select-Object -First 1
}
function PxMsg([string]$pmT, [bool]$pmOk) {
    $script:pxMsg = $pmT; $script:pxOk = $pmOk
    if ($script:pxDlg) { $script:pxDlg.Invalidate() }
}
function PxBtn($pbT, $pbX, $pbY, $pbW, $pbPrim, $pbAct) {
    $pbB = New-Object Windows.Forms.Button; $pbB.Text = $pbT; $pbB.SetBounds($pbX, $pbY, $pbW, 40); $pbB.FlatStyle = 'Flat'; $pbB.Cursor = 'Hand'; $pbB.Font = $fB
    if ($pbPrim) {
        $pbB.FlatAppearance.BorderSize = 0; $pbB.BackColor = $or; $pbB.ForeColor = $cWhite
        $pbB.Add_MouseEnter({ param($s, $e) $s.BackColor = $orH }); $pbB.Add_MouseLeave({ param($s, $e) $s.BackColor = $or })
    } else {
        $pbB.FlatAppearance.BorderColor = $cOffBd; $pbB.BackColor = $cOffBg; $pbB.ForeColor = $cOffFg
        $pbB.Add_MouseEnter({ param($s, $e) $s.BackColor = $cOffHv }); $pbB.Add_MouseLeave({ param($s, $e) $s.BackColor = $cOffBg })
    }
    Rnd $pbB 10; $pbB.Add_Click($pbAct); $pbB
}
function PwExportDialog([string]$pdBack) {
    $script:pxBack = $pdBack; $script:pxPath = $null
    PxMsg 'Noch nicht geprüft.' $false
    $pdDlg = New-Object Windows.Forms.Form
    $pdDlg.FormBorderStyle = 'None'; $pdDlg.StartPosition = 'CenterParent'; $pdDlg.Size = New-Object Drawing.Size(600, 490)
    $pdDlg.BackColor = $sb; $pdDlg.ShowInTaskbar = $true; $pdDlg.Text = 'Kennwörter exportieren'
    Rnd $pdDlg 14
    $script:pxDlg = $pdDlg
    $pdDlg.Add_Paint({ param($s, $e)
            $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
            $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 0, 0, 600, 4)
            $g.DrawImage($logoImg, 24, 20, 40, 40)
            DT $g 'Kennwörter exportieren (optional)' $fH $cTxt 76 18
            DT $g 'Der Export wird im Browser selbst bestätigt.' $fS $mu 78 48
            $pdTxt = "Aus Sicherheitsgründen kann der Kennwort-Export nur im Browser selbst bestätigt werden (Windows-Abfrage). Das Diagnosezentrum liest keine Kennwörter aus.`r`n`r`n1. Unten auf `"Edge öffnen`" oder `"Chrome öffnen`" klicken (öffnet die Kennwortseite).`r`n2. Dort `"Kennwörter exportieren`" wählen und die Windows-Abfrage bestätigen.`r`n3. Die CSV-Datei speichern (z. B. in Downloads).`r`n4. Hier auf `"Export prüfen`" klicken.`r`n`r`nDie CSV enthält Kennwörter im Klartext - nach dem Import bitte löschen."
            [Windows.Forms.TextRenderer]::DrawText($g, $pdTxt, $fN, (New-Object Drawing.Rectangle(26, 84, 548, 210)), $tx, 'WordBreak')
            $pdCol = $mu; if ($script:pxOk) { $pdCol = $gr }
            [Windows.Forms.TextRenderer]::DrawText($g, $script:pxMsg, $fB, (New-Object Drawing.Rectangle(26, 304, 548, 64)), $pdCol, 'WordBreak')
        })
    $pdDlg.Add_MouseDown({ [void][Sip.Win]::ReleaseCapture(); [void][Sip.Win]::SendMessage($script:pxDlg.Handle, 0xA1, 2, 0) })
    $pdEdge = PxBtn 'Edge öffnen' 26 376 170 $false {
        try { Start-Process -FilePath 'msedge.exe' -ArgumentList 'edge://settings/passwords' -ErrorAction Stop; PxMsg 'Edge-Kennwortseite geöffnet. Dort "Kennwörter exportieren" wählen, bestätigen und speichern; danach hier "Export prüfen".' $false }
        catch { PxMsg 'Edge konnte nicht gestartet werden (nicht installiert?).' $false }
    }
    $pdChr = PxBtn 'Chrome öffnen' 206 376 170 $false {
        try { Start-Process -FilePath 'chrome.exe' -ArgumentList 'chrome://password-manager/settings' -ErrorAction Stop; PxMsg 'Chrome-Kennwortseite geöffnet. Dort die Kennwörter exportieren, bestätigen und speichern; danach hier "Export prüfen".' $false }
        catch { PxMsg 'Chrome konnte nicht gestartet werden (nicht installiert?).' $false }
    }
    $pdChk = PxBtn 'Export prüfen' 386 376 188 $true {
        $pxF = PxFind
        if ($pxF) {
            $script:pxPath = $pxF.FullName
            PxMsg ("Export erfolgreich: " + $pxF.Name + " (" + [math]::Round($pxF.Length / 1KB) + " KB) in " + $pxF.DirectoryName + ". Mit `"Ordner öffnen`" anzeigen.") $true
        } else {
            $script:pxPath = $null
            PxMsg 'Keine frisch gespeicherte Kennwort-CSV gefunden (Downloads, Desktop, Dokumente; letzte 24 Stunden). Export im Browser abschließen und erneut prüfen. Sind keine Kennwörter gespeichert, "Keine Kennwörter vorhanden" wählen.' $false
        }
    }
    $pdNone = PxBtn 'Keine Kennwörter vorhanden' 26 428 250 $false {
        $script:pxPath = $null
        PxMsg 'Export erfolgreich: Es sind keine Kennwörter vorhanden, daher wird keine CSV benötigt. "Ordner öffnen" zeigt den Sicherungsordner.' $true
    }
    $pdOpen = PxBtn 'Ordner öffnen' 286 428 140 $false {
        if ($script:pxPath -and (Test-Path -LiteralPath $script:pxPath)) { Start-Process explorer.exe "/select,`"$($script:pxPath)`"" }
        elseif ($script:pxOk -and $script:pxBack -and (Test-Path -LiteralPath $script:pxBack)) { Start-Process explorer.exe "`"$($script:pxBack)`"" }
        else { PxMsg 'Bitte zuerst "Export prüfen" oder "Keine Kennwörter vorhanden" wählen.' $false }
    }
    $pdClose = PxBtn 'Schließen' 436 428 138 $false { }
    $pdClose.DialogResult = 'OK'
    foreach ($pdC in @($pdEdge, $pdChr, $pdChk, $pdNone, $pdOpen, $pdClose)) { $pdDlg.Controls.Add($pdC) }
    $pdDlg.CancelButton = $pdClose
    [void]$pdDlg.ShowDialog($form)
    $pdDlg.Dispose(); $script:pxDlg = $null
}

# ---------- Hilfefenster (Fragezeichen in der Titelleiste) ----------
# Links Navigation mit Themen, rechts Inhalt (Titel, Kurzbeschreibung, je Werkzeug Überschrift und Erklärung).
$script:hlSel = 0; $script:hlRb = $null; $script:hlNav = @(); $script:hlItems = @()
# Hinweis: Die Hilfetexte werden nicht mehr in einem RichTextBox angezeigt (HlAdd bleibt ungenutzt), sondern von HvLayout/Hv-Paint gezeichnet.
function HlAdd([string]$haT, $haF, $haC, [int]$haI) {
    $haRb = $script:hlRb
    $haRb.SelectionStart = $haRb.TextLength; $haRb.SelectionLength = 0
    $haRb.SelectionIndent = $haI; $haRb.SelectionColor = $haC; $haRb.SelectionFont = $haF
    $haRb.AppendText($haT)
}
# Hilfetext: selbst gezeichnete Eintragskarten mit eigener Bildlaufleiste (statt schreibgeschütztem Textfeld)
$script:hvView = $null; $script:hvL = @(); $script:hvH = 0; $script:hvY = 0; $script:hvDrag = $false; $script:hvDy = 0
$script:hvFlags = [Windows.Forms.TextFormatFlags]'WordBreak, NoPadding, NoPrefix, Top, Left'
function HvLayout {
    $hvCw = $script:hvView.Width - 20
    $hvPos = 0; $hvList = @()
    foreach ($hvEn in $script:hlItems[$script:hlSel].E) {
        $hvTh = [Windows.Forms.TextRenderer]::MeasureText([string]$hvEn.T, $fN, (New-Object Drawing.Size(($hvCw - 40), 100000)), $script:hvFlags).Height
        $hvHt = 12 + 20 + 4 + $hvTh + 14
        $hvList += , @{ Y = $hvPos; H = $hvHt; N = [string]$hvEn.N; T = [string]$hvEn.T }
        $hvPos += $hvHt + 10
    }
    $script:hvL = $hvList
    $script:hvH = [Math]::Max(0, $hvPos - 10)
}
function HvScroll([int]$hvNew) {
    $hvMax = [Math]::Max(0, $script:hvH - $script:hvView.Height)
    $script:hvY = [Math]::Min([Math]::Max(0, $hvNew), $hvMax)
    $script:hvView.Invalidate()
}
function HvThumb {
    $hvVh = $script:hvView.Height
    $hvTh = [Math]::Max(34, [int]($hvVh * $hvVh / [Math]::Max(1, $script:hvH)))
    $hvRng = [Math]::Max(1, $script:hvH - $hvVh)
    $hvTy = [int](($script:hvY / $hvRng) * ($hvVh - $hvTh))
    return @($hvTy, $hvTh)
}
function HlSelect([int]$hsI) {
    $script:hlSel = $hsI
    # Titel, Kurzbeschreibung und Illustration (B4) zeichnet die Inhaltskarte selbst
    if ($script:hvView) { HvLayout; $script:hvY = 0; $script:hvView.Invalidate() }
    foreach ($hsP in $script:hlNav) { $hsP.Invalidate() }
    if ($script:hlCardCtl) { $script:hlCardCtl.Invalidate() }
}
# Hilfe-Illustrationen (B4, 4 x 3): 0 Rakete, 1 Monitor mit Lupe, 2 Schild mit Warndreieck, 3 Bericht, 4 Schraubenschlüssel und Zahnrad, 5 Festplatte mit Pfeil,
# 6 Netzwerk, 7 Radar, 8 Schlüssel und Schild, 9 Briefumschlag, 10 Drucker, 11 Headset
# Reihenfolge der Hilfe-Themen: Erste Schritte, Gerät, Netzwerk, Arbeitsplatz, Reparatur Überblick, Windows, Netz und Drucker, Anmeldung und Outlook, Sicherung, Berichte und Support, Wichtige Hinweise
$script:hlImgMap = @(0, 1, 6, 9, 4, 4, 10, 8, 5, 11, 2)
$script:hlImgs = @{}
$script:hlCardCtl = $null
function HelpImg([int]$hiK) {
    if (-not $script:hlImgs.ContainsKey($hiK)) {
        $script:hlImgs[$hiK] = $null
        $hiF = AssetPath 'B4'
        if ($hiF -and $script:imgOk) { try { $script:hlImgs[$hiK] = [Sip.Img]::Cell($hiF, 4, 3, $hiK, 96, $true) } catch {} }
    }
    return $script:hlImgs[$hiK]
}
function ShowHelp {
    $script:hlItems = @(
        @{ H = 'Erste Schritte'; I = 'Kurzanleitung für das Diagnosezentrum.'; E = @(
                @{ N = 'Auswählen'; T = 'Kacheln links anklicken (oranger Punkt = ausgewählt). Der Link "alle" neben einer Überschrift wählt die ganze Gruppe, "Alle" und "Keine" den ganzen Reiter.' },
                @{ N = 'Starten'; T = '"Diagnose starten" führt alle ausgewählten Kacheln nacheinander aus. Das Protokoll unten zeigt jeden Schritt live.' },
                @{ N = 'Ergebnis'; T = 'Auffälligkeiten erscheinen oben in der Liste: orange = mittel, rot = schwerwiegend. Ohne Befund meldet das Programm "Keine Auffälligkeiten".' },
                @{ N = 'Reiter'; T = 'DIAGNOSEN liest nur Informationen aus. REPARATUR ändert das System oder legt Sicherungen an.' },
                @{ N = 'Titelleiste'; T = 'Hilfe (?), Hell/Dunkel-Umschalter, Desktop-Verknüpfung (Pin, erzeugt ein Sippicom-Symbol mit orangem Rahmen, auch auf schwarzem Hintergrund gut sichtbar), Minimieren und Schließen.' }) },
        @{ H = 'Gerät'; I = 'Reiter DIAGNOSEN: Zustand des Computers. Es wird nur gelesen, nichts verändert.'; E = @(
                @{ N = 'System und Datenträger'; T = 'Computername, Benutzer, Windows-Version, letzter Start, Arbeitsspeicher, freier Platz auf den Laufwerken, ausstehender Neustart und nicht laufende Dienste.' },
                @{ N = 'Hardware und Gesundheit'; T = 'Prozessor und Auslastung, speicherhungrige Prozesse, Zustand der Datenträger, Akku-Kapazität und Geräte mit Problemen im Geräte-Manager.' },
                @{ N = 'Sicherheit und Updates'; T = 'Virenschutz und Signaturen, Defender, Firewall-Profile und Benutzerkontensteuerung (UAC).' },
                @{ N = 'Windows-Updates'; T = 'Windows-Version, letztes installiertes Update, Update-Dienst, fehlgeschlagene Installationen und Richtlinien.' },
                @{ N = 'Backup und Verschlüsselung'; T = 'Schattenkopien, VSS, Dateiversionen, OneDrive, BitLocker und erkannte Sicherungssoftware.' },
                @{ N = 'Ereignisse'; T = 'Fehler der letzten 3 Tage aus System- und Anwendungsprotokoll, Häufungen, abgestürzte Dienste, unerwartete Neustarts und Datenträgerfehler.' }) },
        @{ H = 'Netzwerk'; I = 'Reiter DIAGNOSEN: Verbindung, WLAN, VPN, Proxy und Uhrzeit.'; E = @(
                @{ N = 'Netzwerk'; T = 'IP-Konfiguration, Ping zum Gateway, DNS-Server, APIPA-Adresse (kein DHCP) und Erreichbarkeit wichtiger Internetziele.' },
                @{ N = 'WLAN'; T = 'Verbindungsstatus, Signalstärke, Kanal, Funktyp und Übertragungsrate des WLAN-Adapters.' },
                @{ N = 'VPN (Cisco)'; T = 'Cisco Secure Client bzw. AnyConnect, Dienste, Adapter, Gateway-Erreichbarkeit und VPN-Ereignisse.' },
                @{ N = 'Proxy'; T = 'Benutzer-Proxy, PAC-Datei, WinHTTP-Proxy und Umgebungsvariablen.' },
                @{ N = 'Uhrzeit'; T = 'Status des Windows-Zeitdienstes, Zeitquelle und Abweichung zu Microsoft (wichtig für Anmeldungen).' },
                @{ N = 'Netz-Tools'; T = 'Gateway-Test (8 Pings mit Verlust und Antwortzeit), Trace ins Internet (8 Sprünge), Speedtest (Download von ca. 25 MB) und Kurzprüfung des Cisco-VPN-Adapters. Für Subnetz-Scan, DNS-Fingerprinting und SSL/TLS-Prüfung gibt es PingMeMaybe in den Siptools.' }) },
        @{ H = 'Arbeitsplatz'; I = 'Reiter DIAGNOSEN: Microsoft 365, Outlook, Teams und Drucker.'; E = @(
                @{ N = 'Microsoft 365'; T = 'Entra-ID- und Domänenstatus, PRT, TPM, Zeitabweichung, Anmelde-Endpunkte und Fehler im AAD-Protokoll.' },
                @{ N = 'Outlook/Teams'; T = 'Version der Microsoft-365-Apps, neues Outlook, Teams, WebView2, Add-ins, Outlook-Profile, OST/PST-Größen und Abstürze.' },
                @{ N = 'Drucker'; T = 'Spooler, Drucker und Status, Warteschlange, Druckerports und Druckdienst-Fehler.' },
                @{ N = 'Mitschnitt (Gruppe Werkzeuge)'; T = 'Zeichnet 1 Minute lang den Netzwerkverkehr an den Netzwerkkarten auf, und zwar ganze Pakete (Ringpuffer 1 GB, bei wenig freiem Platz kleiner). Aufgenommen wird mit dem in Windows enthaltenen pktmon (Ergebnis .pcapng); fehlt es, nimmt das Programm netsh trace und wandelt die .etl mit einem eingebauten Wandler in .pcapng um (mit Richtung und Prozess je Paket). Es ist keine Zusatzsoftware nötig: weder Wireshark noch TShark noch Npcap. Vorher erscheint eine Bestätigung; Administratorrechte sind erforderlich. Ergebnis im Ordner C:\SippicomInstall\mitschnitt\Mitschnitt_...: .pcapng, ZIP und eine Analyse-Datei (Überblick, Protokolle, Dienste nach Port, größte Verbindungen, Neuübertragungen, TCP-Resets, DNS-Fehlschläge, ICMP). Die Auswertung liest die Datei selbst; Neuübertragungen werden aus den TCP-Folgenummern geschätzt, verschlüsselte Inhalte werden nicht gelesen. Das Protokoll zeigt außerdem Neuübertragungen, Resets, DNS-Fehler und ICMP als Auffälligkeiten. Die Analyse-Datei wird in die Support-ZIP aufgenommen, der Mitschnitt selbst nicht (vertrauliche Daten). Während der Aufnahme erscheint rechts neben der Statuszeile der Knopf "Mitschnitt stoppen": Er beendet den Mitschnitt vorzeitig, Umwandlung und Auswertung folgen trotzdem. Bei "Alle" im Reiter DIAGNOSEN wird die Kachel mitgewählt (mit Bestätigung vor dem Start).' },
                @{ N = 'Zertifikate'; T = 'Zertifikate im persönlichen Speicher (abgelaufen oder in 30 Tagen ablaufend), Kennwortablauf des angemeldeten Kontos (Domäne oder lokal) und BitLocker-Status (mit Administratorrechten).' }) },
        @{ H = 'Reparatur Überblick'; I = 'Reiter REPARATUR: Diese Werkzeuge ändern das System oder legen Sicherungen an.'; E = @(
                @{ N = 'Bestätigung'; T = 'Reparaturen werden vor dem Start in einem Dialog bestätigt. Sicherungen ändern nichts und starten ohne Rückfrage.' },
                @{ N = 'Administratorrechte'; T = 'Die meisten Reparaturen brauchen Administratorrechte: Programm per Rechtsklick "Als Administrator ausführen" starten. Ohne Rechte werden sie übersprungen und als Auffälligkeit gemeldet.' },
                @{ N = 'Auswahl'; T = '"Alle" im Reparatur-Reiter wählt auch die Sicherungen aus. Die Bestätigung erscheint dann für die verändernden Werkzeuge.' },
                @{ N = 'Live-Anzeige'; T = 'Lange Werkzeuge (SFC, DISM, CHKDSK) zeigen im Protokoll eine orange Zeile mit Laufzeit. Das Fenster dabei nicht schließen.' },
                @{ N = 'Wiederherstellungspunkt'; T = 'Vor SFC, DISM und Update-Reset legt das Programm automatisch einen Windows-Wiederherstellungspunkt an (einmal pro Lauf). Voraussetzung: Computerschutz ist aktiviert; Windows erlaubt standardmäßig nur einen Punkt in 24 Stunden. Ohne Punkt läuft die Reparatur trotzdem weiter, das Protokoll nennt den Grund.' }) },
        @{ H = 'Windows'; I = 'Reparatur: Systemdateien, Windows-Abbild, Updates und Aufräumen.'; E = @(
                @{ N = 'SFC'; T = 'Prüft alle geschützten Systemdateien und repariert sie (sfc /scannow).' },
                @{ N = 'DISM'; T = 'Repariert das Windows-Abbild (RestoreHealth). Empfohlene Reihenfolge bei Systemfehlern: erst DISM, danach SFC.' },
                @{ N = 'CHKDSK'; T = 'Prüft das Dateisystem nur lesend, es wird nichts repariert.' },
                @{ N = 'Update-Reset'; T = 'Setzt die Windows-Update-Komponenten zurück (SoftwareDistribution und catroot2 werden umbenannt). Danach neu starten.' },
                @{ N = 'Temp bereinigen'; T = 'Löscht Temp-Dateien (älter als 1 Tag) und leert den Papierkorb; mit Administratorrechten auch C:\Windows\Temp.' },
                @{ N = 'Store-Apps'; T = 'Registriert die Microsoft-Store-Apps des angemeldeten Benutzers neu (hilft bei defektem Startmenü, Einstellungen oder Store).' }) },
        @{ H = 'Netz und Drucker'; I = 'Reparatur: Namensauflösung, Druckwarteschlange, DHCP und Uhrzeit.'; E = @(
                @{ N = 'DNS leeren'; T = 'Leert den DNS-Cache und registriert den Rechner neu im DNS (hilft bei Problemen mit der Namensauflösung).' },
                @{ N = 'Spooler leeren'; T = 'Stoppt den Druckspooler, löscht hängende Druckaufträge und startet ihn wieder.' },
                @{ N = 'DHCP erneuern'; T = 'Gibt die IP-Adresse frei und fordert eine neue an; zeigt danach IP, Gateway und DHCP-Server. Achtung: Die Verbindung wird kurz getrennt (RDP kann abbrechen).' },
                @{ N = 'Zeit-Sync'; T = 'Startet den Zeitdienst und synchronisiert die Uhr neu; zeigt Zeitquelle und Abweichung zu Microsoft.' }) },
        @{ H = 'Anmeldung und Outlook'; I = 'Reparatur: Office-Anmeldung und Outlook. Als betroffener Benutzer starten.'; E = @(
                @{ N = 'OneAuth sichern'; T = 'Sichert OneAuth, IdentityCache, die Office-Identität und die Namen der Office-Anmeldeinformationen (keine Kennwörter).' },
                @{ N = 'OneAuth-Reset'; T = 'Legt zuerst eine Sicherung an und setzt dann die Office-Anmeldung zurück. Office, Teams und OneDrive müssen geschlossen sein; danach neu anmelden.' },
                @{ N = 'Outlook sichern'; T = 'Sichert Profile (Registrierung), Signaturen, Vorlagen und Autovervollständigung; OST- und PST-Dateien werden nur aufgelistet.' },
                @{ N = 'OST neu aufbauen'; T = 'Benennt die OST-Dateien um (.bak); Outlook lädt das Postfach beim nächsten Start neu. Outlook muss geschlossen sein, PST-Dateien bleiben unberührt.' }) },
        @{ H = 'Sicherung'; I = 'Daten sichern und wiederherstellen. Ziel: C:\SippicomInstall\backup.'; E = @(
                @{ N = 'WLAN sichern'; T = 'Exportiert alle gespeicherten WLAN-Profile. Mit Administratorrechten werden die Kennwörter im Klartext mitgesichert.' },
                @{ N = 'WLAN-Restore'; T = 'Spielt die neueste WLAN-Sicherung wieder ein (Administratorrechte nötig, mit Bestätigung).' },
                @{ N = 'Browser sichern'; T = 'Sichert Favoriten und Kennwortdateien von Edge, Chrome und Firefox. Die Favoritenleiste wird zusätzlich als HTML-Datei im Ordner "Favoriten" abgelegt; sie lässt sich in jedem Browser über "Favoriten importieren" einlesen. Danach öffnet sich ein Dialog für den optionalen Kennwort-Export als CSV: Den Export bestätigt man selbst im Browser (Windows-Abfrage); "Export prüfen" findet die gespeicherte CSV, "Ordner öffnen" zeigt sie an. Bei Benutzern ohne gespeicherte Kennwörter "Keine Kennwörter vorhanden" wählen. Die kopierten Kennwortdateien sind an Benutzer und PC gebunden (Edge, Chrome). Browser vorher schließen.' },
                @{ N = 'Laufwerke sichern'; T = 'Sichert dauerhafte Netzlaufwerke und Netzwerkdrucker und erstellt eine Wiederherstellen.cmd (ohne Kennwörter).' }) },
        @{ H = 'Berichte und Support'; I = 'Ergebnis weitergeben und den Support erreichen.'; E = @(
                @{ N = 'Ordner öffnen, Bericht öffnen'; T = 'Öffnet den Berichtsordner bzw. den HTML-Bericht der letzten Diagnose (C:\SippicomInstall\diagnose).' },
                @{ N = 'Kopieren'; T = 'Legt den Bericht als Text in die Zwischenablage.' },
                @{ N = 'Support-ZIP'; T = 'Packt TXT- und HTML-Bericht für den Support zusammen. Die Sicherungsordner sind nicht enthalten.' },
                @{ N = 'E-Mail an den Support'; T = "Die Adresse unten links öffnet eine vorbereitete E-Mail an $mail (mit klassischem Outlook samt Anhang)." },
                @{ N = 'Kunde / Ticket'; T = 'Das Feld oben rechts wird in Bericht, Dateiname und E-Mail-Betreff übernommen.' },
                @{ N = 'Schnell-Check (Blitz oben)'; T = 'Prüft nur System und Datenträger, Netzwerk, Windows-Updates sowie Sicherheit, meist in unter einer Minute. Bisherige Auswahlen werden dafür zurückgesetzt.' },
                @{ N = 'Kundenbericht (Dokument oben)'; T = 'Erstellt aus dem letzten Lauf eine leicht verständliche, druckbare Zusammenfassung ohne Protokoll. Als PDF speichern: im Browser Strg+P und "Als PDF speichern" wählen.' },
                @{ N = 'Vergleich mit dem letzten Lauf'; T = 'Jeder Lauf wird je PC gespeichert (Verlauf_<PC>.json im Berichtsordner, letzte 20 Läufe). Der Bericht zeigt neue und behobene Auffälligkeiten sowie Änderungen bei freiem Platz, Updates und Windows-Build; verglichen werden nur Bereiche, die in beiden Läufen geprüft wurden.' },
                @{ N = 'Version und Update-Hinweis'; T = 'Die Version steht unten im Fenster und im Bericht. Liegt unter der hinterlegten Adresse eine neuere Versionsnummer, erscheint beim Start ein Hinweis.' }) },
        @{ H = 'Wichtige Hinweise'; I = 'Bitte beachten.'; E = @(
                @{ N = 'Sicherungsordner'; T = 'Alle Sicherungen liegen unter C:\SippicomInstall\backup (je Werkzeug ein Ordner mit Rechnername, Benutzer und Zeitstempel). Der Zugriff ist auf Benutzer, Administratoren und System beschränkt.' },
                @{ N = 'Vertrauliche Daten'; T = 'Die Ordner können WLAN- und Browser-Kennwörter enthalten. Eine exportierte Kennwort-CSV enthält die Kennwörter im Klartext. Nach Gebrauch sicher löschen oder verschlüsselt aufbewahren.' },
                @{ N = 'Update des Programms'; T = 'Nach einem Update den Pin-Button (Desktop-Verknüpfung) erneut klicken, sonst startet die Verknüpfung weiter die alte Kopie. Eine alte, von Hand angelegte Verknüpfung vorher löschen, sonst bleibt das Standardsymbol.' },
                @{ N = 'Support'; T = "$cpy  |  Tel. $telefon  |  $mail" }) }
    )
    $hlDlg = New-Object Windows.Forms.Form
    $hlDlg.FormBorderStyle = 'None'; $hlDlg.StartPosition = 'CenterParent'; $hlDlg.Size = New-Object Drawing.Size(900, 650)
    $hlDlg.BackColor = $sb; $hlDlg.ShowInTaskbar = $false; $hlDlg.TopMost = $true
    Rnd $hlDlg 14
    $hlDlg.Add_Paint({ param($s, $e)
            $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
            $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 0, 0, 900, 4)
            $g.DrawImage($logoImg, 26, 20, 44, 44)
            DT $g 'Hilfe und Erklärungen' $fH $cTxt 82 18
            DT $g 'Was die einzelnen Kategorien und Werkzeuge bewirken' $fS $mu 84 48
            $g.FillRectangle((New-Object Drawing.SolidBrush($script:sepCol)), 26, 80, 848, 1)
            DT $g "$cpy  |  Tel. $telefon  |  $mail" $fS $mu 26 604
        })
    $hlDlg.Add_MouseDown({ [void][Sip.Win]::ReleaseCapture(); [void][Sip.Win]::SendMessage($hlDlg.Handle, 0xA1, 2, 0) })
    # Navigation links
    $script:hlNav = @()
    for ($hlK = 0; $hlK -lt $script:hlItems.Count; $hlK++) {
        $hlP = New-Object Windows.Forms.Panel; $hlP.SetBounds(22, (96 + 38 * $hlK), 206, 34); $hlP.BackColor = $sb; $hlP.Cursor = 'Hand'; DB $hlP
        $hlP.Tag = @{ I = $hlK; T = $script:hlItems[$hlK].H; Hot = $false }
        $hlP.Add_MouseEnter({ param($s, $e) $s.Tag.Hot = $true; $s.Invalidate() })
        $hlP.Add_MouseLeave({ param($s, $e) $s.Tag.Hot = $false; $s.Invalidate() })
        $hlP.Add_Click({ param($s, $e) HlSelect $s.Tag.I })
        $hlP.Add_Paint({ param($s, $e)
                $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
                $t = $s.Tag; $r = New-Object Drawing.Rectangle(1, 1, ($s.Width - 3), ($s.Height - 3))
                $sel = ($script:hlSel -eq $t.I)
                if ($sel) { $g.FillPath((New-Object Drawing.SolidBrush($script:tileHot)), (RR $r 8)); $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 1, 8, 4, ($s.Height - 16)) }
                elseif ($t.Hot) { $g.FillPath((New-Object Drawing.SolidBrush($script:cOffBg)), (RR $r 8)) }
                if ($sel) { DT $g $t.T $fSB $cTxt 18 ([int]($s.Height / 2 - 9)) } else { DT $g $t.T $fN $mu 18 ([int]($s.Height / 2 - 9)) }
            })
        Rnd $hlP 8; $hlDlg.Controls.Add($hlP); $script:hlNav += $hlP
    }
    # Inhaltskarte rechts
    $hlCard = New-Object Windows.Forms.Panel; $hlCard.SetBounds(248, 96, 626, 490); $hlCard.BackColor = $pn; DB $hlCard
    $hlCard.Add_Paint({ param($s, $e)
            $g = $e.Graphics
            $tl = New-Object Drawing.Drawing2D.LinearGradientBrush((New-Object Drawing.Rectangle(0, 0, $s.Width, 3)), [Drawing.Color]::FromArgb(230, 242, 140, 40), [Drawing.Color]::FromArgb(0, 242, 140, 40), [single]0)
            $g.FillRectangle($tl, 0, 0, $s.Width, 3); $tl.Dispose()
            $hcIt = $script:hlItems[$script:hlSel]
            $g.SmoothingMode = 'AntiAlias'; $g.InterpolationMode = 'HighQualityBicubic'
            $hcX = 22
            $hcImg = HelpImg ($script:hlImgMap[$script:hlSel])
            if ($hcImg) { $g.DrawImage($hcImg, 22, 14, 64, 64); $hcX = 100 }
            DT $g $hcIt.H $fH $or $hcX 18
            DT $g $hcIt.I $fN $mu $hcX 52
        })
    Rnd $hlCard 12; $hlDlg.Controls.Add($hlCard); $script:hlCardCtl = $hlCard
    $script:hvView = New-Object Windows.Forms.Panel; $script:hvView.SetBounds(14, 90, 598, 388); $script:hvView.BackColor = $pn; DB $script:hvView
    $script:hvY = 0; $script:hvDrag = $false
    $script:hvView.Add_Paint({ param($s, $e)
            $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
            $hvCw = $s.Width - 20
            $hvBr = New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(24, $cTxt.R, $cTxt.G, $cTxt.B))
            $hvOr = New-Object Drawing.SolidBrush($or)
            foreach ($hvIt in $script:hvL) {
                $hvTop = [int]($hvIt.Y - $script:hvY)
                if (($hvTop + $hvIt.H) -lt 0 -or $hvTop -gt $s.Height) { continue }
                $hvRc = New-Object Drawing.Rectangle(0, $hvTop, $hvCw, $hvIt.H)
                $g.FillPath($hvBr, (RR $hvRc 10))
                $g.FillRectangle($hvOr, 0, ($hvTop + 12), 4, ($hvIt.H - 24))
                [Windows.Forms.TextRenderer]::DrawText($g, $hvIt.N, $fB, (New-Object Drawing.Rectangle(20, ($hvTop + 12), ($hvCw - 40), 20)), $cTxt, $script:hvFlags)
                [Windows.Forms.TextRenderer]::DrawText($g, $hvIt.T, $fN, (New-Object Drawing.Rectangle(20, ($hvTop + 36), ($hvCw - 40), ($hvIt.H - 36))), $mu, $script:hvFlags)
            }
            if ($script:hvH -gt $s.Height) {
                $hvTb = HvThumb
                $hvTr = New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(28, $cTxt.R, $cTxt.G, $cTxt.B))
                $g.FillRectangle($hvTr, ($s.Width - 8), 0, 4, $s.Height); $hvTr.Dispose()
                $g.FillRectangle($hvOr, ($s.Width - 8), $hvTb[0], 4, $hvTb[1])
            }
            $hvBr.Dispose(); $hvOr.Dispose()
        })
    $script:hvView.Add_MouseEnter({ param($s, $e) $s.Focus() })
    $script:hvView.Add_MouseWheel({ param($s, $e) HvScroll ($script:hvY - [int]($e.Delta / 120) * 54) })
    $script:hvView.Add_MouseDown({ param($s, $e)
            if ($script:hvH -le $s.Height) { return }
            if ($e.X -ge ($s.Width - 18)) {
                $hvTb = HvThumb
                if ($e.Y -ge $hvTb[0] -and $e.Y -le ($hvTb[0] + $hvTb[1])) { $script:hvDrag = $true; $script:hvDy = $e.Y - $hvTb[0] }
                elseif ($e.Y -lt $hvTb[0]) { HvScroll ($script:hvY - $s.Height + 40) }
                else { HvScroll ($script:hvY + $s.Height - 40) }
            }
        })
    $script:hvView.Add_MouseMove({ param($s, $e)
            if ($script:hvDrag) {
                $hvTb = HvThumb; $hvRg = $s.Height - $hvTb[1]
                if ($hvRg -gt 0) { HvScroll ([int]((($e.Y - $script:hvDy) / $hvRg) * ($script:hvH - $s.Height))) }
            }
        })
    $script:hvView.Add_MouseUp({ param($s, $e) $script:hvDrag = $false })
    $hlCard.Controls.Add($script:hvView)
    $hlBtn = New-Object Windows.Forms.Button; $hlBtn.Text = 'Schließen'; $hlBtn.SetBounds(764, 596, 110, 36); $hlBtn.FlatStyle = 'Flat'; $hlBtn.FlatAppearance.BorderSize = 0
    $hlBtn.BackColor = $or; $hlBtn.ForeColor = $cWhite; $hlBtn.Font = $fB; $hlBtn.Cursor = 'Hand'; $hlBtn.DialogResult = 'OK'; Rnd $hlBtn 10
    $hlBtn.Add_MouseEnter({ param($s, $e) $s.BackColor = $orH }); $hlBtn.Add_MouseLeave({ param($s, $e) $s.BackColor = $or })
    $hlDlg.Controls.Add($hlBtn); $hlDlg.AcceptButton = $hlBtn; $hlDlg.CancelButton = $hlBtn
    $hlStart = 0; if ($script:tab -eq 'rep') { $hlStart = 4 }
    HlSelect $hlStart
    [void]$hlDlg.ShowDialog($form); $script:hlCardCtl = $null; $script:hvView = $null; $hlDlg.Dispose()
}

# ---------- Hilfsfunktionen für Prüfungen ----------
# ACHTUNG: Funktionsnamen dürfen nicht wie PowerShell-Aliase heißen (nv, sc, ft, fl, fw ...).
# Auffälligkeit: F 'Befund' 'Empfehlung'   (orange, MITTEL)
#                FS 'Befund' 'Empfehlung'  (rot, HOCH / schwerwiegend)
#                FLow 'Befund' 'Empfehlung' (orange im Programm, NIEDRIG blau im Bericht)
function F { "[!] $($args[0])||$($args[1])" }
function FS { "[!!] $($args[0])||$($args[1])" }
function FLow { "[~] $($args[0])||$($args[1])" }
function KV {
    $k = $args[0]; $v = ''
    if ($args.Count -gt 1) { $v = ($args[1..($args.Count - 1)] | ForEach-Object { "$_" }) -join ' ' }
    '{0,-15}: {1}' -f $k, $v
}
function OKF($b) { if ($b) { 'OK' } else { 'FEHLER' } }
function JN($b) { if ($b) { 'ja' } else { 'nein' } }
function Tcp($h, $p, $ms = 2500) {
    try { $c = New-Object Net.Sockets.TcpClient; $a = $c.BeginConnect($h, $p, $null, $null)
        $ok = $a.AsyncWaitHandle.WaitOne($ms)
        if ($ok -and $c.Connected) { $c.Close(); return $true }; $c.Close(); return $false } catch { return $false }
}
function Ev($log, $days, $lvl, $id) {
    $hh = @{ LogName = $log; StartTime = (Get-Date).AddDays(-$days) }
    if ($lvl) { $hh.Level = $lvl }; if ($id) { $hh.Id = $id }
    try { @(Get-WinEvent -FilterHashtable $hh -MaxEvents 3000 -ErrorAction Stop) } catch { @() }
}
function Cut($t, $n) { $t = "$t" -replace '\s+', ' '; if ($t.Length -gt $n) { $t.Substring(0, $n) + '...' } else { $t } }
function FirstLine($m) { (("$m" -split "`r?`n") | Where-Object { $_ -match '\S' } | Select-Object -First 1) }
function EvTop($ev, $n = 4) {
    foreach ($g in @($ev | Group-Object { "ID $($_.Id) | " + (FirstLine $_.Message) } | Sort-Object Count -Descending | Select-Object -First $n)) {
        '  {0}x | {1}' -f $g.Count, (Cut $g.Name 110)
    }
}
function NVal($lines, $re) { $l = $lines | Where-Object { $_ -match $re } | Select-Object -First 1; if ($l) { ($l -split ':', 2)[1].Trim() } }
function PendReboot {
    (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') -or
    (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')
}
function CertIssuer($h) {
    try {
        $c = New-Object Net.Sockets.TcpClient; $a = $c.BeginConnect($h, 443, $null, $null)
        if (-not $a.AsyncWaitHandle.WaitOne(3000)) { $c.Close(); return $null }
        $ss = New-Object Net.Security.SslStream($c.GetStream(), $false, { $true })
        $ss.AuthenticateAsClient($h)
        $iss = (New-Object Security.Cryptography.X509Certificates.X509Certificate2($ss.RemoteCertificate)).Issuer
        $c.Close(); return $iss
    } catch { return $null }
}
function MsOffset {
    $resp = $null
    try { $r = [Net.HttpWebRequest]::Create('https://login.microsoftonline.com'); $r.Method = 'HEAD'; $r.Timeout = 5000; $resp = $r.GetResponse() }
    catch { $ex = $_.Exception; if ($ex.InnerException) { $ex = $ex.InnerException }; $resp = $ex.Response }
    if ($resp) { try { $d = [DateTimeOffset]::Parse($resp.Headers['Date'], [Globalization.CultureInfo]::InvariantCulture); $resp.Close(); return [int][math]::Abs(([DateTimeOffset]::UtcNow - $d).TotalSeconds) } catch {} }
    return $null
}
# Externes Programm starten, Ausgabe einsammeln und dabei die Oberfläche bedienbar halten (für SFC, DISM, CHKDSK ...).
# Während der Laufzeit zeigt eine orange Live-Zeile im Protokoll (drehendes Zeichen + Laufzeit), dass das Werkzeug arbeitet.
# Optional $rtTotal: geplante Laufzeit in Sekunden (Anzeige "von N s"; hängt das Programm länger als N + 25 s, wird es beendet).
function RunTool([string]$rtLabel, [string]$rtExe, [string]$rtArgs, $rtEnc, [int]$rtTotal = 0) {
    $rtPsi = New-Object Diagnostics.ProcessStartInfo
    $rtPsi.FileName = $rtExe; $rtPsi.Arguments = $rtArgs; $rtPsi.UseShellExecute = $false
    $rtPsi.RedirectStandardOutput = $true; $rtPsi.RedirectStandardError = $true; $rtPsi.CreateNoWindow = $true
    $rtPsi.StandardOutputEncoding = $rtEnc; $rtPsi.StandardErrorEncoding = $rtEnc
    $script:toolCode = -1
    try { $rtP = [Diagnostics.Process]::Start($rtPsi) } catch { return @("FEHLER: $rtExe konnte nicht gestartet werden ($($_.Exception.Message))") }
    $rtO = $rtP.StandardOutput.ReadToEndAsync(); $rtE = $rtP.StandardError.ReadToEndAsync()
    $rtSw = [Diagnostics.Stopwatch]::StartNew()
    # Live-Zeile: beginnt mit einer eindeutigen Markierung (») und wird am Ende anhand dieser Markierung sicher entfernt.
    # Das Protokollfeld ist schreibgeschützt; für die Live-Zeile wird der Schutz kurz aufgehoben.
    $rtMk = "  $([char]0xBB) "
    $rtRo = $box.ReadOnly; $box.ReadOnly = $false
    if ($box.TextLength -gt 0 -and $box.Text[$box.TextLength - 1] -ne "`n") { $box.SelectionStart = $box.TextLength; $box.SelectionLength = 0; $box.AppendText("`n") }
    $rtPos = $box.TextLength; $rtSpin = @('|', '/', '-', '\'); $rtI = 0
    while (-not $rtP.HasExited) {
        $rtI++; $rtEl = Dur $rtSw.Elapsed; $rtOf = ''
        if ($rtTotal -gt 0) {
            $rtOf = " (geplant $rtTotal s)"
            if ($rtSw.Elapsed.TotalSeconds -gt ($rtTotal + 25)) { try { $rtP.Kill() } catch {} }
        }
        $rtLine = "$rtMk$($rtSpin[$rtI % 4])  $rtLabel läuft seit $rtEl$rtOf - bitte warten, Fenster nicht schließen ..."
        Msg "$rtLabel läuft seit $rtEl$rtOf - bitte warten ..." $null
        $hdr.Tag.Sub = "$rtLabel läuft seit $rtEl$rtOf ..."; $hdr.Invalidate()
        if ($rtPos -gt $box.TextLength) { $rtPos = $box.TextLength }
        $box.Select($rtPos, ($box.TextLength - $rtPos)); $box.SelectionColor = $or; $box.SelectionFont = $fM; $box.SelectedText = $rtLine
        [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 250
    }
    # Live-Zeile entfernen: erst über die Markierung, sonst über die gemerkte Startposition
    $rtIdx = $box.Text.LastIndexOf($rtMk)
    if ($rtIdx -ge 0) { $rtPos = $rtIdx }
    if ($rtPos -gt $box.TextLength) { $rtPos = $box.TextLength }
    $box.Select($rtPos, ($box.TextLength - $rtPos)); $box.SelectedText = ''; $box.SelectionStart = $box.TextLength
    if ($box.TextLength -gt 0 -and $box.Text[$box.TextLength - 1] -ne "`n") { $box.SelectionStart = $box.TextLength; $box.SelectionLength = 0; $box.AppendText("`n") }
    $box.ReadOnly = $rtRo
    $rtP.WaitForExit(); $script:toolCode = $rtP.ExitCode
    $rtTxt = "$($rtO.Result)`n$($rtE.Result)"
    @($rtTxt -split '[\r\n]+' | ForEach-Object { ($_ -replace "`0", '').TrimEnd() } | Where-Object { $_ -match '\S' -and $_ -notmatch '^\s*\[[= ]*[\d\.,]*%?[= ]*\]' -and $_ -notmatch '\d+\s*%\s*(abgeschlossen|complete)|Überprüfung \d+|Verification \d+' })
}
function NeedAdmin($na) {
    'Hinweis: Für dieses Werkzeug sind Administratorrechte erforderlich.'
    F "Reparatur '$na' übersprungen: keine Administratorrechte." 'Diagnosezentrum per Rechtsklick als Administrator starten und das Werkzeug erneut ausführen.'
}

# ---------- OneAuth / Anmeldeinformationen (Office, Teams, OneDrive) ----------
# Wirkt immer auf das Profil des angemeldeten Benutzers (nicht als fremder Administrator starten).
$script:oaDir = $null
$script:oaCredRe = '^(MicrosoftOffice1[56]_Data:|Microsoft_OC1|virtualapp/didlogical|SSO_POP_Device|OneDrive Cached Credential)'
function OaFolders {
    @(
        @{ N = 'OneAuth'; P = "$env:LOCALAPPDATA\Microsoft\OneAuth" },
        @{ N = 'IdentityCache'; P = "$env:LOCALAPPDATA\Microsoft\IdentityCache" }
    )
}
# Liefert aus der cmdkey-Ausgabe die Namen der Office-/OneDrive-Anmeldeinformationen
function OaCredNames($oaLines) {
    foreach ($oaX in $oaLines) {
        if ($oaX -match '(?i)^\s*(Ziel|Target)\s*:\s*(?:\S*?:)?target=(.+?)\s*$') {
            $oaN = $Matches[2]
            if ($oaN -match $script:oaCredRe) { $oaN }
        }
    }
}
# Sichert OneAuth, IdentityCache, Office-Identität (Registry) und die Namensliste der Anmeldeinformationen (keine Kennwörter)
function OaBackup {
    $script:oaDir = $null
    $oaTs = Get-Date -Format 'yyyyMMdd_HHmmss'
    $oaRoot = "C:\SippicomInstall\backup\OneAuth_$($env:COMPUTERNAME)_$($env:USERNAME)_$oaTs"
    try { New-Item -ItemType Directory -Path $oaRoot -Force -ErrorAction Stop | Out-Null } catch { KV 'Sicherung' "FEHLER - Zielordner nicht anlegbar ($($_.Exception.Message))"; return }
    $oaBad = 0
    foreach ($oaF in OaFolders) {
        if (Test-Path $oaF.P) {
            [void](RunTool 'Sicherung' "$env:windir\System32\robocopy.exe" "`"$($oaF.P)`" `"$oaRoot\$($oaF.N)`" /E /R:0 /W:0 /NFL /NDL /NJH /NJS /NP" $script:oemEnc)
            $oaSz = [math]::Round((Get-ChildItem "$oaRoot\$($oaF.N)" -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1KB)
            if ($script:toolCode -lt 8) { KV ($oaF.N) "gesichert (OK, $oaSz KB)" } else { $oaBad++; KV ($oaF.N) "FEHLER (robocopy Code $($script:toolCode))" }
        } else { KV ($oaF.N) 'nicht vorhanden' }
    }
    [void](RunTool 'Sicherung' "$env:windir\System32\reg.exe" "export `"HKCU\Software\Microsoft\Office\16.0\Common\Identity`" `"$oaRoot\Office_Identity.reg`" /y" $script:oemEnc)
    if ($script:toolCode -eq 0) { KV 'Office-Identität' 'Registrierung gesichert (OK)' } else { KV 'Office-Identität' 'nicht vorhanden' }
    $oaL = @(RunTool 'Sicherung' "$env:windir\System32\cmdkey.exe" '/list' $script:oemEnc)
    try { Set-Content -Path "$oaRoot\Anmeldeinformationen_Namen.txt" -Value $oaL -Encoding UTF8 -ErrorAction Stop } catch { $oaBad++ }
    $oaNames = @(OaCredNames $oaL)
    $oaAll = @($oaL | Where-Object { $_ -match '(?i)target=' }).Count
    KV 'Anmeldeinfos' "$oaAll Einträge gelistet, davon $($oaNames.Count) von Office/OneDrive (nur Namen, keine Kennwörter)"
    foreach ($oaX in $oaNames | Select-Object -First 15) { "  $oaX" }
    if ($oaBad) { KV 'Sicherung' "FEHLER - nicht vollständig ($oaRoot)" }
    else { KV 'Sicherung' "OK - $oaRoot"; $script:oaDir = $oaRoot }
}

# ---------- WLAN-Profile sichern und wiederherstellen ----------
# Sicherung: netsh wlan export profile (mit Administratorrechten inkl. Kennwörter im Klartext), Ordner nur für Benutzer, Administratoren und System.
# Wiederherstellung: neueste Sicherung C:\SippicomInstall\backup\WLAN_* per netsh wlan add profile (Administratorrechte nötig).
$script:wlDir = $null
function WlBackup {
    $script:wlDir = $null
    $wlTs = Get-Date -Format 'yyyyMMdd_HHmmss'
    $wlRoot = "C:\SippicomInstall\backup\WLAN_$($env:COMPUTERNAME)_$wlTs"
    try { New-Item -ItemType Directory -Path $wlRoot -Force -ErrorAction Stop | Out-Null } catch { KV 'Sicherung' "FEHLER - Zielordner nicht anlegbar ($($_.Exception.Message))"; return }
    [void](RunTool 'Sicherung' "$env:windir\System32\icacls.exe" "`"$wlRoot`" /inheritance:r /grant:r *S-1-5-18:(OI)(CI)F *S-1-5-32-544:(OI)(CI)F `"${env:USERDOMAIN}\${env:USERNAME}`":(OI)(CI)F" $script:oemEnc)
    if ($script:toolCode -eq 0) { KV 'Zugriffsschutz' 'OK - nur Benutzer, Administratoren und System' } else { KV 'Zugriffsschutz' 'FEHLER - Ordnerrechte konnten nicht beschränkt werden' }
    $wlL = @(RunTool 'Sicherung' "$env:windir\System32\netsh.exe" 'wlan show profiles' $script:oemEnc)
    $wlNames = @(foreach ($wlX in $wlL) { if ($wlX -match '(?i)^\s*(?:Profil|All User Profile|Current User Profile)[^:]*:\s*(.+?)\s*$') { $Matches[1] } })
    if ($wlNames.Count -eq 0) { KV 'WLAN-Profile' 'keine gespeichert (nichts zu sichern)'; return }
    KV 'WLAN-Profile' "$($wlNames.Count) gespeichert"
    $wlKey = ''; if ($isAdmin) { $wlKey = 'key=clear ' }
    [void](RunTool 'Sicherung' "$env:windir\System32\netsh.exe" "wlan export profile ${wlKey}folder=`"$wlRoot`"" $script:oemEnc)
    $wlFiles = @(Get-ChildItem $wlRoot -Filter *.xml -File -ErrorAction SilentlyContinue)
    $wlClear = 0
    foreach ($wlF in $wlFiles | Select-Object -First 25) {
        $wlN = $wlF.BaseName
        try {
            $wlXml = [xml](Get-Content -LiteralPath $wlF.FullName -Raw -ErrorAction Stop)
            $wlN = $wlXml.WLANProfile.name
            if ($wlXml.WLANProfile.MSM.security.sharedKey.protected -eq 'false') { $wlClear++ }
        } catch {}
        "  $wlN"
    }
    if ($wlFiles.Count -eq $wlNames.Count) { KV 'Gesichert' "$($wlFiles.Count) von $($wlNames.Count) Profilen (OK)"; $script:wlDir = $wlRoot }
    else { KV 'Gesichert' "FEHLER - nur $($wlFiles.Count) von $($wlNames.Count) Profilen" }
    KV 'Ordner' $wlRoot
    if ($wlClear -gt 0) { 'Hinweis: Die Dateien enthalten WLAN-Kennwörter im Klartext - nach Gebrauch sicher löschen.' }
    elseif (-not $isAdmin) { 'Hinweis: Ohne Administratorrechte sind Kennwörter nur verschlüsselt gesichert (nur auf diesem PC nutzbar).' }
}
function WlRestore {
    $wlDirs = @(Get-ChildItem 'C:\SippicomInstall\backup' -Directory -Filter 'WLAN_*' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    if ($wlDirs.Count -eq 0) {
        'Hinweis: Keine WLAN-Sicherung gefunden (C:\SippicomInstall\backup\WLAN_*).'
        F 'WLAN-Wiederherstellung nicht möglich: keine Sicherung vorhanden.' 'Zuerst "WLAN sichern" ausführen oder den Sicherungsordner nach C:\SippicomInstall\backup kopieren.'
        return
    }
    $wlSrc = $wlDirs[0].FullName
    KV 'Sicherung' $wlSrc
    $wlFiles = @(Get-ChildItem $wlSrc -Filter *.xml -File -ErrorAction SilentlyContinue)
    if ($wlFiles.Count -eq 0) { F 'WLAN-Wiederherstellung nicht möglich: Sicherungsordner enthält keine Profildateien.' 'Anderen Sicherungsordner wählen (neuester WLAN_*-Ordner wird verwendet).'; return }
    if ((Get-Service WlanSvc -ErrorAction SilentlyContinue).Status -ne 'Running') {
        F 'WLAN-Dienst (WlanSvc) läuft nicht oder kein WLAN-Adapter vorhanden.' 'WLAN-Adapter aktivieren und Dienst "WLAN-AutoKonfiguration" starten, dann erneut ausführen.'
        return
    }
    KV 'Profile' "$($wlFiles.Count) Datei(en) werden eingespielt"
    $wlOk = 0; $wlBad = 0
    foreach ($wlF in $wlFiles) {
        $wlN = $wlF.BaseName
        try { $wlN = ([xml](Get-Content -LiteralPath $wlF.FullName -Raw -ErrorAction Stop)).WLANProfile.name } catch {}
        $wlOut = @(RunTool 'Wiederherstellung' "$env:windir\System32\netsh.exe" "wlan add profile filename=`"$($wlF.FullName)`" user=all" $script:oemEnc)
        if ($script:toolCode -eq 0) { $wlOk++; "Profil $wlN wiederhergestellt : OK" }
        else { $wlBad++; "Profil $wlN wiederhergestellt : FEHLER ($(Cut ($wlOut -join ' ') 90))" }
    }
    if ($wlBad) {
        KV 'Ergebnis' "FEHLER - $wlBad von $($wlFiles.Count) Profilen nicht wiederhergestellt"
        F 'WLAN-Profile konnten nicht vollständig wiederhergestellt werden.' 'WLAN-Adapter und Dienst WlanSvc prüfen; Sicherungsdateien auf Lesbarkeit prüfen und erneut ausführen.'
    } else {
        KV 'Ergebnis' "OK - $wlOk Profile wiederhergestellt"
        'Hinweis: Profile mit Zertifikat oder 802.1X benötigen eventuell eine erneute Anmeldung; WLAN kurz aus- und einschalten.'
    }
}

# ---------- Weitere Sicherungen und Reparaturen ----------
# Gemeinsamer Sicherungsordner: C:\SippicomInstall\backup\<Name>_<PC>_<Benutzer>_<Zeit>, nur für Benutzer, Administratoren und System.
# Ergebnis steht in $script:bkLast (Funktion schreibt Meldungen in die Ausgabe).
$script:bkLast = $null; $script:bwOk = $false; $script:oxOk = $false; $script:nlOk = $false
$script:bwFavN = 0; $script:bwFavBar = 0
function BkDir([string]$bkName, [string]$bkBase = 'C:\SippicomInstall\backup') {
    $script:bkLast = $null
    $bkRoot = "$bkBase\${bkName}_$($env:COMPUTERNAME)_$($env:USERNAME)_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    try { New-Item -ItemType Directory -Path $bkRoot -Force -ErrorAction Stop | Out-Null } catch { KV 'Sicherung' "FEHLER - Zielordner nicht anlegbar ($($_.Exception.Message))"; return }
    [void](RunTool 'Sicherung' "$env:windir\System32\icacls.exe" "`"$bkRoot`" /inheritance:r /grant:r *S-1-5-18:(OI)(CI)F *S-1-5-32-544:(OI)(CI)F `"${env:USERDOMAIN}\${env:USERNAME}`":(OI)(CI)F" $script:oemEnc)
    if ($script:toolCode -eq 0) { KV 'Zugriffsschutz' 'OK - nur Benutzer, Administratoren und System' } else { KV 'Zugriffsschutz' 'FEHLER - Ordnerrechte konnten nicht beschränkt werden' }
    $script:bkLast = $bkRoot
}
# Favoriten (Chromium-Bookmarks-Datei) als HTML im Netscape-Format schreiben; importierbar in Edge, Chrome und Firefox
function BwFavNode($fnNode, $fnSb) {
    foreach ($fnC in @($fnNode.children)) {
        if ($fnC.type -eq 'folder') {
            [void]$fnSb.AppendLine('<DT><H3>' + (Hz $fnC.name) + '</H3>')
            [void]$fnSb.AppendLine('<DL><p>')
            BwFavNode $fnC $fnSb
            [void]$fnSb.AppendLine('</DL><p>')
        } elseif ($fnC.type -eq 'url') {
            $script:bwFavN++
            [void]$fnSb.AppendLine('<DT><A HREF="' + (Hz $fnC.url) + '">' + (Hz $fnC.name) + '</A>')
        }
    }
}
function BwFavHtml([string]$fhSrc, [string]$fhDst) {
    $script:bwFavN = 0; $script:bwFavBar = 0
    try { $fhJ = (Get-Content -LiteralPath $fhSrc -Raw -Encoding UTF8 -ErrorAction Stop) | ConvertFrom-Json -ErrorAction Stop } catch { return $false }
    $fhSb = New-Object Text.StringBuilder
    [void]$fhSb.AppendLine('<!DOCTYPE NETSCAPE-Bookmark-file-1>')
    [void]$fhSb.AppendLine('<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">')
    [void]$fhSb.AppendLine('<TITLE>Lesezeichen</TITLE>')
    [void]$fhSb.AppendLine('<H1>Lesezeichen</H1>')
    [void]$fhSb.AppendLine('<DL><p>')
    $fhRoots = @(@{ N = 'Favoritenleiste'; K = 'bookmark_bar' }, @{ N = 'Weitere Favoriten'; K = 'other' }, @{ N = 'Mobile Favoriten'; K = 'synced' })
    foreach ($fhR in $fhRoots) {
        $fhNode = $fhJ.roots.($fhR.K)
        if ($fhNode -and @($fhNode.children).Count) {
            $fhAttr = ''; if ($fhR.K -eq 'bookmark_bar') { $fhAttr = ' PERSONAL_TOOLBAR_FOLDER="true"' }
            [void]$fhSb.AppendLine('<DT><H3' + $fhAttr + '>' + $fhR.N + '</H3>')
            [void]$fhSb.AppendLine('<DL><p>')
            BwFavNode $fhNode $fhSb
            [void]$fhSb.AppendLine('</DL><p>')
            if ($fhR.K -eq 'bookmark_bar') { $script:bwFavBar = $script:bwFavN }
        }
    }
    [void]$fhSb.AppendLine('</DL><p>')
    try { [IO.File]::WriteAllText($fhDst, $fhSb.ToString(), (New-Object Text.UTF8Encoding($true))) } catch { return $false }
    return $true
}
# Browser: Favoriten (inkl. Favoritenleiste als HTML) und Kennwortdateien (verschlüsselt, keine Klartext-Kennwörter) von Edge, Chrome und Firefox
function BwBackup {
    $script:bwOk = $false
    BkDir 'Browser'
    $bwRoot = $script:bkLast
    if (-not $bwRoot) { return }
    $bwFavDir = Join-Path $bwRoot 'Favoriten'
    New-Item -ItemType Directory -Path $bwFavDir -Force | Out-Null
    $bwRun = @(Get-Process -Name msedge, chrome, firefox -ErrorAction SilentlyContinue | Select-Object -ExpandProperty ProcessName -Unique)
    if ($bwRun.Count) { 'Hinweis: Geöffnete Browser (' + ($bwRun -join ', ') + ') - bitte schließen, sonst sind Kennwortdateien eventuell gesperrt.' }
    $bwBad = 0; $bwN = 0
    $bwCr = @(@{ N = 'Edge'; P = "$env:LOCALAPPDATA\Microsoft\Edge\User Data" }, @{ N = 'Chrome'; P = "$env:LOCALAPPDATA\Google\Chrome\User Data" })
    foreach ($bwB in $bwCr) {
        if (-not (Test-Path -LiteralPath $bwB.P)) { KV $bwB.N 'nicht installiert bzw. kein Profil'; continue }
        $bwDst = Join-Path $bwRoot $bwB.N
        New-Item -ItemType Directory -Path $bwDst -Force | Out-Null
        try { Copy-Item -LiteralPath "$($bwB.P)\Local State" -Destination $bwDst -Force -ErrorAction Stop } catch { $bwBad++; "  FEHLER: $($bwB.N) Local State nicht kopierbar" }
        $bwProf = @(Get-ChildItem -LiteralPath $bwB.P -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'Default' -or $_.Name -like 'Profile *' })
        if ($bwProf.Count -eq 0) { KV $bwB.N 'kein Browserprofil gefunden' }
        foreach ($bwP in $bwProf) {
            $bwPd = Join-Path $bwDst $bwP.Name
            New-Item -ItemType Directory -Path $bwPd -Force | Out-Null
            foreach ($bwF in 'Bookmarks', 'Login Data', 'Login Data For Account') {
                $bwS = Join-Path $bwP.FullName $bwF
                if (Test-Path -LiteralPath $bwS) {
                    try { Copy-Item -LiteralPath $bwS -Destination $bwPd -Force -ErrorAction Stop; $bwN++ } catch { $bwBad++; "  FEHLER: $($bwB.N) $($bwP.Name) '$bwF' nicht kopierbar (Browser geschlossen?)" }
                }
            }
            $bwCnt = 0
            $bwBm = Join-Path $bwPd 'Bookmarks'
            if (Test-Path -LiteralPath $bwBm) { try { $bwCnt = ([regex]::Matches((Get-Content -LiteralPath $bwBm -Raw -ErrorAction Stop), '"type":\s*"url"')).Count } catch {} }
            $bwFavT = ''
            if (Test-Path -LiteralPath $bwBm) {
                $bwHtml = Join-Path $bwFavDir "Favoriten_$($bwB.N)_$($bwP.Name).html"
                if (BwFavHtml $bwBm $bwHtml) { $bwFavT = ", Favoritenleiste $($script:bwFavBar) Einträge als HTML (OK)" }
                else { $bwBad++; $bwFavT = ', Favoriten-HTML FEHLER' }
            }
            $bwPw = Test-Path -LiteralPath (Join-Path $bwPd 'Login Data')
            $bwPwT = 'nicht vorhanden'; if ($bwPw) { $bwPwT = 'gesichert (OK)' }
            "  $($bwB.N) $($bwP.Name): $bwCnt Lesezeichen$bwFavT, Kennwortdatei $bwPwT"
        }
    }
    $bwFx = "$env:APPDATA\Mozilla\Firefox"
    if (Test-Path -LiteralPath "$bwFx\Profiles") {
        $bwDst = Join-Path $bwRoot 'Firefox'
        New-Item -ItemType Directory -Path $bwDst -Force | Out-Null
        try { Copy-Item -LiteralPath "$bwFx\profiles.ini" -Destination $bwDst -Force -ErrorAction Stop } catch {}
        foreach ($bwP in @(Get-ChildItem -LiteralPath "$bwFx\Profiles" -Directory -ErrorAction SilentlyContinue)) {
            $bwPd = Join-Path (Join-Path $bwDst 'Profiles') $bwP.Name
            New-Item -ItemType Directory -Path $bwPd -Force | Out-Null
            $bwFbad = 0
            foreach ($bwF in 'places.sqlite', 'key4.db', 'logins.json') {
                $bwS = Join-Path $bwP.FullName $bwF
                if (Test-Path -LiteralPath $bwS) {
                    try { Copy-Item -LiteralPath $bwS -Destination $bwPd -Force -ErrorAction Stop; $bwN++ } catch { $bwBad++; $bwFbad++; "  FEHLER: Firefox $($bwP.Name) '$bwF' nicht kopierbar (Firefox geschlossen?)" }
                }
            }
            if (Test-Path -LiteralPath "$($bwP.FullName)\bookmarkbackups") {
                [void](RunTool 'Sicherung' "$env:windir\System32\robocopy.exe" "`"$($bwP.FullName)\bookmarkbackups`" `"$bwPd\bookmarkbackups`" /E /R:0 /W:0 /NFL /NDL /NJH /NJS /NP" $script:oemEnc)
            }
            $bwFt = 'Favoriten (inkl. Lesezeichenleiste) und Kennwörter gesichert (OK)'; if ($bwFbad) { $bwFt = 'unvollständig' }
            "  Firefox $($bwP.Name): $bwFt"
        }
    } else { KV 'Firefox' 'nicht installiert bzw. kein Profil' }
    KV 'Ordner' $bwRoot
    if ($bwBad -eq 0 -and $bwN -gt 0) { KV 'Sicherung' 'OK - Favoriten, Favoritenleiste und Kennwortdateien kopiert'; $script:bwOk = $true }
    elseif ($bwN -eq 0) { KV 'Sicherung' 'FEHLER - keine Browserdaten gefunden' }
    else { KV 'Sicherung' "FEHLER - $bwBad Datei(en) nicht kopiert" }
    'Hinweis: Die HTML-Dateien im Ordner Favoriten lassen sich in Edge, Chrome und Firefox über "Favoriten importieren" einlesen (Favoritenleiste inklusive).'
    'Hinweis: Firefox: Lesezeichenleiste steckt in places.sqlite und in bookmarkbackups; Zurückspielen über "Lesezeichen verwalten" > "Importieren und Sichern".'
    'Hinweis: Kennwörter werden verschlüsselt kopiert, nicht im Klartext. Der Ordner ist vertraulich zu behandeln.'
    'Hinweis: Edge/Chrome-Kennwörter sind an Windows-Benutzer und PC gebunden (Wiederherstellung nur dort); für einen PC-Wechsel Export im Browser oder Synchronisierung nutzen.'
}
# Outlook: Profile (Registrierung), Signaturen, Vorlagen, Autovervollständigen; OST/PST werden nur aufgelistet
function OxBackup {
    $script:oxOk = $false
    BkDir 'Outlook'
    $oxRoot = $script:bkLast
    if (-not $oxRoot) { return }
    $oxBad = 0
    [void](RunTool 'Sicherung' "$env:windir\System32\reg.exe" "export `"HKCU\Software\Microsoft\Office\16.0\Outlook\Profiles`" `"$oxRoot\Outlook_Profile.reg`" /y" $script:oemEnc)
    if ($script:toolCode -eq 0) { KV 'Outlook-Profile' 'Registrierung gesichert (OK)' } else { KV 'Outlook-Profile' 'nicht vorhanden (kein klassisches Outlook eingerichtet)' }
    $oxPf = @(Get-ChildItem 'HKCU:\Software\Microsoft\Office\16.0\Outlook\Profiles' -ErrorAction SilentlyContinue | ForEach-Object { $_.PSChildName })
    if ($oxPf.Count) { KV 'Profilnamen' ($oxPf -join ', ') }
    $oxDirs = @(
        @{ N = 'Signaturen'; P = "$env:APPDATA\Microsoft\Signatures" },
        @{ N = 'Vorlagen'; P = "$env:APPDATA\Microsoft\Templates" },
        @{ N = 'Autovervollständigen'; P = "$env:LOCALAPPDATA\Microsoft\Outlook\RoamCache" }
    )
    foreach ($oxD in $oxDirs) {
        if (Test-Path -LiteralPath $oxD.P) {
            [void](RunTool 'Sicherung' "$env:windir\System32\robocopy.exe" "`"$($oxD.P)`" `"$oxRoot\$($oxD.N)`" /E /R:0 /W:0 /NFL /NDL /NJH /NJS /NP" $script:oemEnc)
            if ($script:toolCode -lt 8) { KV $oxD.N 'gesichert (OK)' } else { $oxBad++; KV $oxD.N "FEHLER (robocopy Code $($script:toolCode))" }
        } else { KV $oxD.N 'nicht vorhanden' }
    }
    ''
    'Datendateien (werden nicht kopiert):'
    $oxFiles = @(Get-ChildItem "$env:LOCALAPPDATA\Microsoft\Outlook" -Include *.ost, *.pst -Recurse -ErrorAction SilentlyContinue) + @(Get-ChildItem "$env:USERPROFILE\Documents" -Filter *.pst -Recurse -ErrorAction SilentlyContinue | Select-Object -First 10)
    if ($oxFiles.Count) { foreach ($oxFi in $oxFiles) { "  $($oxFi.FullName) : $([math]::Round($oxFi.Length/1GB,2)) GB" } } else { '  keine gefunden' }
    KV 'Ordner' $oxRoot
    if ($oxBad) { KV 'Sicherung' 'FEHLER - nicht vollständig' } else { KV 'Sicherung' 'OK - Profile, Signaturen, Vorlagen gesichert'; $script:oxOk = $true }
    'Hinweis: PST-Dateien bei Bedarf separat kopieren; OST-Dateien sind nur ein Zwischenspeicher und werden vom Server neu aufgebaut.'
}
# Netzlaufwerke, Netzwerkdrucker und Registry-Mappings sichern, dazu eine Wiederherstellen.cmd (ohne Kennwörter)
function NlBackup {
    $script:nlOk = $false
    BkDir 'Netzlaufwerke'
    $nlRoot = $script:bkLast
    if (-not $nlRoot) { return }
    $nlBad = 0
    $nlRows = @()
    foreach ($nlK in @(Get-ChildItem 'HKCU:\Network' -ErrorAction SilentlyContinue)) {
        $nlP = Get-ItemProperty -LiteralPath $nlK.PSPath -ErrorAction SilentlyContinue
        $nlRows += [pscustomobject]@{ Laufwerk = "$($nlK.PSChildName):"; Pfad = "$($nlP.RemotePath)"; Benutzer = "$($nlP.UserName)"; Anbieter = "$($nlP.ProviderName)" }
    }
    KV 'Netzlaufwerke' "$($nlRows.Count) dauerhaft verbunden"
    foreach ($nlR in $nlRows) { "  $($nlR.Laufwerk) -> $($nlR.Pfad)" }
    $nlPr = @(Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '\\*' })
    KV 'Netzwerkdrucker' "$($nlPr.Count) verbunden"
    foreach ($nlD in $nlPr) { "  $($nlD.Name)" }
    try { if ($nlRows.Count) { $nlRows | Export-Csv -Path "$nlRoot\Netzlaufwerke.csv" -NoTypeInformation -Delimiter ';' -Encoding UTF8 -ErrorAction Stop } } catch { $nlBad++ }
    $nlNet = @(RunTool 'Sicherung' "$env:windir\System32\net.exe" 'use' $script:oemEnc)
    try { Set-Content -Path "$nlRoot\net_use.txt" -Value $nlNet -Encoding UTF8 -ErrorAction Stop } catch { $nlBad++ }
    [void](RunTool 'Sicherung' "$env:windir\System32\reg.exe" "export `"HKCU\Network`" `"$nlRoot\Netzlaufwerke_Registry.reg`" /y" $script:oemEnc)
    if ($script:toolCode -eq 0) { KV 'Registrierung' 'gesichert (OK)' } else { KV 'Registrierung' 'keine dauerhaften Laufwerke vorhanden' }
    $nlCmd = @('@echo off', 'rem Sippicom Diagnosezentrum - verbindet die gesicherten Netzlaufwerke und Netzwerkdrucker neu (ohne Kennwörter).', 'rem Bei Anmeldeabfrage Benutzername und Kennwort eingeben.')
    foreach ($nlR in $nlRows) { if ($nlR.Pfad) { $nlCmd += "net use $($nlR.Laufwerk) `"$($nlR.Pfad)`" /persistent:yes" } }
    foreach ($nlD in $nlPr) { $nlCmd += "rundll32 printui.dll,PrintUIEntry /in /n`"$($nlD.Name)`"" }
    $nlCmd += 'pause'
    try { [IO.File]::WriteAllLines("$nlRoot\Wiederherstellen.cmd", $nlCmd, $script:oemEnc) } catch { $nlBad++ }
    KV 'Ordner' $nlRoot
    if ($nlBad) { KV 'Sicherung' 'FEHLER - nicht vollständig' } else { KV 'Sicherung' 'OK - Zuordnungen gesichert (Wiederherstellen.cmd im Ordner)'; $script:nlOk = $true }
    'Hinweis: Kennwörter der Netzlaufwerke werden nicht gesichert; Laufwerke, die nur per "net use" ohne /persistent verbunden sind, stehen in net_use.txt.'
}
# Temp-Dateien bereinigen: Dateien älter als 1 Tag im Benutzer-Temp (mit Administratorrechten auch Windows-Temp), Papierkorb leeren
function TcClean {
    $tcPaths = @($env:TEMP)
    if ($isAdmin) { $tcPaths += "$env:windir\Temp" } else { 'Hinweis: Ohne Administratorrechte wird nur das Benutzer-Temp bereinigt (C:\Windows\Temp wird übersprungen).' }
    $tcCut = (Get-Date).AddDays(-1); $tcTotal = 0L; $tcDel = 0; $tcFail = 0; $tcI = 0
    foreach ($tcP in $tcPaths | Select-Object -Unique) {
        if (-not (Test-Path -LiteralPath $tcP)) { continue }
        $tcSub = 0L; $tcCnt = 0
        foreach ($tcF in @(Get-ChildItem -LiteralPath $tcP -Recurse -Force -File -ErrorAction SilentlyContinue)) {
            if ($tcF.LastWriteTime -gt $tcCut) { continue }
            $tcI++
            if ($tcI % 100 -eq 0) { Msg "Bereinige Temp-Dateien ... ($tcI geprüft)" $null; [Windows.Forms.Application]::DoEvents() }
            $tcLen = $tcF.Length
            try { Remove-Item -LiteralPath $tcF.FullName -Force -ErrorAction Stop; $tcSub += $tcLen; $tcCnt++ } catch { $tcFail++ }
        }
        foreach ($tcD in @(Get-ChildItem -LiteralPath $tcP -Recurse -Force -Directory -ErrorAction SilentlyContinue | Sort-Object { $_.FullName.Length } -Descending)) {
            if (-not (Get-ChildItem -LiteralPath $tcD.FullName -Force -ErrorAction SilentlyContinue | Select-Object -First 1)) { Remove-Item -LiteralPath $tcD.FullName -Force -ErrorAction SilentlyContinue }
        }
        "Ordner $tcP : $tcCnt Dateien gelöscht, $([math]::Round($tcSub / 1MB, 1)) MB freigegeben"
        $tcTotal += $tcSub; $tcDel += $tcCnt
    }
    try { Clear-RecycleBin -Force -ErrorAction Stop; 'Papierkorb geleert : OK' } catch { 'Papierkorb: bereits leer oder nicht leerbar' }
    KV 'Ergebnis' "OK - $tcDel Dateien gelöscht, $([math]::Round($tcTotal / 1MB, 1)) MB freigegeben"
    if ($tcFail) { "Hinweis: $tcFail Dateien sind in Benutzung und wurden übersprungen (normal)." }
}
# Microsoft-Store-Apps des angemeldeten Benutzers neu registrieren
function SaRegister {
    $ProgressPreference = 'SilentlyContinue'
    $saPk = @(Get-AppxPackage | Where-Object { $_.InstallLocation -and -not $_.IsFramework -and (Test-Path -LiteralPath "$($_.InstallLocation)\AppxManifest.xml") })
    KV 'Apps' "$($saPk.Count) Pakete des angemeldeten Benutzers"
    if ($saPk.Count -eq 0) { F 'Keine registrierbaren Store-Apps gefunden.' 'Windows-Version und Rechte prüfen (Get-AppxPackage liefert keine Pakete).'; return }
    $saOk = 0; $saFail = @(); $saI = 0
    foreach ($saA in $saPk) {
        $saI++
        Msg "Registriere Apps neu ... ($saI von $($saPk.Count))" $null
        $hdr.Tag.Sub = "Store-Apps: $saI von $($saPk.Count) ..."; $hdr.Invalidate()
        [Windows.Forms.Application]::DoEvents()
        try { Add-AppxPackage -DisableDevelopmentMode -Register "$($saA.InstallLocation)\AppxManifest.xml" -ErrorAction Stop; $saOk++ } catch { $saFail += $saA.Name }
    }
    "Apps neu registriert : $saOk von $($saPk.Count) (OK)"
    if ($saFail.Count) {
        "Nicht registrierbar (laufend oder geschützt): $($saFail.Count)"
        foreach ($saN in $saFail | Select-Object -First 8) { "  $saN" }
    }
    if ($saOk -eq 0) { F 'Keine Store-App konnte neu registriert werden.' 'Als betroffener Benutzer starten, Windows-Updates installieren und erneut versuchen.' }
    else { 'Hinweis: Bei Problemen mit Startmenü oder Einstellungen einmal ab- und wieder anmelden bzw. den PC neu starten.' }
}
# DHCP-Lease erneuern und die erhaltene Konfiguration anzeigen (hilft bei VLAN- und DHCP-Problemen)
function DcRenew {
    [void](RunTool 'DHCP' "$env:windir\System32\ipconfig.exe" '/release' $script:oemEnc); $dcC1 = $script:toolCode
    if ($dcC1 -eq 0) { 'IP-Adresse freigeben : OK' } else { "IP-Adresse freigeben : Exitcode $dcC1 (evtl. Adapter ohne DHCP)" }
    [void](RunTool 'DHCP' "$env:windir\System32\ipconfig.exe" '/renew' $script:oemEnc); $dcC2 = $script:toolCode
    if ($dcC2 -eq 0) { 'IP-Adresse erneuern : OK' } else { "IP-Adresse erneuern : FEHLER (Exitcode $dcC2)"; F 'DHCP-Erneuerung ist fehlgeschlagen.' 'Netzwerkkabel bzw. WLAN, Switch-Port (VLAN) und DHCP-Server prüfen.' }
    Start-Sleep -Seconds 2
    ''
    $dcAd = @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=true' | Where-Object { $_.DHCPEnabled })
    if ($dcAd.Count -eq 0) { F 'Kein Adapter mit DHCP und IP-Adresse gefunden.' 'Adapter auf automatische IP-Vergabe (DHCP) stellen und Verbindung prüfen.' }
    foreach ($dcA in $dcAd) {
        $dcIp = @($dcA.IPAddress | Where-Object { $_ -notmatch ':' })
        KV 'Adapter' $dcA.Description
        KV 'IPv4' ($dcIp -join ', ')
        KV 'Gateway' (@($dcA.DefaultIPGateway) -join ', ')
        KV 'DHCP-Server' $dcA.DHCPServer
        if ($dcA.DHCPLeaseObtained) { KV 'Lease erhalten' $dcA.DHCPLeaseObtained.ToString('dd.MM.yyyy HH:mm:ss') }
        ''
        if ($dcIp | Where-Object { $_ -like '169.254.*' }) { FS "Adapter '$($dcA.Description)' hat nach der Erneuerung eine APIPA-Adresse (kein DHCP erreicht)." 'DHCP-Server, VLAN des Ports und Netzwerkverbindung prüfen.' }
    }
}
# Uhrzeit neu synchronisieren (Zeitdienst starten, w32tm /resync /force, Quelle und Abweichung anzeigen)
function ZtSync {
    $ztSv = Get-Service w32time -ErrorAction SilentlyContinue
    if (-not $ztSv) { F 'Windows-Zeitdienst (w32time) ist nicht vorhanden.' 'Windows-Installation prüfen (Zeitdienst fehlt).'; return }
    if ($ztSv.Status -ne 'Running') {
        try { Start-Service w32time -ErrorAction Stop; 'Zeitdienst gestartet : OK' } catch { "Zeitdienst gestartet : FEHLER ($($_.Exception.Message))"; F 'Windows-Zeitdienst konnte nicht gestartet werden.' 'Dienst "Windows-Zeit" manuell starten und Startart auf Automatisch setzen.'; return }
    } else { 'Zeitdienst läuft : OK' }
    $ztO = @(RunTool 'Zeitsync' "$env:windir\System32\w32tm.exe" '/resync /force' $script:oemEnc); $ztC = $script:toolCode
    foreach ($ztL in $ztO | Select-Object -Last 3) { "  $ztL" }
    if ($ztC -eq 0) { KV 'Ergebnis' 'OK - Uhrzeit synchronisiert' }
    else { KV 'Ergebnis' "FEHLER - Exitcode $ztC"; F 'Zeitsynchronisierung ist fehlgeschlagen.' 'Zeitquelle prüfen (w32tm /query /status), Netzwerk bzw. NTP-Server (UDP 123) erreichbar machen.' }
    $ztS = @(RunTool 'Zeitsync' "$env:windir\System32\w32tm.exe" '/query /status' $script:oemEnc)
    foreach ($ztL in $ztS | Where-Object { $_ -match '^(Quelle|Source|Letzte erfolgreiche|Last Successful)' }) { $ztL }
    $ztOff = MsOffset
    if ($null -ne $ztOff) {
        KV 'Abweichung' "$ztOff Sekunden zu Microsoft"
        if ($ztOff -gt 120) { F "Uhr weicht weiterhin um $ztOff s von Microsoft ab." 'Zeitzone, Datum und Zeitquelle prüfen; bei Domänenrechnern Domänencontroller als Zeitquelle prüfen.' }
    }
}

# Wiederherstellungspunkt vor riskanten Reparaturen (SFC, DISM, Update-Reset). Pro Programmlauf nur einmal.
# Voraussetzung: Computerschutz ist aktiviert; Windows legt standardmäßig höchstens einen Punkt in 24 Stunden an.
$script:rpRun = $false
function RpCreate([string]$rpWhy) {
    if ($script:rpRun) { KV 'Wiederherstellung' 'bereits in diesem Lauf angelegt (OK)'; return }
    $script:rpRun = $true
    Msg 'Lege Wiederherstellungspunkt an ...' $null; [Windows.Forms.Application]::DoEvents()
    $rpErr = ''
    try {
        $rpJob = Start-Job -ScriptBlock { param($rpD) $ErrorActionPreference = 'Stop'; Checkpoint-Computer -Description $rpD -RestorePointType MODIFY_SETTINGS } -ArgumentList "Sippicom Diagnosezentrum vor $rpWhy"
        $rpSw = [Diagnostics.Stopwatch]::StartNew()
        while ($rpJob.State -eq 'Running' -and $rpSw.Elapsed.TotalSeconds -lt 120) { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 200 }
        if ($rpJob.State -eq 'Running') { $rpErr = 'Zeitüberschreitung'; Stop-Job $rpJob -ErrorAction SilentlyContinue }
        else {
            [void](Receive-Job $rpJob -ErrorAction SilentlyContinue)
            if ($rpJob.State -eq 'Failed' -or $rpJob.ChildJobs[0].Error.Count) { $rpErr = "$($rpJob.ChildJobs[0].Error[0].Exception.Message)"; if (-not $rpErr) { $rpErr = "$($rpJob.ChildJobs[0].JobStateInfo.Reason.Message)" } }
            # Windows meldet die 24-Stunden-Begrenzung nur als Warnung (ohne Fehler)
            if (-not $rpErr -and $rpJob.ChildJobs[0].Warning.Count) { $rpErr = "$($rpJob.ChildJobs[0].Warning[0])" }
        }
        Remove-Job $rpJob -Force -ErrorAction SilentlyContinue
    } catch { $rpErr = $_.Exception.Message }
    if ($rpErr) {
        # Kurze, gut lesbare Ursache statt der langen Windows-Fehlermeldung
        $rpWhy2 = 'Windows hat den Punkt abgelehnt'
        if ($rpErr -match '1440|24 Stunden|Minuten') { $rpWhy2 = 'in den letzten 24 Stunden wurde schon ein Punkt angelegt' }
        elseif ($rpErr -match 'deaktiv|disabled|Computerschutz|System Restore|Systemwiederherstellung') { $rpWhy2 = 'Computerschutz ist deaktiviert' }
        elseif ($rpErr -match 'Zeitüberschreitung') { $rpWhy2 = 'Zeitüberschreitung beim Anlegen' }
        KV 'Wiederherstellung' "kein Punkt angelegt ($rpWhy2)"
        'Hinweis: Die Reparatur läuft trotzdem weiter.'
    } else { KV 'Wiederherstellung' 'OK - Punkt "Sippicom Diagnosezentrum" angelegt (Rückgängig: Systemwiederherstellung)' }
}

# ---------- Paketmitschnitt mit Windows-Bordmitteln (pktmon, netsh trace) und eigener Auswertung ----------
# Aufbau nach NetCapture: Aufnahme mit pktmon (ganze Pakete, Ringpuffer), ersatzweise netsh trace mit eingebautem ETL-nach-pcapng-Wandler.
# Die Auswertung (Protokolle, Dienste, Verbindungen, Neuübertragungen, Resets, DNS-Fehler, ICMP) liest die pcapng-Datei selbst;
# es werden weder Wireshark/TShark noch Npcap benötigt.
$script:NcSource = @'
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace Sippicom {
public sealed class EtlConvertResult {
    public long Events, Packets, Bytes, Ignored, Malformed;
    public int Interfaces;
    public bool TimedOut;
    public int Status;
    public string Error;
}

public sealed class EtlToPcapng {
    [StructLayout(LayoutKind.Sequential)]
    struct EVENT_TRACE_HEADER {
        public ushort Size; public ushort FieldTypeFlags; public uint Version;
        public uint ThreadId; public uint ProcessId; public long TimeStamp;
        public Guid Guid; public uint KernelTime; public uint UserTime;
    }
    [StructLayout(LayoutKind.Sequential)]
    struct EVENT_TRACE {
        public EVENT_TRACE_HEADER Header; public uint InstanceId; public uint ParentInstanceId;
        public Guid ParentGuid; public IntPtr MofData; public uint MofLength; public uint ClientContext;
    }
    [StructLayout(LayoutKind.Sequential)]
    struct TRACE_LOGFILE_HEADER {
        public uint BufferSize; public uint Version; public uint ProviderVersion; public uint NumberOfProcessors;
        public long EndTime; public uint TimerResolution; public uint MaximumFileSize; public uint LogFileMode;
        public uint BuffersWritten; public Guid LogInstanceGuid; public IntPtr LoggerName; public IntPtr LogFileName;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 172)] public byte[] TimeZone;
        public long BootTime; public long PerfFreq; public long StartTime; public uint ReservedFlags; public uint BuffersLost;
    }
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate uint BufferCallbackFn(IntPtr logfile);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate void EventRecordCallbackFn(IntPtr record);
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct EVENT_TRACE_LOGFILE {
        [MarshalAs(UnmanagedType.LPWStr)] public string LogFileName;
        [MarshalAs(UnmanagedType.LPWStr)] public string LoggerName;
        public long CurrentTime; public uint BuffersRead; public uint ProcessTraceMode;
        public EVENT_TRACE CurrentEvent; public TRACE_LOGFILE_HEADER LogfileHeader;
        public BufferCallbackFn BufferCallback;
        public uint BufferSize; public uint Filled; public uint EventsLost;
        public EventRecordCallbackFn EventRecordCallback;
        public uint IsKernelTrace; public IntPtr Context;
    }
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    static extern ulong OpenTrace(ref EVENT_TRACE_LOGFILE logfile);
    [DllImport("advapi32.dll")]
    static extern int ProcessTrace([In] ulong[] handles, uint count, IntPtr startTime, IntPtr endTime);
    [DllImport("advapi32.dll")]
    static extern int CloseTrace(ulong handle);

    const uint PROCESS_TRACE_MODE_EVENT_RECORD = 0x10000000;
    const ulong KW_MEDIA_WIRELESS_WAN = 0x200, KW_MEDIA_NATIVE_802_11 = 0x10000;
    const ulong KW_PACKET_START = 0x40000000, KW_PACKET_END = 0x80000000;
    const ulong KW_SEND = 0x100000000, KW_RECEIVE = 0x200000000;
    const int MaxPacket = 262144;
    const int OffPid = 12, OffTime = 16, OffProvider = 24, OffId = 40, OffKeyword = 48, OffCpu = 80, OffUserLen = 86;

    sealed class Pending { public byte[] Data = new byte[2048]; public int Len; public int IfId; public ulong Kw; public long Time; public uint Pid; }

    readonly long guidLo, guidHi;
    readonly Dictionary<uint, string> ifNames, procNames;
    readonly Dictionary<ulong, int> ifIds = new Dictionary<ulong, int>();
    readonly Dictionary<ulong, Pending> pending = new Dictionary<ulong, Pending>();
    readonly EtlConvertResult res = new EtlConvertResult();
    BinaryWriter w;
    DateTime deadline;

    EtlToPcapng(Dictionary<uint, string> ifNames, Dictionary<uint, string> procNames) {
        byte[] g = new Guid("2ED6006E-4729-4609-B423-3EE7BCD678EF").ToByteArray();
        guidLo = BitConverter.ToInt64(g, 0); guidHi = BitConverter.ToInt64(g, 8);
        this.ifNames = ifNames ?? new Dictionary<uint, string>();
        this.procNames = procNames ?? new Dictionary<uint, string>();
    }

    public static EtlConvertResult Convert(string etlPath, string pcapPath, int timeoutSec,
                                           Dictionary<uint, string> ifNames, Dictionary<uint, string> procNames) {
        EtlToPcapng c = new EtlToPcapng(ifNames, procNames);
        c.deadline = DateTime.UtcNow.AddSeconds(timeoutSec);
        BufferCallbackFn bufferCb = c.OnBuffer;
        EventRecordCallbackFn eventCb = c.OnEvent;
        try {
            using (FileStream fs = new FileStream(pcapPath, FileMode.Create, FileAccess.Write, FileShare.Read, 1 << 20)) {
                c.w = new BinaryWriter(fs);
                c.WriteSectionHeader();
                EVENT_TRACE_LOGFILE lf = new EVENT_TRACE_LOGFILE();
                lf.LogFileName = etlPath;
                lf.ProcessTraceMode = PROCESS_TRACE_MODE_EVENT_RECORD;
                lf.BufferCallback = bufferCb;
                lf.EventRecordCallback = eventCb;
                ulong h = OpenTrace(ref lf);
                if (h == ulong.MaxValue || h == 0xFFFFFFFFUL) {
                    c.res.Status = Marshal.GetLastWin32Error();
                    c.res.Error = "OpenTrace fehlgeschlagen (Win32-Fehler " + c.res.Status + ")";
                    return c.res;
                }
                try { c.res.Status = ProcessTrace(new ulong[] { h }, 1, IntPtr.Zero, IntPtr.Zero); }
                finally { CloseTrace(h); }
                foreach (Pending p in c.pending.Values) if (p.Len > 0) c.WritePacket(p);
                c.w.Flush();
            }
        } catch (Exception ex) {
            if (c.res.Error == null) c.res.Error = ex.Message;
        }
        GC.KeepAlive(bufferCb); GC.KeepAlive(eventCb);
        c.res.Interfaces = c.ifIds.Count;
        if (c.res.Status != 0 && !(c.res.TimedOut && c.res.Status == 1223) && c.res.Error == null)
            c.res.Error = "ProcessTrace meldet Win32-Fehler " + c.res.Status;
        return c.res;
    }

    uint OnBuffer(IntPtr logfile) {
        if (DateTime.UtcNow > deadline) { res.TimedOut = true; return 0; }
        return 1;
    }

    void OnEvent(IntPtr rec) {
        try {
            res.Events++;
            if (Marshal.ReadInt64(rec, OffProvider) != guidLo || Marshal.ReadInt64(rec, OffProvider + 8) != guidHi
                || (ushort)Marshal.ReadInt16(rec, OffId) != 1001) { res.Ignored++; return; }
            int userLen = (ushort)Marshal.ReadInt16(rec, OffUserLen);
            IntPtr data = Marshal.ReadIntPtr(rec, 88 + IntPtr.Size);
            if (userLen < 12 || data == IntPtr.Zero) { res.Malformed++; return; }
            uint miniport = (uint)Marshal.ReadInt32(data, 0);
            uint lower = (uint)Marshal.ReadInt32(data, 4);
            int fragLen = Marshal.ReadInt32(data, 8);
            if (fragLen < 0 || fragLen > userLen - 12 || fragLen > MaxPacket) { res.Malformed++; return; }
            ulong kw = (ulong)Marshal.ReadInt64(rec, OffKeyword);
            ushort linkType = (ushort)((kw & KW_MEDIA_WIRELESS_WAN) != 0 ? 101 : (kw & KW_MEDIA_NATIVE_802_11) != 0 ? 105 : 1);
            int ifId = GetInterface(miniport, linkType);
            ulong key = ((ulong)(ushort)Marshal.ReadInt16(rec, OffCpu) << 32) | lower;
            bool start = (kw & KW_PACKET_START) != 0, end = (kw & KW_PACKET_END) != 0;

            Pending p;
            pending.TryGetValue(key, out p);
            if (start || p == null || p.Len == 0) {
                if (p != null && p.Len > 0) WritePacket(p);
                if (p == null) { p = new Pending(); pending[key] = p; }
                p.Len = 0; p.IfId = ifId; p.Kw = kw;
                p.Time = Marshal.ReadInt64(rec, OffTime);
                p.Pid = (uint)Marshal.ReadInt32(rec, OffPid);
                if (!start && !end) end = true;
            }
            if (p.Len + fragLen > MaxPacket) fragLen = MaxPacket - p.Len;
            if (p.Len + fragLen > p.Data.Length) Array.Resize(ref p.Data, Math.Max(p.Len + fragLen, p.Data.Length * 2));
            Marshal.Copy(new IntPtr(data.ToInt64() + 12), p.Data, p.Len, fragLen);
            p.Len += fragLen;
            if (end) { WritePacket(p); p.Len = 0; }
        } catch (Exception ex) {
            res.Malformed++;
            if (res.Error == null) res.Error = "Ereignis " + res.Events + ": " + ex.Message;
        }
    }

    int GetInterface(uint ifIndex, ushort linkType) {
        ulong key = ((ulong)ifIndex << 16) | linkType;
        int id;
        if (ifIds.TryGetValue(key, out id)) return id;
        id = ifIds.Count;
        ifIds[key] = id;
        string name;
        if (!ifNames.TryGetValue(ifIndex, out name)) name = "ifIndex " + ifIndex;
        else name = name + " (ifIndex " + ifIndex + ")";
        string desc = linkType == 101 ? "Mobilfunk (Raw IP)" : linkType == 105 ? "WLAN (natives 802.11)" : "Ethernet";
        byte[] opts = Options(new int[] { 2, 3 }, new string[] { name, desc });
        w.Write((uint)1); w.Write((uint)(20 + opts.Length));
        w.Write(linkType); w.Write((ushort)0); w.Write((uint)MaxPacket);
        w.Write(opts);
        w.Write((uint)(20 + opts.Length));
        return id;
    }

    void WritePacket(Pending p) {
        int len = p.Len, pad = (4 - len % 4) % 4;
        long us = Math.Max(0, (p.Time - 116444736000000000L) / 10);
        uint dir = (p.Kw & KW_SEND) != 0 ? 2u : (p.Kw & KW_RECEIVE) != 0 ? 1u : 0u;
        string comment = null;
        if (p.Pid != 0 && p.Pid != 4 && p.Pid != uint.MaxValue) {
            string pn;
            comment = procNames.TryGetValue(p.Pid, out pn) ? "PID=" + p.Pid + " (" + pn + ")" : "PID=" + p.Pid;
        }
        byte[] cb = comment == null ? null : Encoding.UTF8.GetBytes(comment);
        int optLen = (dir != 0 ? 8 : 0) + (cb != null ? 4 + cb.Length + (4 - cb.Length % 4) % 4 : 0) + 4;
        uint total = (uint)(32 + len + pad + optLen);
        w.Write((uint)6); w.Write(total);
        w.Write((uint)p.IfId); w.Write((uint)(us >> 32)); w.Write((uint)us);
        w.Write((uint)len); w.Write((uint)len);
        w.Write(p.Data, 0, len);
        for (int i = 0; i < pad; i++) w.Write((byte)0);
        if (dir != 0) { w.Write((ushort)2); w.Write((ushort)4); w.Write(dir); }
        if (cb != null) {
            w.Write((ushort)1); w.Write((ushort)cb.Length); w.Write(cb);
            for (int i = 0; i < (4 - cb.Length % 4) % 4; i++) w.Write((byte)0);
        }
        w.Write((uint)0);
        w.Write(total);
        res.Packets++; res.Bytes += len;
    }

    void WriteSectionHeader() {
        byte[] opts = Options(new int[] { 4 }, new string[] { "SIPPICOM Diagnosezentrum (netsh trace)" });
        w.Write(0x0A0D0D0Au); w.Write((uint)(28 + opts.Length));
        w.Write(0x1A2B3C4Du); w.Write((ushort)1); w.Write((ushort)0); w.Write(-1L);
        w.Write(opts);
        w.Write((uint)(28 + opts.Length));
    }

    static byte[] Options(int[] codes, string[] values) {
        MemoryStream ms = new MemoryStream();
        BinaryWriter o = new BinaryWriter(ms);
        for (int i = 0; i < codes.Length; i++) {
            byte[] b = Encoding.UTF8.GetBytes(values[i]);
            if (b.Length > 60000) Array.Resize(ref b, 60000);
            o.Write((ushort)codes[i]); o.Write((ushort)b.Length); o.Write(b);
            for (int j = 0; j < (4 - b.Length % 4) % 4; j++) o.Write((byte)0);
        }
        o.Write((uint)0);
        return ms.ToArray();
    }
}

// Umwandlung im Hintergrund, damit die Oberfläche bedienbar bleibt
public sealed class ConvertJob {
    public volatile bool Done;
    public EtlConvertResult Result;
    public string Error;
    string etl, pcap; int timeout;
    Dictionary<uint, string> ifn, pn;
    public static ConvertJob Start(string etl, string pcap, int timeoutSec, Dictionary<uint, string> ifn, Dictionary<uint, string> pn) {
        ConvertJob j = new ConvertJob();
        j.etl = etl; j.pcap = pcap; j.timeout = timeoutSec; j.ifn = ifn; j.pn = pn;
        System.Threading.Thread t = new System.Threading.Thread(j.Run);
        t.IsBackground = true; t.Start();
        return j;
    }
    void Run() {
        try { Result = EtlToPcapng.Convert(etl, pcap, timeout, ifn, pn); }
        catch (Exception ex) { Error = ex.Message; }
        Done = true;
    }
}

public sealed class FlowInfo { public string Key; public long Packets, Bytes, Retrans, Rst; }

// Einfache Auswertung einer pcapng-Datei (Ethernet/IPv4/IPv6/TCP/UDP/ICMP/DNS), läuft im Hintergrund
public sealed class PcapStat {
    public volatile bool Done;
    public string Error;
    public long Pos, Len;
    public long Packets, Bytes, TcpPackets, UdpPackets, Retrans, Rst, Syn, DnsResponses, DnsErrors, IcmpUnreach, IcmpTtl, Skipped, Wlan;
    public long FirstUs = -1, LastUs;
    public Dictionary<string, long[]> Protos = new Dictionary<string, long[]>();
    public Dictionary<string, long[]> Services = new Dictionary<string, long[]>();
    public Dictionary<string, long> DnsFail = new Dictionary<string, long>();
    public Dictionary<string, long> IcmpMsgs = new Dictionary<string, long>();
    public Dictionary<string, FlowInfo> Flows = new Dictionary<string, FlowInfo>();
    Dictionary<string, uint> maxNext = new Dictionary<string, uint>();
    string path;
    static readonly Dictionary<int, string> Svc = BuildSvc();

    static Dictionary<int, string> BuildSvc() {
        Dictionary<int, string> d = new Dictionary<int, string>();
        d[20] = "FTP"; d[21] = "FTP"; d[22] = "SSH"; d[25] = "SMTP"; d[53] = "DNS"; d[67] = "DHCP"; d[68] = "DHCP"; d[80] = "HTTP";
        d[88] = "Kerberos"; d[110] = "POP3"; d[123] = "NTP"; d[135] = "RPC"; d[137] = "NetBIOS"; d[138] = "NetBIOS"; d[139] = "NetBIOS";
        d[143] = "IMAP"; d[389] = "LDAP"; d[443] = "HTTPS/QUIC"; d[445] = "SMB"; d[587] = "SMTP"; d[636] = "LDAPS"; d[993] = "IMAPS";
        d[995] = "POP3S"; d[1900] = "SSDP"; d[3389] = "RDP"; d[5353] = "mDNS"; d[5355] = "LLMNR"; d[8080] = "HTTP-Alt"; d[8443] = "HTTPS-Alt";
        return d;
    }

    public static PcapStat Start(string path) {
        PcapStat s = new PcapStat();
        s.path = path;
        System.Threading.Thread t = new System.Threading.Thread(s.Run);
        t.IsBackground = true; t.Start();
        return s;
    }

    void Run() {
        try { Parse(); } catch (Exception ex) { Error = ex.Message; }
        Done = true;
    }

    static uint U32(byte[] b, int i) { return (uint)(b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24)); }
    static int B16(byte[] b, int i) { return (b[i] << 8) | b[i + 1]; }
    static uint B32(byte[] b, int i) { return (uint)((b[i] << 24) | (b[i + 1] << 16) | (b[i + 2] << 8) | b[i + 3]); }

    void Parse() {
        using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 20)) {
            Len = fs.Length;
            BinaryReader r = new BinaryReader(fs);
            List<ushort> links = new List<ushort>();
            List<int> tsres = new List<int>();
            byte[] buf = new byte[65536];
            while (fs.Position + 12 <= fs.Length) {
                uint type = r.ReadUInt32();
                uint total = r.ReadUInt32();
                if (total < 12 || total > 64u * 1024 * 1024) break;
                int body = (int)total - 12;
                if (body > buf.Length) buf = new byte[body];
                int got = body > 0 ? r.Read(buf, 0, body) : 0;
                if (got < body) break;
                r.ReadUInt32();
                Pos = fs.Position;
                if (type == 1 && body >= 8) {
                    links.Add((ushort)(buf[0] | (buf[1] << 8)));
                    int res = 6;
                    int o = 8;
                    while (o + 4 <= body) {
                        int code = buf[o] | (buf[o + 1] << 8), ol = buf[o + 2] | (buf[o + 3] << 8);
                        if (code == 0) break;
                        if (code == 9 && ol >= 1 && o + 4 < body) res = buf[o + 4];
                        o += 4 + ((ol + 3) & ~3);
                    }
                    tsres.Add(res);
                } else if (type == 6 && body >= 20) {
                    uint ifid = U32(buf, 0);
                    ulong hi = U32(buf, 4), lo = U32(buf, 8);
                    long ticks = (long)((hi << 32) | lo);
                    uint cap = U32(buf, 12), orig = U32(buf, 16);
                    if (20 + cap > body) cap = (uint)(body - 20);
                    ushort lt = ifid < links.Count ? links[(int)ifid] : (ushort)1;
                    int rs = ifid < tsres.Count ? tsres[(int)ifid] : 6;
                    long us = ticks;
                    if ((rs & 0x80) == 0) { if (rs > 6) { for (int k = 6; k < rs; k++) us /= 10; } else if (rs < 6) { for (int k = rs; k < 6; k++) us *= 10; } }
                    Packet(buf, 20, (int)cap, (int)orig, lt, us);
                }
            }
        }
    }

    void AddTo(Dictionary<string, long[]> d, string key, long bytes) {
        long[] v;
        if (!d.TryGetValue(key, out v)) { v = new long[2]; d[key] = v; }
        v[0]++; v[1] += bytes;
    }

    void AddCount(Dictionary<string, long> d, string key) {
        long v;
        d.TryGetValue(key, out v);
        d[key] = v + 1;
    }

    string ServiceOf(int sp, int dp) {
        string s;
        int lo = Math.Min(sp, dp), hi = Math.Max(sp, dp);
        if (Svc.TryGetValue(lo, out s)) return s;
        if (Svc.TryGetValue(hi, out s)) return s;
        return "Andere Ports";
    }

    static string Ip4(byte[] b, int i) { return b[i] + "." + b[i + 1] + "." + b[i + 2] + "." + b[i + 3]; }
    static string Ip6(byte[] b, int i) {
        byte[] a = new byte[16]; Array.Copy(b, i, a, 0, 16);
        return new System.Net.IPAddress(a).ToString();
    }

    static string QName(byte[] b, int i, int end) {
        StringBuilder sb = new StringBuilder();
        int guard = 0;
        while (i < end && guard++ < 40) {
            int l = b[i];
            if (l == 0 || (l & 0xC0) != 0) break;
            if (i + 1 + l > end) break;
            if (sb.Length > 0) sb.Append('.');
            sb.Append(Encoding.ASCII.GetString(b, i + 1, l));
            i += 1 + l;
            if (sb.Length > 120) break;
        }
        return sb.Length == 0 ? "(leer)" : sb.ToString();
    }

    void Packet(byte[] b, int off, int cap, int orig, ushort lt, long us) {
        Packets++; Bytes += orig;
        if (FirstUs < 0 || us < FirstUs) FirstUs = us;
        if (us > LastUs) LastUs = us;
        if (lt != 1 && lt != 101) { Wlan++; AddTo(Protos, "WLAN 802.11 (Rahmenebene, nicht ausgewertet)", orig); return; }
        int p = off, end = off + cap, et;
        if (lt == 1) {
            if (cap < 14) { Skipped++; return; }
            et = (b[p + 12] << 8) | b[p + 13]; p += 14;
            while ((et == 0x8100 || et == 0x88A8) && p + 4 <= end) { et = (b[p + 2] << 8) | b[p + 3]; p += 4; }
        } else {
            if (cap < 1) { Skipped++; return; }
            int v = b[p] >> 4; et = v == 4 ? 0x0800 : v == 6 ? 0x86DD : 0;
        }
        if (et == 0x0806) { AddTo(Protos, "ARP", orig); return; }
        int proto, l4, l4len; string src, dst;
        if (et == 0x0800) {
            if (p + 20 > end) { Skipped++; return; }
            int ihl = (b[p] & 15) * 4; proto = b[p + 9];
            int tot = (b[p + 2] << 8) | b[p + 3];
            int frag = ((b[p + 6] & 0x1F) << 8) | b[p + 7];
            src = Ip4(b, p + 12); dst = Ip4(b, p + 16);
            l4 = p + ihl;
            l4len = tot >= ihl ? tot - ihl : orig - (l4 - off);
            if (frag != 0) { AddTo(Protos, "IPv4-Fragmente", orig); return; }
        } else if (et == 0x86DD) {
            if (p + 40 > end) { Skipped++; return; }
            proto = b[p + 6]; int plen = (b[p + 4] << 8) | b[p + 5];
            src = Ip6(b, p + 8); dst = Ip6(b, p + 24);
            l4 = p + 40;
            int guard = 0;
            while ((proto == 0 || proto == 43 || proto == 60) && l4 + 2 <= end && guard++ < 4) {
                int nh = b[l4], hl = (b[l4 + 1] + 1) * 8; l4 += hl; plen -= hl; proto = nh;
            }
            if (proto == 44) { AddTo(Protos, "IPv6-Fragmente", orig); return; }
            l4len = plen > 0 ? plen : orig - (l4 - off);
        } else {
            AddTo(Protos, "Andere (Ethertype 0x" + et.ToString("X4") + ")", orig); return;
        }
        if (proto == 6) {
            if (l4 + 20 > end) { Skipped++; return; }
            TcpPackets++;
            int sp = B16(b, l4), dp = B16(b, l4 + 2);
            uint seq = B32(b, l4 + 4);
            int flags = b[l4 + 13], doff = (b[l4 + 12] >> 4) * 4;
            int payload = l4len - doff; if (payload < 0) payload = 0;
            AddTo(Protos, "TCP", orig); AddTo(Services, "TCP " + ServiceOf(sp, dp), orig);
            string e1 = src + ":" + sp, e2 = dst + ":" + dp;
            string dirKey = e1 + ">" + e2;
            string fk = string.CompareOrdinal(e1, e2) <= 0 ? "TCP " + e1 + " <-> " + e2 : "TCP " + e2 + " <-> " + e1;
            FlowInfo f = Flow(fk);
            if (f != null) { f.Packets++; f.Bytes += orig; }
            if ((flags & 2) != 0 && (flags & 0x10) == 0) Syn++;
            if ((flags & 4) != 0) { Rst++; if (f != null) f.Rst++; }
            if ((flags & 2) != 0) { maxNext[dirKey] = seq + 1; }
            else if (payload > 0) {
                uint endSeq = seq + (uint)payload, m;
                if (maxNext.TryGetValue(dirKey, out m)) {
                    if ((int)(endSeq - m) <= 0) { Retrans++; if (f != null) f.Retrans++; }
                    else maxNext[dirKey] = endSeq;
                } else if (maxNext.Count < 400000) maxNext[dirKey] = endSeq;
            }
        } else if (proto == 17) {
            if (l4 + 8 > end) { Skipped++; return; }
            UdpPackets++;
            int sp = B16(b, l4), dp = B16(b, l4 + 2);
            AddTo(Protos, "UDP", orig); AddTo(Services, "UDP " + ServiceOf(sp, dp), orig);
            string e1 = src + ":" + sp, e2 = dst + ":" + dp;
            string fk = string.CompareOrdinal(e1, e2) <= 0 ? "UDP " + e1 + " <-> " + e2 : "UDP " + e2 + " <-> " + e1;
            FlowInfo f = Flow(fk);
            if (f != null) { f.Packets++; f.Bytes += orig; }
            if ((sp == 53 || dp == 53) && l4 + 8 + 12 <= end) {
                int fl = B16(b, l4 + 10);
                if ((fl & 0x8000) != 0) {
                    DnsResponses++;
                    int rc = fl & 0xF;
                    if (rc > 0) { DnsErrors++; AddCount(DnsFail, QName(b, l4 + 8 + 12, end) + " (Fehlercode " + rc + ")"); }
                }
            }
        } else if (proto == 1) {
            if (l4 + 2 > end) { Skipped++; return; }
            AddTo(Protos, "ICMP", orig);
            int ty = b[l4], co = b[l4 + 1];
            if (ty == 3) { IcmpUnreach++; AddCount(IcmpMsgs, "Ziel nicht erreichbar (Code " + co + "): " + src + " -> " + dst); }
            else if (ty == 11) { IcmpTtl++; AddCount(IcmpMsgs, "TTL abgelaufen: " + src + " -> " + dst); }
        } else if (proto == 58) {
            AddTo(Protos, "ICMPv6", orig);
        } else {
            AddTo(Protos, "IP-Protokoll " + proto, orig);
        }
    }

    FlowInfo Flow(string key) {
        FlowInfo f;
        if (Flows.TryGetValue(key, out f)) return f;
        if (Flows.Count >= 200000) return null;
        f = new FlowInfo(); f.Key = key; Flows[key] = f;
        return f;
    }
}
}
'@

# Kompiliert den eingebauten Wandler und die Auswertung einmalig (C# per Add-Type, keine Zusatzprogramme nötig)
function NcInit {
    if ('Sippicom.PcapStat' -as [type]) { return $true }
    try { Add-Type -TypeDefinition $script:NcSource -Language CSharp -ErrorAction Stop; return $true } catch { return $false }
}
# Wandelt eine netsh-trace-ETL in pcapng um (im Hintergrund, Oberfläche bleibt bedienbar); liefert das Ergebnisobjekt oder $null
function NcConvertEtl([string]$ncvEtl, [string]$ncvPcap) {
    if (-not (NcInit)) { return $null }
    $ncvNames = New-Object 'System.Collections.Generic.Dictionary[uint32,string]'
    try { foreach ($ncvA in @(Get-NetAdapter -IncludeHidden -ErrorAction SilentlyContinue)) { $ncvNames[[uint32]$ncvA.ifIndex] = $ncvA.Name } } catch {}
    $ncvProc = New-Object 'System.Collections.Generic.Dictionary[uint32,string]'
    foreach ($ncvP in @(Get-Process -ErrorAction SilentlyContinue)) { $ncvProc[[uint32]$ncvP.Id] = $ncvP.ProcessName }
    $ncvJob = [Sippicom.ConvertJob]::Start($ncvEtl, $ncvPcap, 1800, $ncvNames, $ncvProc)
    $ncvSw = [Diagnostics.Stopwatch]::StartNew()
    while (-not $ncvJob.Done) { Msg "Wandle Mitschnitt in pcapng um ... ($([int]$ncvSw.Elapsed.TotalSeconds) s)" $null; [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 200 }
    return $ncvJob
}
# Auswertung einer pcapng-Datei (im Hintergrund); liefert das Statistikobjekt oder $null
function NcStat([string]$nsFile) {
    if (-not (NcInit)) { return $null }
    $nsJob = [Sippicom.PcapStat]::Start($nsFile)
    while (-not $nsJob.Done) {
        $nsPct = 0; if ($nsJob.Len -gt 0) { $nsPct = [int](100 * $nsJob.Pos / $nsJob.Len) }
        Msg "Werte Mitschnitt aus ... $nsPct %" $null; [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 150
    }
    return $nsJob
}
# Menschenlesbare Größe
function NcSize([double]$nzB) {
    if ($nzB -ge 1GB) { return ('{0:N2} GB' -f ($nzB / 1GB)) }
    if ($nzB -ge 1MB) { return ('{0:N1} MB' -f ($nzB / 1MB)) }
    return ('{0:N0} KB' -f ($nzB / 1KB))
}

# Ausführliche Analyse einer Aufzeichnung als Textdatei (Protokolle, Dienste, Verbindungen, Neuübertragungen, Resets, DNS-Fehler, ICMP)
# Ergebnis: Pfad der Datei in $script:ncAna; Rückgabe ist die Zeilenliste (für die Anzeige im Protokoll).
$script:ncAna = $null
function NcAnalyseText($naSt, [string]$naFile, [string]$naOut) {
    $naL = New-Object Collections.Generic.List[string]
    $naDur = 0.0; if ($naSt.FirstUs -ge 0 -and $naSt.LastUs -gt $naSt.FirstUs) { $naDur = ($naSt.LastUs - $naSt.FirstUs) / 1000000.0 }
    $naL.Add('== Mitschnitt-Analyse (Diagnosezentrum) ==')
    $naL.Add("Datei   : $(Split-Path $naFile -Leaf)")
    $naL.Add("Rechner : $env:COMPUTERNAME  |  Erstellt: $(Get-Date -Format 'dd.MM.yyyy HH:mm')  |  Diagnosezentrum $appVer")
    $naL.Add('Hinweis : Eigene Auswertung (kein Wireshark). Neuübertragungen werden aus den TCP-Folgenummern geschätzt; Verschlüsselte Inhalte werden nicht gelesen.')
    $naL.Add('')
    $naL.Add('== Überblick ==')
    $naL.Add(('Pakete            : {0:N0}' -f $naSt.Packets))
    $naL.Add(('Datenmenge        : {0}' -f (NcSize $naSt.Bytes)))
    $naL.Add(('Dauer             : {0:N1} s' -f $naDur))
    if ($naDur -gt 0) { $naL.Add(('Durchsatz (Ø)     : {0:N1} Mbit/s, {1:N0} Pakete/s' -f (($naSt.Bytes * 8 / 1000000.0) / $naDur), ($naSt.Packets / $naDur))) }
    $naL.Add(('TCP-Pakete        : {0:N0}  |  UDP-Pakete: {1:N0}' -f $naSt.TcpPackets, $naSt.UdpPackets))
    $naPct = 0.0; if ($naSt.TcpPackets -gt 0) { $naPct = 100.0 * $naSt.Retrans / $naSt.TcpPackets }
    $naL.Add(('Neuübertragungen  : {0:N0} ({1:N1} % der TCP-Pakete)' -f $naSt.Retrans, $naPct))
    $naL.Add(('TCP-Resets        : {0:N0}  |  Verbindungsaufbauten (SYN): {1:N0}' -f $naSt.Rst, $naSt.Syn))
    $naL.Add(('DNS-Antworten     : {0:N0}, davon mit Fehlercode: {1:N0}' -f $naSt.DnsResponses, $naSt.DnsErrors))
    $naL.Add(('ICMP              : Ziel nicht erreichbar {0:N0}, TTL abgelaufen {1:N0}' -f $naSt.IcmpUnreach, $naSt.IcmpTtl))
    if ($naSt.Wlan -gt 0) { $naL.Add(('Hinweis            : {0:N0} Pakete liegen auf WLAN-Rahmenebene (802.11) und sind nicht ausgewertet.' -f $naSt.Wlan)) }
    if ($naSt.Skipped -gt 0) { $naL.Add(('Nicht auswertbar   : {0:N0} Pakete (zu kurz abgeschnitten)' -f $naSt.Skipped)) }
    $naL.Add('')
    $naL.Add('== Protokolle (Pakete | Datenmenge) ==')
    foreach ($naE in @($naSt.Protos.GetEnumerator() | Sort-Object { $_.Value[1] } -Descending | Select-Object -First 20)) { $naL.Add(('  {0,-48} {1,10:N0} | {2}' -f $naE.Key, $naE.Value[0], (NcSize $naE.Value[1]))) }
    $naL.Add('')
    $naL.Add('== Dienste nach Port (Pakete | Datenmenge) ==')
    foreach ($naE in @($naSt.Services.GetEnumerator() | Sort-Object { $_.Value[1] } -Descending | Select-Object -First 20)) { $naL.Add(('  {0,-48} {1,10:N0} | {2}' -f $naE.Key, $naE.Value[0], (NcSize $naE.Value[1]))) }
    $naL.Add('')
    $naL.Add('== Größte Verbindungen (Datenmenge | Pakete | Neuübertragungen | Resets) ==')
    foreach ($naF in @($naSt.Flows.Values | Sort-Object Bytes -Descending | Select-Object -First 25)) { $naL.Add(('  {0} | {1} | {2:N0} | {3:N0} | {4:N0}' -f $naF.Key, (NcSize $naF.Bytes), $naF.Packets, $naF.Retrans, $naF.Rst)) }
    $naL.Add('')
    $naL.Add('== Verbindungen mit den meisten Neuübertragungen ==')
    $naRt = @($naSt.Flows.Values | Where-Object { $_.Retrans -gt 0 } | Sort-Object Retrans -Descending | Select-Object -First 15)
    if ($naRt.Count -eq 0) { $naL.Add('  (keine)') } else { foreach ($naF in $naRt) { $naL.Add(('  {0} | Neuübertragungen {1:N0} von {2:N0} Paketen' -f $naF.Key, $naF.Retrans, $naF.Packets)) } }
    $naL.Add('')
    $naL.Add('== Verbindungen mit TCP-Resets ==')
    $naRs = @($naSt.Flows.Values | Where-Object { $_.Rst -gt 0 } | Sort-Object Rst -Descending | Select-Object -First 15)
    if ($naRs.Count -eq 0) { $naL.Add('  (keine)') } else { foreach ($naF in $naRs) { $naL.Add(('  {0} | Resets {1:N0}' -f $naF.Key, $naF.Rst)) } }
    $naL.Add('')
    $naL.Add('== DNS-Fehlschläge (Name | Anzahl) ==')
    if ($naSt.DnsFail.Count -eq 0) { $naL.Add('  (keine)') } else { foreach ($naE in @($naSt.DnsFail.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 30)) { $naL.Add(('  {0}  (x{1})' -f $naE.Key, $naE.Value)) } }
    $naL.Add('')
    $naL.Add('== ICMP-Meldungen ==')
    if ($naSt.IcmpMsgs.Count -eq 0) { $naL.Add('  (keine)') } else { foreach ($naE in @($naSt.IcmpMsgs.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 30)) { $naL.Add(('  {0}  (x{1})' -f $naE.Key, $naE.Value)) } }
    try { [IO.File]::WriteAllLines($naOut, $naL, (New-Object Text.UTF8Encoding($true))); $script:ncAna = $naOut } catch {}
    return $naL
}
# Live-Zeile mit Restzeit (orange, ganz unten im Protokoll), während ein Mitschnitt läuft
function NcLive([string]$nlLabel, [int]$nlSec, $nlProc = $null) {
    $nlMk = "  $([char]0xBB) "
    $nlRo = $box.ReadOnly; $box.ReadOnly = $false
    if ($box.TextLength -gt 0 -and $box.Text[$box.TextLength - 1] -ne "`n") { $box.SelectionStart = $box.TextLength; $box.SelectionLength = 0; $box.AppendText("`n") }
    $nlPos = $box.TextLength; $nlSw = [Diagnostics.Stopwatch]::StartNew(); $nlSpin = @('|', '/', '-', '\'); $nlI = 0
    # Stopp-Knopf einblenden (vorzeitiges Beenden)
    $script:ncStop = $false; $btnStop.Enabled = $true; $btnStop.Text = 'Mitschnitt stoppen'; $btnStop.Visible = $true; $btnStop.BringToFront()
    while ($nlSw.Elapsed.TotalSeconds -lt $nlSec -and -not $script:ncStop -and -not ($nlProc -and $nlProc.HasExited)) {
        $nlI++; $nlLeft = [int][math]::Ceiling($nlSec - $nlSw.Elapsed.TotalSeconds)
        $nlLine = "$nlMk$($nlSpin[$nlI % 4])  $nlLabel läuft - noch $nlLeft s von $nlSec s (Knopf ""Mitschnitt stoppen"" beendet vorzeitig) ..."
        Msg "$nlLabel läuft - noch $nlLeft s ..." $null
        $hdr.Tag.Sub = "$nlLabel läuft - noch $nlLeft s ..."; $hdr.Invalidate()
        if ($nlPos -gt $box.TextLength) { $nlPos = $box.TextLength }
        $box.Select($nlPos, ($box.TextLength - $nlPos)); $box.SelectionColor = $or; $box.SelectionFont = $fM; $box.SelectedText = $nlLine
        [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 250
    }
    $script:ncLen = [int][math]::Round($nlSw.Elapsed.TotalSeconds); $btnStop.Visible = $false
    $nlIdx = $box.Text.LastIndexOf($nlMk)
    if ($nlIdx -ge 0) { $nlPos = $nlIdx }
    if ($nlPos -gt $box.TextLength) { $nlPos = $box.TextLength }
    $box.Select($nlPos, ($box.TextLength - $nlPos)); $box.SelectedText = ''; $box.SelectionStart = $box.TextLength
    if ($box.TextLength -gt 0 -and $box.Text[$box.TextLength - 1] -ne "`n") { $box.SelectionStart = $box.TextLength; $box.SelectionLength = 0; $box.AppendText("`n") }
    $box.ReadOnly = $nlRo
}
# Paketmitschnitt mit den Bordmitteln von Windows: pktmon (Ergebnis .pcapng), ersatzweise netsh trace (die .etl wird mit dem eingebauten Wandler in .pcapng umgewandelt).
# Erfasst an den Netzwerkkarten ganze Pakete (wie NetCapture), Ringpuffer. Braucht Administratorrechte.
# Ergebnis: $script:ncFile (Pfad der Mitschnittdatei oder $null); Meldungen gehen in die Ausgabe.
$script:ncFile = $null
function NcCapture([int]$ncSec) {
    $script:ncFile = $null
    BkDir 'Mitschnitt' 'C:\SippicomInstall\mitschnitt'
    if (-not $script:bkLast) { F 'Paketmitschnitt nicht möglich: Zielordner konnte nicht angelegt werden.' 'Rechte und Speicherplatz auf C: prüfen.'; return }
    $ncDir = $script:bkLast
    $ncBase = Join-Path $ncDir "Mitschnitt_${env:COMPUTERNAME}_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    $ncEtl = "$ncBase.etl"; $ncPcap = "$ncBase.pcapng"
    $ncPkt = Join-Path $env:SystemRoot 'System32\PktMon.exe'; $ncNetsh = Join-Path $env:SystemRoot 'System32\netsh.exe'
    $ncActive = 'C:\SippicomInstall\Mitschnitt.aktiv'
    # Verfahren wählen: pktmon nur, wenn es pcapng erzeugen kann
    $ncMeth = 'netsh'
    if (Test-Path -LiteralPath $ncPkt) {
        $ncH = @(RunTool 'Prüfung' $ncPkt 'etl2pcap help' $script:oemEnc)
        if (($ncH -join ' ') -match '(?i)pcapng') { $ncMeth = 'pktmon' }
    }
    if ($ncMeth -eq 'pktmon') { KV 'Methode' 'pktmon, ganze Pakete (Ergebnis .pcapng)' } else { KV 'Methode' 'netsh trace, ganze Pakete (pktmon fehlt oder kann kein pcapng; die .etl wird in .pcapng umgewandelt)' }
    # Hängengebliebenen Mitschnitt eines hart beendeten Laufs aufräumen
    if (Test-Path -LiteralPath $ncActive) {
        $ncOld = (Get-Content -LiteralPath $ncActive -Raw -ErrorAction SilentlyContinue) -split '\|'
        if (-not (Get-Process -Id ([int]$ncOld[0]) -ErrorAction SilentlyContinue)) {
            'Hinweis: Ein früherer Mitschnitt wurde nicht sauber beendet und wird jetzt gestoppt.'
            if ($ncOld[1] -eq 'pktmon') { [void](RunTool 'Aufräumen' $ncPkt 'stop' $script:oemEnc); [void](RunTool 'Aufräumen' $ncPkt 'filter remove' $script:oemEnc) }
            else { [void](RunTool 'Aufräumen' $ncNetsh 'trace stop' $script:oemEnc) }
        }
        Remove-Item -LiteralPath $ncActive -Force -ErrorAction SilentlyContinue
    }
    # Platz prüfen (Mitschnitt, Umwandlung und ZIP brauchen etwa das 2,5-fache des Ringpuffers)
    $ncSize = 1024
    try {
        $ncFree = [math]::Floor((New-Object IO.DriveInfo([IO.Path]::GetPathRoot($ncDir))).AvailableFreeSpace / 1MB)
        if ($ncFree -lt ($ncSize * 2.5 + 200)) {
            $ncSize = [int][math]::Floor(($ncFree - 200) / 2.5)
            if ($ncSize -lt 50) { F "Zu wenig freier Speicher für einen Paketmitschnitt ($ncFree MB frei)." 'Speicherplatz auf C: freigeben (mindestens 400 MB) und den Mitschnitt wiederholen.'; return }
            "Hinweis: Wenig freier Speicher, der Ringpuffer wurde auf $ncSize MB verkleinert."
        }
    } catch {}
    # Starten
    $ncOk = $false
    if ($ncMeth -eq 'pktmon') {
        [void](RunTool 'Mitschnitt' $ncPkt 'filter remove' $script:oemEnc)
        $ncR = @(RunTool 'Mitschnitt' $ncPkt ('start --capture --comp nics --pkt-size 0 --file-name "{0}" --file-size {1} --log-mode circular' -f $ncEtl, $ncSize) $script:oemEnc)
    } else {
        $ncR = @(RunTool 'Mitschnitt' $ncNetsh ('trace start capture=yes tracefile="{0}" maxsize={1} filemode=circular overwrite=yes report=disabled correlation=disabled' -f $ncEtl, $ncSize) $script:oemEnc)
    }
    if ($script:toolCode -eq 0) { $ncOk = $true }
    else {
        foreach ($ncL in $ncR | Select-Object -First 5) { "  $ncL" }
        KV 'Ergebnis' 'FEHLER - Mitschnitt konnte nicht gestartet werden'
        FS 'Der Paketmitschnitt konnte nicht gestartet werden.' 'Läuft schon ein anderer Mitschnitt? Dann als Administrator "pktmon stop" bzw. "netsh trace stop" ausführen und wiederholen.'
        if ($ncMeth -eq 'pktmon') { [void](RunTool 'Aufräumen' $ncPkt 'filter remove' $script:oemEnc) }
        return
    }
    try { [IO.File]::WriteAllText($ncActive, "$PID|$ncMeth") } catch {}
    KV 'Dauer' "$ncSec Sekunden (ganze Pakete, Ringpuffer $ncSize MB)"
    $ncCnt = @()
    try { NcLive 'Mitschnitt' $ncSec }
    finally {
        $btnStop.Visible = $false
        # Beenden in jedem Fall
        if ($ncMeth -eq 'pktmon') {
            $ncCnt = @(RunTool 'Mitschnitt beenden' $ncPkt 'counters' $script:oemEnc)
            [void](RunTool 'Mitschnitt beenden' $ncPkt 'stop' $script:oemEnc)
            [void](RunTool 'Mitschnitt beenden' $ncPkt 'filter remove' $script:oemEnc)
        } else { [void](RunTool 'Mitschnitt beenden' $ncNetsh 'trace stop' $script:oemEnc) }
        Remove-Item -LiteralPath $ncActive -Force -ErrorAction SilentlyContinue
    }
    if ($script:ncStop) { "Hinweis: Mitschnitt vorzeitig beendet nach $($script:ncLen) s (geplant: $ncSec s)." }
    # Ergebnisdatei bestimmen (pktmon: .etl in .pcapng umwandeln)
    if (-not (Test-Path -LiteralPath $ncEtl)) {
        KV 'Ergebnis' 'FEHLER - keine Mitschnittdatei vorhanden'
        FS 'Der Paketmitschnitt hat keine Datei geliefert.' 'Administratorrechte, freien Speicher und laufende Mitschnitte (pktmon status) prüfen und wiederholen.'
        return
    }
    if ($ncMeth -eq 'pktmon') {
        [void](RunTool 'Umwandlung' $ncPkt ('etl2pcap "{0}" --out "{1}"' -f $ncEtl, $ncPcap) $script:oemEnc)
        if ($script:toolCode -eq 0 -and (Test-Path -LiteralPath $ncPcap)) { $script:ncFile = $ncPcap; Remove-Item -LiteralPath $ncEtl -Force -ErrorAction SilentlyContinue }
        else { 'Hinweis: Die Umwandlung in pcapng ist fehlgeschlagen, die .etl-Datei bleibt erhalten.'; $script:ncFile = $ncEtl }
    } else {
        # netsh trace: ETL mit dem eingebauten Wandler in pcapng umwandeln (mit Richtung und PID/Prozess je Paket)
        $ncCv = NcConvertEtl $ncEtl $ncPcap
        if ($ncCv -and $ncCv.Result -and $ncCv.Result.Packets -gt 0 -and (Test-Path -LiteralPath $ncPcap)) {
            $script:ncFile = $ncPcap
            KV 'Umwandlung' ('OK - {0:N0} Pakete an {1} Netzwerkkarte(n)' -f $ncCv.Result.Packets, $ncCv.Result.Interfaces)
            if ($ncCv.Result.TimedOut -or $ncCv.Result.Error) { 'Hinweis: Die Umwandlung war unvollständig; die .etl-Datei bleibt zusätzlich erhalten.' } else { Remove-Item -LiteralPath $ncEtl -Force -ErrorAction SilentlyContinue }
        } else {
            'Hinweis: Die Umwandlung in pcapng ist fehlgeschlagen oder lieferte keine Pakete, die .etl-Datei bleibt erhalten (mit Wireshark ab 4.2 oder etl2pcapng öffnen).'
            $script:ncFile = $ncEtl
        }
    }
    if ($ncCnt.Count) {
        ''
        'Zähler von pktmon (Pakete, Bytes, Verwürfe je Komponente):'
        foreach ($ncL in $ncCnt | Where-Object { $_ -match '\S' } | Select-Object -First 30) { "  $($ncL.TrimEnd())" }
    }
}

# ---------- Diagnosen und Reparatur-Werkzeuge ----------
# c = Gruppe in der Seitenleiste; r = verändert das System (Bestätigung); x = Zusatzwerkzeug ohne Änderung.
# Einträge mit r oder x erscheinen im Reiter REPARATUR, alle anderen im Reiter DIAGNOSEN.
$diag = @(
    @{ k = 'System'; t = 'System und Datenträger'; c = 'GERÄT'; f = {
            $os = Get-CimInstance Win32_OperatingSystem; $cs = Get-CimInstance Win32_ComputerSystem
            $bn = [int]$os.BuildNumber; $nm = $os.Caption; if ($bn -ge 22000) { $nm = $nm -replace 'Windows 10', 'Windows 11' }
            $up = (Get-Date) - $os.LastBootUpTime; $rb = PendReboot
            KV 'Computer' $env:COMPUTERNAME
            KV 'Benutzer' "$env:USERDOMAIN\$env:USERNAME"
            KV 'Hersteller' "$($cs.Manufacturer) $($cs.Model)"
            KV 'Betriebssystem' "$nm (Build $bn)"
            KV 'Letzter Start' "$($os.LastBootUpTime.ToString('dd.MM.yyyy HH:mm')) ($([int][math]::Floor($up.TotalDays)) Tage $($up.Hours) Std.)"
            $ram = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1); $fr = [math]::Round($os.FreePhysicalMemory / 1MB, 1)
            KV 'Arbeitsspeicher' "$fr GB frei von $ram GB"
            foreach ($dk in Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3') {
                $pc = [math]::Round(100 * $dk.FreeSpace / $dk.Size, 0)
                "Laufwerk $($dk.DeviceID) $([math]::Round($dk.FreeSpace/1GB,1)) GB frei von $([math]::Round($dk.Size/1GB,1)) GB ($pc %)"
                if ($pc -lt 5) { FS "Laufwerk $($dk.DeviceID) ist fast voll ($pc % frei)." 'Speicherplatz sofort freigeben (Datenträgerbereinigung, große Dateien archivieren) oder Laufwerk erweitern.' }
                elseif ($pc -lt 10) { F "Laufwerk $($dk.DeviceID) wird knapp ($pc % frei)." 'Speicherplatz freigeben (Datenträgerbereinigung, große Dateien archivieren).' }
            }
            if ($up.TotalDays -gt 14) { F 'Seit über 14 Tagen kein Neustart.' 'Rechner neu starten (Updates und Treiber werden erst dann vollständig aktiv).' }
            if ($rb) { F 'Ein Neustart steht aus.' 'Rechner zeitnah neu starten.' }
            if ($ram -gt 0 -and ($fr / $ram) -lt 0.1) { F 'Weniger als 10 % Arbeitsspeicher frei.' 'Speicherhungrige Programme beenden; bei dauerhaft knappem Speicher RAM aufrüsten.' }
            $sv = @(Get-CimInstance Win32_Service | Where-Object { $_.StartMode -eq 'Auto' -and $_.State -ne 'Running' } | Sort-Object DisplayName)
            if ($sv.Count) {
                ''
                'Info: automatisch startende Dienste, die gerade nicht laufen (teils normal, z. B. verzögerter Start):'
                foreach ($x in $sv | Select-Object -First 15) { "  $($x.DisplayName) ($($x.Name))" }
            }
        } },
    @{ k = 'Hardware'; t = 'Hardware und Gesundheit'; c = 'GERÄT'; f = {
            $cp = Get-CimInstance Win32_Processor | Select-Object -First 1
            KV 'Prozessor' "$($cp.Name.Trim()) ($($cp.NumberOfCores) Kerne, Auslastung $($cp.LoadPercentage) %)"
            if ($cp.LoadPercentage -gt 90) { FLow "Prozessorauslastung sehr hoch ($($cp.LoadPercentage) %)." 'Prozesse mit hoher Last im Task-Manager prüfen; bei Dauerlast Ursache (Update, Indexierung, Schadsoftware) klären.' }
            ''
            'Speicherhungrigste Prozesse (Name | Arbeitsspeicher):'
            $pr = @(Get-Process | Group-Object ProcessName | ForEach-Object { [pscustomobject]@{ N = $_.Name; M = ($_.Group | Measure-Object WorkingSet64 -Sum).Sum } } | Sort-Object M -Descending | Select-Object -First 5)
            foreach ($g in $pr) { '  {0} | {1} MB' -f $g.N, [int]($g.M / 1MB) }
            ''
            'Datenträger (Name | Typ | Zustand | Größe):'
            foreach ($pd in Get-PhysicalDisk) {
                '  {0} | {1} | {2} | {3} GB' -f $pd.FriendlyName, $pd.MediaType, $pd.HealthStatus, [math]::Round($pd.Size / 1GB)
                if ($pd.HealthStatus -ne 'Healthy') { FS "Datenträger $($pd.FriendlyName) meldet Zustand $($pd.HealthStatus)." 'Sofort Datensicherung durchführen und Datenträger austauschen.' }
            }
            $bt = Get-CimInstance Win32_Battery
            if ($bt) {
                ''
                KV 'Akku' "$($bt.EstimatedChargeRemaining) % geladen (Status $($bt.BatteryStatus))"
                $full = Get-CimInstance -Namespace root/wmi -ClassName BatteryFullChargedCapacity; $des = Get-CimInstance -Namespace root/wmi -ClassName BatteryStaticData
                if ($full -and $des -and $des.DesignedCapacity) {
                    $cap = [int](100 * $full.FullChargedCapacity / $des.DesignedCapacity)
                    KV 'Akku-Kapazität' "$cap % des Originals"
                    if ($cap -lt 60) { F "Akku-Kapazität nur noch $cap % des Originals." 'Akku wegen Verschleiß austauschen lassen.' }
                } else { 'Hinweis: Akku-Kapazität nicht abrufbar.' }
            }
            ''
            'Geräte mit Problemen (Geräte-Manager):'
            $bad = @(Get-CimInstance Win32_PnPEntity | Where-Object { $_.ConfigManagerErrorCode -ne 0 })
            if ($bad.Count) { foreach ($x in $bad | Select-Object -First 10) { '  {0} | Fehlercode {1}' -f $x.Name, $x.ConfigManagerErrorCode; FLow "Gerät mit Problem im Geräte-Manager: $($x.Name) (Fehlercode $($x.ConfigManagerErrorCode))." 'Treiber des Geräts aktualisieren oder neu installieren bzw. Gerät aktivieren; nicht benötigte Geräte können ignoriert werden.' } } else { '  keine' }
        } },
    @{ k = 'Sicherheit'; t = 'Sicherheit und Updates'; c = 'GERÄT'; f = {
            $anyOn = $false
            foreach ($a in @(Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct)) {
                $h = '{0:X6}' -f [int]$a.productState
                $on = ($h.Substring(2, 2) -eq '10'); $upd = ($h.Substring(4, 2) -eq '00')
                if ($on) { $anyOn = $true }
                "Virenschutz: $($a.displayName) | aktiv: $on | Signaturen aktuell: $upd"
                if ($on -and -not $upd) { F "Virenschutz $($a.displayName): Signaturen nicht aktuell." 'Virensignaturen aktualisieren (Update im Virenschutz anstoßen, Internetverbindung prüfen).' }
            }
            if (-not $anyOn) { FS 'Kein aktiver Virenschutz erkannt.' 'Virenschutz sofort aktivieren oder installieren.' }
            $m = Get-MpComputerStatus
            "Defender: Echtzeitschutz $($m.RealTimeProtectionEnabled), Signaturen vom $(if($m.AntivirusSignatureLastUpdated){$m.AntivirusSignatureLastUpdated.ToString('dd.MM.yyyy')})"
            "Neustart ausstehend: $(PendReboot)"
            if (PendReboot) { F 'Ein Neustart steht aus.' 'Rechner zeitnah neu starten.' }
            $fw = @(); $fwBad = @()
            foreach ($fp in Get-NetFirewallProfile) { $fw += "$($fp.Name) $($fp.Enabled)"; if (-not $fp.Enabled) { $fwBad += $fp.Name } }
            "Firewall: $($fw -join ' | ')"
            foreach ($b in $fwBad) { FS "Firewall-Profil $b ist aus." 'Windows-Firewall-Profil aktivieren (sofern keine andere Firewall zentral verwaltet wird).' }
            $uac = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System').EnableLUA
            "UAC aktiv: $($uac -ne 0)"
            if ($uac -eq 0) { FS 'UAC ist deaktiviert.' 'Benutzerkontensteuerung wieder aktivieren (Richtlinie bzw. Registrierung prüfen).' }
        } },
    @{ k = 'Updates'; t = 'Windows-Updates'; c = 'GERÄT'; f = {
            $os = Get-CimInstance Win32_OperatingSystem; $cv = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
            $bn = [int]$os.BuildNumber; $nm = ($os.Caption -replace '^Microsoft\s+', ''); if ($bn -ge 22000) { $nm = $nm -replace 'Windows 10', 'Windows 11' }
            KV 'Version' "$nm $($cv.DisplayVersion) (Build $bn.$($cv.UBR))"
            $hf = @(Get-HotFix | Where-Object { $_.InstalledOn } | Sort-Object InstalledOn -Descending)
            if ($hf.Count) {
                $age = ((Get-Date) - $hf[0].InstalledOn).Days; KV 'Letztes Update' "$($hf[0].HotFixID) ($($hf[0].InstalledOn.ToString('dd.MM.yyyy')), vor $age Tagen)"
                if ($age -gt 120) { FS "Letztes Update ist $age Tage alt." 'Windows-Update sofort ausführen und Update-Dienst bzw. Richtlinien prüfen.' } elseif ($age -gt 60) { F "Letztes Update ist $age Tage alt." 'Windows-Update ausführen und Update-Dienst bzw. Richtlinien prüfen.' }
            } else { KV 'Letztes Update' 'keine Daten' }
            $wu = Get-CimInstance Win32_Service -Filter "Name='wuauserv'"
            "Windows-Update-Dienst: Starttyp $($wu.StartMode), Status $($wu.State)"
            if (PendReboot) { F 'Neustart wegen Updates steht aus.' 'Rechner zeitnah neu starten.' }
            $evs = @(Ev 'System' 30 $null @(19, 20) | Where-Object { $_.ProviderName -eq 'Microsoft-Windows-WindowsUpdateClient' } | Select-Object -First 40)
            $okc = @($evs | Where-Object { $_.Id -eq 19 }).Count; $failc = @($evs | Where-Object { $_.Id -eq 20 }).Count
            ''
            "Update-Verlauf (letzte 40 Einträge): $okc erfolgreich, $failc fehlgeschlagen in 30 Tagen"
            if ($failc) { F "$failc Update-Installationen fehlgeschlagen (30 Tage)." 'Update-Verlauf und Fehlercodes prüfen (Windows-Update-Problembehandlung, freier Speicherplatz).' }
            if ((Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU').NoAutoUpdate -eq 1) { F 'Richtlinie deaktiviert automatische Windows-Updates (NoAutoUpdate=1).' 'Richtlinie prüfen; automatische Updates nur bewusst abschalten (z. B. bei WSUS- oder Intune-Verwaltung).' }
        } },
    @{ k = 'Backup'; t = 'Backup und Verschlüsselung'; c = 'GERÄT'; f = {
            $sh = @(Get-CimInstance Win32_ShadowCopy)
            KV 'Schattenkopien' "$($sh.Count)"
            KV 'VSS-Dienst' "$((Get-Service VSS).Status)"
            KV 'Dateiversionen' "Dienst $((Get-Service fhsvc).Status)"
            KV 'OneDrive' $(if (Get-Process OneDrive) { 'läuft' } else { 'läuft nicht' })
            try { foreach ($bl in Get-BitLockerVolume -ErrorAction Stop) { KV "BitLocker $($bl.MountPoint)" "Schutz $($bl.ProtectionStatus) ($($bl.VolumeStatus))" } } catch { KV 'BitLocker' 'Abfrage nur mit Administratorrechten' }
            $bk = @(Get-Service | Where-Object { $_.DisplayName -match 'Veeam|Acronis|Backup|Datto|Macrium|Cove|N-able|Synology|Altaro|Arcserve' })
            ''
            if ($bk.Count) { 'Sicherungsdienste:'; foreach ($x in $bk | Select-Object -First 8) { "  $($x.DisplayName) ($($x.Status))" } } else { 'Info: keine lokale Sicherungssoftware erkannt (Server-/Cloud-Backup nicht prüfbar).' }
            if ($bk.Count -eq 0 -and $sh.Count -eq 0) { FLow 'Keine lokale Datensicherung erkannt (Server- oder Cloud-Backup lässt sich lokal nicht prüfen).' 'Datensicherung einrichten bzw. vorhandene Sicherungslösung prüfen (lokal oder Cloud).' }
            foreach ($x in $bk | Where-Object { $_.Status -ne 'Running' -and $_.StartType -eq 'Automatic' }) { F "Sicherungsdienst $($x.DisplayName) läuft nicht." 'Dienst der Sicherungssoftware starten und Startart prüfen.' }
        } },
    @{ k = 'Eventlogs'; t = 'Ereignisprotokolle (letzte 3 Tage)'; c = 'GERÄT'; f = {
            $ev = @(@(Ev 'System' 3 @(1, 2) $null) + @(Ev 'Application' 3 @(1, 2) $null) | Sort-Object TimeCreated -Descending)
            "Fehler/kritische Ereignisse: $($ev.Count)"
            if ($ev.Count -gt 100) { F "Ungewöhnlich viele Fehler/kritische Ereignisse ($($ev.Count))." 'Häufigste Fehlerquellen im Protokoll prüfen (siehe Tabelle) und beheben.' }
            ''
            'Wiederholte Fehler (Anzahl | Quelle | ID | zuletzt | Text):'
            $grp = @($ev | Group-Object { "$($_.ProviderName)|$($_.Id)" } | Sort-Object @{ e = 'Count'; Descending = $true }, @{ e = { $_.Group[0].ProviderName } }, @{ e = { [int]$_.Group[0].Id } } | Select-Object -First 8)
            if ($grp.Count -eq 0) { '  keine' }
            foreach ($g in $grp) {
                $e0 = $g.Group[0]
                '  {0}x | {1} | {2} | {3} | {4}' -f $g.Count, $e0.ProviderName, $e0.Id, $e0.TimeCreated.ToString('dd.MM. HH:mm'), (Cut (FirstLine $e0.Message) 120)
                if ($e0.ProviderName -eq 'Service Control Manager' -and $e0.Id -eq 7034) { '     Hinweis: Dienst unerwartet beendet (siehe Abgestürzte Dienste)' }
                if ($g.Count -ge 5) { F "Wiederholt ($($g.Count)x in 3 Tagen): $($e0.ProviderName) ID $($e0.Id) - $(Cut (FirstLine $e0.Message) 90)" 'Ursache der wiederholten Meldung beheben (Ereignis-ID und Quelle recherchieren).' }
            }
            ''
            'Abgestürzte Dienste (Name | Anzahl | Status | Hersteller | Pfad):'
            $crash = @($ev | Where-Object { $_.ProviderName -eq 'Service Control Manager' -and $_.Id -eq 7034 })
            if ($crash.Count -eq 0) { 'Keine.' }
            foreach ($g in @($crash | Group-Object { if ("$($_.Message)" -match '"([^"]+)"') { $Matches[1] } })) {
                $sv = Get-CimInstance Win32_Service | Where-Object { $_.DisplayName -eq $g.Name -or $_.Name -eq $g.Name } | Select-Object -First 1
                $pp = "$($sv.PathName)" -replace '^"([^"]+)".*$', '$1' -replace '^(\S+\.exe).*$', '$1'
                $mf = ''; if ($pp -and (Test-Path $pp)) { $mf = (Get-Item $pp).VersionInfo.CompanyName; if (-not $mf) { $mf = (Split-Path (Split-Path $pp -Parent) -Leaf) + ' (aus Ordnername)' } }
                '{0} | {1}x | {2} | {3} | {4}' -f $g.Name, $g.Count, $(if ($sv) { $sv.State } else { '?' }), $mf, $pp
                F "Dienst '$($g.Name)' ist $($g.Count)x abgestürzt (Hersteller: $mf)." 'Dienst und zugehörige Software aktualisieren oder neu installieren; bei Wiederholung den Hersteller kontaktieren.'
            }
            ''
            'Fehlerhäufungen (5 oder mehr Fehler innerhalb von 10 Minuten):'
            $asc = @($ev | Sort-Object TimeCreated); $i = 0; $cl = @()
            while ($i -lt $asc.Count) {
                $j = $i
                while (($j + 1) -lt $asc.Count -and ($asc[$j + 1].TimeCreated - $asc[$i].TimeCreated).TotalMinutes -le 10) { $j++ }
                $cnt = $j - $i + 1
                if ($cnt -ge 5) { $cl += "  $($asc[$i].TimeCreated.ToString('dd.MM. HH:mm')) | $cnt Fehler innerhalb von 10 Minuten"; $i = $j + 1 } else { $i++ }
            }
            if ($cl.Count) { $cl; F "$($cl.Count) Fehlerhäufung(en) in 3 Tagen." 'Zeitraum der Häufung im Ereignisprotokoll prüfen (Treiber, Netzwerk, Datenträger).' } else { 'Keine.' }
            ''
            'Letzte 10 Fehler (Zeit | Log | ID | Quelle | Text):'
            foreach ($e1 in $ev | Select-Object -First 10) { '{0} | {1} | {2} | {3} | {4}' -f $e1.TimeCreated.ToString('dd.MM. HH:mm'), $e1.LogName, $e1.Id, $e1.ProviderName, (Cut (FirstLine $e1.Message) 110) }
            ''
            'Unerwartete Neustarts/Abstürze (41, 6008, 1001):'
            $un = @(Ev 'System' 3 $null @(41, 6008, 1001) | Where-Object { $_.Id -ne 1001 -or $_.ProviderName -match 'BugCheck' })
            if ($un.Count) { foreach ($e2 in $un) { "  $($e2.TimeCreated.ToString('dd.MM. HH:mm')) | ID $($e2.Id) | $($e2.ProviderName)" }; FS "$($un.Count) unerwartete Neustarts/Abstürze (3 Tage)." 'Ursache klären: Netzteil/Akku, Treiber, Hardware (Speicher, Datenträger) und Absturzabbilder prüfen.' } else { 'Keine gefunden.' }
            $dk = @(Ev 'System' 3 @(1, 2, 3) $null | Where-Object { $_.ProviderName -match '^(disk|Ntfs|storahci|stornvme)$' })
            if ($dk.Count) { FS "$($dk.Count) Datenträger-/NTFS-Fehler (3 Tage)." 'Datenträger prüfen (chkdsk, SMART) und Datensicherung sicherstellen.' }
        } },
    @{ k = 'Netzwerk'; t = 'Netzwerk und Erreichbarkeit'; c = 'NETZWERK'; f = {
            $cfg = @(Get-NetIPConfiguration | Where-Object { $_.NetAdapter.Status -eq 'Up' -and $_.IPv4Address })
            $rows = @($cfg | ForEach-Object { [pscustomobject]@{ InterfaceAlias = $_.InterfaceAlias; IPv4 = (@($_.IPv4Address.IPAddress) -join ', '); Gateway = (@($_.IPv4DefaultGateway.NextHop) -join ', '); DNS = ((@($_.DNSServer.ServerAddresses) | Where-Object { $_ -notmatch ':' }) -join ', ') } })
            ''
            if ($rows.Count) { (($rows | Format-Table -AutoSize | Out-String -Width 250) -split "`r?`n") | ForEach-Object { $_.TrimEnd() } | Where-Object { $_ -ne '' } }
            else { FS 'Keine aktive Netzwerkverbindung mit IPv4-Adresse gefunden.' 'Netzwerkkabel bzw. WLAN, Adapter und DHCP prüfen.' }
            foreach ($c1 in $cfg) {
                $gw1 = "$($c1.IPv4DefaultGateway.NextHop)"
                if ($c1.IPv4Address.IPAddress -like '169.254.*') { FS "Adapter '$($c1.InterfaceAlias)' hat eine APIPA-Adresse (kein DHCP erreicht)." 'DHCP-Server und Netzwerkverbindung prüfen.' }
                if ($gw1) {
                    $okp = Test-Connection $gw1 -Count 1 -Quiet
                    "Ping Gateway $gw1 : $(if($okp){'OK'}else{'KEINE ANTWORT'})"
                    if (-not $okp) { FS "Gateway $gw1 antwortet nicht auf Ping." 'Netzwerkkabel bzw. WLAN, Switch und Router prüfen.' }
                }
                $dns1 = @($c1.DNSServer.ServerAddresses | Where-Object { $_ -notmatch ':' })
                foreach ($dn in $dns1) {
                    $okd = Tcp $dn 53
                    "DNS-Server $dn Port 53 : $(if($okd){'OK'}else{'NICHT ERREICHBAR'})"
                    if (-not $okd) { FS "DNS-Server $dn antwortet nicht auf TCP 53." 'DNS-Server und Netzwerkeinstellungen prüfen, zweiten DNS-Server eintragen.' }
                }
                if ($dns1.Count -eq 1) {
                    $rc1 = 'DNS-Server und Netzwerkeinstellungen prüfen, zweiten DNS-Server eintragen.'
                    if ("$($c1.InterfaceAlias)" -match 'WLAN|Wi-?Fi') { $rc1 = 'Position und Access Point prüfen, 5-GHz-Band bevorzugen, bei Bedarf Roaming-Einstellungen anpassen.' }
                    FLow "Adapter '$($c1.InterfaceAlias)' hat nur einen DNS-Server ($($dns1[0]))." $rc1
                }
            }
            ''
            $okAny = $false
            foreach ($h in 'www.microsoft.com', 'login.microsoftonline.com', 'outlook.office365.com', 'www.google.com') {
                $ipx = ''; try { $ipx = (Resolve-DnsName $h -Type A -DnsOnly -ErrorAction Stop | Where-Object { $_.IPAddress } | Select-Object -First 1).IPAddress } catch {}
                $okt = $false; if ($ipx) { $okt = Tcp $h 443 }
                if ($okt) { $okAny = $true }
                '{0,-28} DNS {1,-16} TCP443 {2}' -f $h, $(if ($ipx) { $ipx } else { 'FEHLER' }), $(if ($okt) { 'OK' } else { 'NICHT ERREICHBAR' })
                if (-not $ipx) { FS "DNS-Auflösung für $h schlägt fehl." 'DNS-Server und Netzwerkeinstellungen prüfen.' }
                elseif (-not $okt) { F "TCP 443 zu $h nicht erreichbar." 'Firewall bzw. Proxy prüfen und Zugriff auf Port 443 freigeben.' }
            }
            if (-not $okAny) { FS 'Keine Internetverbindung: kein Endpunkt erreichbar.' 'Gateway, Router und Internetanschluss prüfen.' }
        } },
    @{ k = 'WLAN'; t = 'WLAN-Qualität'; c = 'NETZWERK'; f = {
            $o = @(netsh wlan show interfaces 2>$null)
            if (-not ($o -match 'SSID|Status|State|Name')) { 'Hinweis: Kein WLAN-Adapter gefunden bzw. WLAN-Dienst nicht aktiv.' } else {
                $stl = NVal $o '^\s*(Status|State)\s*:'
                $disc = ($stl -match 'getrennt|disconnected|nicht verbunden')
                $keys = 'Name|Status|State'
                if (-not $disc) { $keys = 'Name|Status|State|SSID|Netzwerktyp|Network type|Funktyp|Radio type|Authentifizierung|Authentication|Signal|Kanal|Channel|Empfangsrate|Receive rate|Übertragungsrate|Transmit rate' }
                foreach ($l in $o) { if ($l -match "^\s+($keys)\s*:") { $l.TrimEnd() } }
                if ($disc) { 'Hinweis: WLAN-Adapter ist nicht verbunden.' }
                else {
                    $sig = NVal $o '^\s*Signal\s*:'
                    if ($sig -match '(\d+)') { if ([int]$Matches[1] -lt 50) { F "Schwaches WLAN-Signal ($sig)." 'Position und Access Point prüfen, 5-GHz-Band bevorzugen, bei Bedarf Roaming-Einstellungen anpassen.' } }
                }
            }
        } },
    @{ k = 'VPN'; t = 'VPN-Verbindung (Cisco Secure Client / AnyConnect)'; c = 'NETZWERK'; f = {
            $pg = @(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' | Where-Object { $_.DisplayName -match 'Cisco (Secure Client|AnyConnect)' } | Sort-Object DisplayName)
            $sv = @(Get-CimInstance Win32_Service | Where-Object { $_.DisplayName -match 'Cisco (Secure Client|AnyConnect)' -or $_.Name -match '^(vpnagent|csc_)' })
            if ($pg.Count -eq 0 -and $sv.Count -eq 0) { 'Info: Cisco Secure Client/AnyConnect ist nicht installiert (kein Fehler, falls nicht benötigt).' }
            else {
                foreach ($p in $pg) { "Client: $($p.DisplayName) $($p.DisplayVersion)" }
                foreach ($s in $sv) { "Dienst $($s.DisplayName) ($($s.Name)) : $($s.State)" }
                foreach ($s in $sv | Where-Object { $_.Name -eq 'csc_vpnagent' -or $_.Name -eq 'vpnagent' }) { if ($s.State -ne 'Running') { F "Cisco-Dienst $($s.Name) läuft nicht." 'Cisco-Dienst starten bzw. Secure Client reparieren oder neu installieren.' } }
                ''
                foreach ($a in Get-NetAdapter -IncludeHidden | Where-Object { $_.InterfaceDescription -match 'Cisco|AnyConnect' }) { "Adapter $($a.Name) ($($a.InterfaceDescription)) : $($a.Status)" }
                $hosts = @()
                foreach ($x in Get-ChildItem "$env:ProgramData\Cisco" -Recurse -Filter *.xml -ErrorAction SilentlyContinue | Where-Object { $_.FullName -match 'VPN\\Profile' }) {
                    foreach ($mm in [regex]::Matches((Get-Content $x.FullName -Raw), '<HostAddress>\s*([^<\s]+)\s*</HostAddress>')) { $hosts += $mm.Groups[1].Value }
                }
                $hosts = @($hosts | Select-Object -Unique)
                if ($hosts.Count -eq 0) { $gwIn = AskGateway; if ($gwIn) { $hosts = @($gwIn) } }
                ''
                if ($hosts.Count) {
                    'VPN-Gateways (Host | TCP 443):'
                    foreach ($hn in $hosts | Select-Object -First 5) { $ok = Tcp $hn 443; '  {0,-28} {1}' -f $hn, $(if ($ok) { 'OK' } else { 'NICHT ERREICHBAR' }); if (-not $ok) { F "VPN-Gateway $hn nicht erreichbar (TCP 443)." 'Gateway-Adresse, Firewall und Internetverbindung prüfen.' } }
                } else { 'VPN-Gateways: keine angegeben' }
                $ip = 'nicht ermittelbar'; try { $ip = (Invoke-RestMethod 'https://api.ipify.org' -TimeoutSec 5 -ErrorAction Stop) } catch {}
                ''
                "Öffentliche IP: $ip"
                $ve = @(Ev 'Application' 3 @(2, 3) $null | Where-Object { $_.ProviderName -match 'vpn|anyconnect|cisco|csc_' -or $_.Message -match 'vpnagent|AnyConnect' })
                ''
                'VPN-Ereignisse (Anwendungsprotokoll, 3 Tage, Warnungen/Fehler):'
                if ($ve.Count) { foreach ($e3 in $ve | Select-Object -First 5) { '  {0} | ID {1} | {2} | {3}' -f $e3.TimeCreated.ToString('dd.MM. HH:mm'), $e3.Id, $e3.ProviderName, (Cut (FirstLine $e3.Message) 100) }; F "$($ve.Count) VPN-Ereignisse (Warnungen/Fehler) in 3 Tagen." 'VPN-Ereignisse im Anwendungsprotokoll prüfen und den Client aktualisieren.' } else { 'Keine gefunden.' }
            }
        } },
    @{ k = 'Proxy'; t = 'Proxy-Einstellungen'; c = 'NETZWERK'; f = {
            $is = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'
            "Benutzer-Proxy aktiv : $($is.ProxyEnable)".TrimEnd()
            "Benutzer-Proxy Server: $($is.ProxyServer)".TrimEnd()
            "Auto-Config-URL (PAC): $($is.AutoConfigURL)".TrimEnd()
            ''
            $w = @(netsh winhttp show proxy 2>$null)
            if ($w.Count) { $ix = @(0..($w.Count - 1) | Where-Object { "$($w[$_])".Trim() }); if ($ix.Count) { $w[$ix[0]..$ix[-1]] } }
            "Umgebung: HTTP_PROXY='$([Environment]::GetEnvironmentVariable('HTTP_PROXY'))' HTTPS_PROXY='$([Environment]::GetEnvironmentVariable('HTTPS_PROXY'))'"
            if ($is.ProxyEnable -eq 1 -and $is.ProxyServer -match '^(127\.0\.0\.1|localhost)') { F "Proxy zeigt auf den lokalen Rechner ($($is.ProxyServer)) - ein Programm setzt ihn." 'Programm identifizieren, das den lokalen Proxy setzt (ProxyCheck-Diagnose nutzen), und Einstellung bereinigen.' }
            foreach ($v in 'HTTP_PROXY', 'HTTPS_PROXY') { if ([Environment]::GetEnvironmentVariable($v)) { F "Umgebungsvariable $v ist gesetzt: $([Environment]::GetEnvironmentVariable($v))" 'Umgebungsvariable prüfen und entfernen, falls nicht benötigt.' } }
        } },
    @{ k = 'Zeit'; t = 'Uhrzeit-Synchronisierung'; c = 'NETZWERK'; f = {
            $w = @(w32tm /query /status 2>$null | Where-Object { $_ -match '\S' })
            if ($w.Count -lt 3) { 'Hinweis: Der Windows-Zeitdienst liefert keinen Status (Dienst gestoppt?).'; F 'Windows-Zeitdienst liefert keinen Status.' 'Zeitdienst starten (net start w32time) und Startart auf Automatisch setzen.' }
            else {
                $w
                $src = ($w | Where-Object { $_ -match '^(Quelle|Source)\s*:' } | Select-Object -First 1)
                if ("$src" -match 'Local CMOS|Free-running|lokale') { F 'Zeitquelle ist die lokale Hardware-Uhr (keine Synchronisierung).' 'Zeitquelle konfigurieren (Domäne oder NTP-Server, w32tm /config).' }
            }
            $off = MsOffset
            if ($null -ne $off) {
                if ($off -gt 300) { FS "Uhr weicht um $off s von Microsoft ab (Anmeldung an Microsoft 365 schlägt vermutlich fehl)." 'Uhrzeit und Zeitzone korrigieren und Zeitsynchronisierung prüfen (w32tm /resync).' }
                elseif ($off -gt 120) { F "Uhr weicht um $off s von Microsoft ab (Anmeldeprobleme möglich)." 'Uhrzeit und Zeitzone korrigieren und Zeitsynchronisierung prüfen (w32tm /resync).' }
            }
        } },
    @{ k = 'Web'; t = 'Webseiten-Test'; c = 'NETZWERK'; n = $true; f = {
            # Prüft je Adresse: DNS, Ping, TCP 443, Zertifikat und HTTPS (direkt und über den System-Proxy)
            $wbIn = @(AskSites)
            $wbHosts = @($wbIn | Where-Object { $_ })
            if ($wbHosts.Count -eq 0) { $wbHosts = @('www.google.de', 'www.microsoft.com', 'www.sippicom.com', 'login.microsoftonline.com'); 'Hinweis: Keine Adresse angegeben, es wird eine Standardliste geprüft.' }
            $wbHosts = @($wbHosts | Select-Object -First 6)
            $wbIs = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction SilentlyContinue
            $wbPx = 'keiner'; if ($wbIs.ProxyEnable -eq 1 -and $wbIs.ProxyServer) { $wbPx = "$($wbIs.ProxyServer)" }
            $wbPac = 'keine'; if ($wbIs.AutoConfigURL) { $wbPac = "$($wbIs.AutoConfigURL)" }
            KV 'System-Proxy' $wbPx
            KV 'Auto-Config (PAC)' $wbPac
            ''
            $wbGet = {
                param($wbU, $wbMode)
                try {
                    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                    $wbRq = [Net.HttpWebRequest]::Create($wbU); $wbRq.Method = 'GET'; $wbRq.Timeout = 10000; $wbRq.AllowAutoRedirect = $false; $wbRq.UserAgent = 'Sippicom-Diagnosezentrum'
                    if ($wbMode -eq 'direkt') { $wbRq.Proxy = $null }
                    $wbRs = $wbRq.GetResponse(); $wbCode = [int]$wbRs.StatusCode; $wbRs.Close()
                    return "HTTP $wbCode"
                } catch [Net.WebException] {
                    if ($_.Exception.Response) { return "HTTP $([int]$_.Exception.Response.StatusCode)" }
                    return "FEHLER ($($_.Exception.Message))"
                } catch { return "FEHLER ($($_.Exception.Message))" }
            }
            $wbBad = 0
            foreach ($wbH in $wbHosts) {
                "Ziel: $wbH"
                $wbIp = @(); try { $wbIp = @([Net.Dns]::GetHostAddresses($wbH) | ForEach-Object { $_.IPAddressToString }) } catch {}
                if ($wbIp.Count -gt 0) { KV '  DNS' ('OK (' + (($wbIp | Select-Object -First 2) -join ', ') + ')') }
                else {
                    KV '  DNS' 'FEHLER (Name nicht auflösbar)'
                    F "DNS-Auflösung für $wbH fehlgeschlagen." "DNS-Server des Adapters bzw. der Firewall prüfen (nslookup $wbH) und ggf. einen anderen DNS-Server testen."
                    $wbBad++; ''; continue
                }
                $wbPing = $false; try { $wbPing = [bool](Test-Connection -ComputerName $wbH -Count 1 -Quiet -ErrorAction Stop) } catch {}
                if ($wbPing) { KV '  Ping' 'OK' } else { KV '  Ping' 'nicht beantwortet (oft gesperrt, unkritisch)' }
                $wbTcp = Tcp $wbH 443
                if ($wbTcp) { KV '  TCP 443' 'OK' } else { KV '  TCP 443' 'NICHT ERREICHBAR' }
                if (-not $wbTcp) {
                    FS "TCP 443 zu $wbH ist blockiert oder nicht erreichbar." 'Firewall, Webfilter oder Proxy prüfen und ausgehendes HTTPS (TCP 443) freigeben.'
                    $wbBad++; ''; continue
                }
                $wbIss = CertIssuer $wbH
                if ($wbIss) {
                    $wbIss = (($wbIss -split ',')[0]) -replace '^CN=', ''
                    KV '  Zertifikat' $wbIss
                    if ($wbIss -match 'Fortinet|FortiGate|Sophos|Zscaler|Palo Alto|Cisco|Umbrella|Check Point|Forcepoint|SonicWall|Netskope|Barracuda|WatchGuard|Kaspersky|ESET|Avast|AVG|Bitdefender|Untangle|Trend Micro|McAfee') {
                        F "Zertifikat von $wbH stammt von '$wbIss' (TLS-Inspection oder Sicherheitssoftware)." 'Prüfen, ob Webfilter oder Antivirus die HTTPS-Verbindung aufbricht; Stammzertifikat der Inspektion im System hinterlegen oder die Seite ausnehmen.'
                    }
                } else {
                    KV '  Zertifikat' 'FEHLER (TLS-Verbindung kam nicht zustande)'
                    F "TLS-Verbindung zu $wbH kam nicht zustande." 'Uhrzeit, TLS-Einstellungen und Sicherheitssoftware (Web-Schutz) prüfen.'
                    $wbBad++
                }
                $wbD = & $wbGet "https://$wbH" 'direkt'
                $wbP = & $wbGet "https://$wbH" 'system'
                KV '  HTTPS direkt' $wbD
                KV '  HTTPS System' $wbP
                $wbDok = ($wbD -match '^HTTP [123]'); $wbPok = ($wbP -match '^HTTP [123]')
                if ($wbDok -and -not $wbPok) {
                    FS "Seite $wbH geht direkt, aber nicht über den System-Proxy ($wbP)." 'Proxy-Einstellungen bzw. PAC-Datei prüfen und falschen oder veralteten Proxy entfernen (siehe Abschnitt Proxy).'
                    $wbBad++
                } elseif ($wbPok -and -not $wbDok) {
                    'Hinweis: Nur über den Proxy erreichbar - direkter Internetzugang ist gesperrt (bei Firmenproxy normal).'
                } elseif (-not $wbDok -and -not $wbPok) {
                    F "HTTPS-Anfrage an $wbH scheitert ($wbD)." 'Zertifikat, Uhrzeit, Web-Schutz der Sicherheitssoftware und Firewall prüfen.'
                    $wbBad++
                }
                if ($wbD -match '^HTTP 407' -or $wbP -match '^HTTP 407') { F 'Der Proxy verlangt eine Anmeldung (HTTP 407).' 'Anmeldedaten für den Proxy hinterlegen oder die Proxy-Einstellung prüfen.' }
                ''
            }
            if ($wbBad -eq 0) {
                'Ergebnis: Alle geprüften Seiten sind per DNS, TCP 443 und HTTPS erreichbar.'
                'Hinweis: Geht eine Seite im Browser trotzdem nicht, Browser-Proxy, Erweiterungen, Richtlinien (Edge/Chrome) und das Browserprofil prüfen und einen anderen Browser testen.'
            }
        } },
    @{ k = 'M365'; t = 'Microsoft 365 und Anmeldung'; c = 'ARBEITSPLATZ'; f = {
            $ds = @(dsregcmd /status 2>$null)
            foreach ($l in $ds) { if ($l -match '^\s*(AzureAdJoined|DomainJoined|WorkplaceJoined|TenantName|AzureAdPrt|TpmProtected)\s*:\s*(.*)$') { $mk = $Matches[1]; $mv = $Matches[2].Trim(); KV $mk $mv } }
            if (($ds -match 'AzureAdJoined\s*:\s*YES') -and ($ds -match 'AzureAdPrt\s*:\s*NO')) { F 'Entra-ID-Gerät ohne PRT: Anmeldung an Microsoft-365-Apps kann scheitern.' 'Gerät neu anmelden und dsregcmd /status prüfen; ggf. Entra-/Hybrid-Join reparieren.' }
            $tp = Get-Tpm
            ''
            "TPM: $(if($tp.TpmPresent){'vorhanden'}else{'fehlt'}) , $(if($tp.TpmReady){'bereit'}else{'nicht bereit'})"
            $off = MsOffset
            if ($null -ne $off) { "Uhrzeitabweichung zu Microsoft: $off Sekunden"; if ($off -gt 300) { FS "Uhr weicht um $off s ab (Anmeldung an Microsoft 365 schlägt vermutlich fehl)." 'Uhrzeit und Zeitzone korrigieren (w32tm /resync).' } elseif ($off -gt 120) { F "Uhr weicht um $off s ab (Anmeldeprobleme möglich)." 'Uhrzeit und Zeitzone korrigieren (w32tm /resync).' } }
            ''
            'Anmelde-Endpunkte (Host | TCP 443 | Zertifikatsaussteller):'
            foreach ($h in 'login.microsoftonline.com', 'graph.microsoft.com', 'outlook.office365.com', 'teams.microsoft.com', 'login.live.com') {
                $ok = Tcp $h 443; $iss = ''
                if ($ok -and $h -eq 'login.microsoftonline.com') { $iss = CertIssuer $h; if ($iss) { $iss = ($iss -split ',')[0] -replace '^CN=', ''; if ($iss -notmatch 'Microsoft|DigiCert') { F "Ungewöhnlicher Zertifikatsaussteller ($iss): mögliche TLS-Inspection." 'Zertifikats-Inspektion der Firewall für Microsoft-365-Endpunkte ausnehmen.' } } }
                '  {0,-28} {1}  {2}' -f $h, $(if ($ok) { 'OK' } else { 'NICHT ERREICHBAR' }), $iss
                if (-not $ok) { F "TCP 443 zu $h nicht erreichbar." 'Firewall bzw. Proxy prüfen und Zugriff auf den Endpunkt (TCP 443) freigeben.' }
            }
            $ae = @(Ev 'Microsoft-Windows-AAD/Operational' 3 2 $null)
            ''
            "Fehler im Protokoll Microsoft-Windows-AAD/Operational (3 Tage):"
            EvTop $ae 4
            if ($ae.Count) { F "$($ae.Count) AAD-Fehlereignisse in 3 Tagen." 'Fehlerereignisse der Anmeldung prüfen (Token-Broker); Konto in den Office-Apps ab- und neu anmelden.' }
        } },
    @{ k = 'Office'; t = 'Outlook und Teams'; c = 'ARBEITSPLATZ'; f = {
            $c2r = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration'
            if ($c2r) { "Microsoft 365 Apps : Version $($c2r.VersionToReport) | Kanal $(($c2r.CDNBaseUrl -split '/')[-1]) | Plattform $($c2r.Platform)" } else { 'Microsoft 365 Apps : nicht gefunden (kein Click-to-Run)' }
            $op = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\OUTLOOK.EXE').'(default)'
            "Outlook (classic): $(if($op){$op}else{'nicht gefunden'})"
            $no = Get-AppxPackage Microsoft.OutlookForWindows; $tm2 = Get-AppxPackage MSTeams
            "App Microsoft.OutlookForWindows : $(if($no){'Version ' + $no.Version}else{'nicht installiert'})"
            "App MSTeams : $(if($tm2){'Version ' + $tm2.Version}else{'nicht installiert'})"
            foreach ($pn2 in 'ms-teams', 'olk', 'OUTLOOK') {
                foreach ($pr in @(Get-Process -Name $pn2)) {
                    "Prozess $pn2 : $(if($pr.Responding){'reagiert'}else{'REAGIERT NICHT'})"
                    if (-not $pr.Responding) { FS "Prozess $pn2 reagiert nicht." 'Anwendung beenden und neu starten; bei Wiederholung Add-ins deaktivieren bzw. Office reparieren.' }
                }
            }
            $wv = (Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}').pv
            ''
            "WebView2-Runtime: $(if($wv){$wv}else{'FEHLT'})"
            if (-not $wv) { F 'WebView2-Runtime fehlt (neues Outlook/Teams benötigen sie).' 'WebView2-Runtime von Microsoft installieren.' }
            if ((Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Edge').AlwaysOpenPdfExternally -eq 1) { F 'Edge-Richtlinie AlwaysOpenPdfExternally=1: PDF-Vorschau in Outlook (new) geht nicht.' 'Richtlinie prüfen und ggf. entfernen.' }
            $ad = @(Get-ChildItem 'HKCU:\Software\Microsoft\Office\Outlook\Addins' | ForEach-Object { "  $($_.PSChildName) | $((Get-ItemProperty $_.PSPath).LoadBehavior)" })
            ''
            'Outlook-Add-ins (Name | LoadBehavior):'
            if ($ad.Count) { $ad } else { '  keine gefunden' }
            $pf = @(Get-ChildItem 'HKCU:\Software\Microsoft\Office\16.0\Outlook\Profiles' | ForEach-Object { $_.PSChildName })
            "Outlook-Profile: $(if($pf.Count){$pf -join ', '}else{'keine'})"
            ''
            'Datendateien (OST/PST):'
            $df = @(Get-ChildItem "$env:LOCALAPPDATA\Microsoft\Outlook" -Include *.ost, *.pst -Recurse -ErrorAction SilentlyContinue) + @(Get-ChildItem "$env:USERPROFILE\Documents" -Filter *.pst -Recurse -ErrorAction SilentlyContinue | Select-Object -First 10)
            if ($df.Count) { foreach ($dfi in $df) { "  $($dfi.Name) : $([math]::Round($dfi.Length/1GB,1)) GB"; if ($dfi.Length -gt 50GB) { F "Datendatei $($dfi.Name) ist sehr groß." 'Postfach bereinigen bzw. archivieren; OST-Datei ggf. neu aufbauen.' } } } else { '  keine gefunden' }
            $cr = @(Ev 'Application' 7 2 1000 | Where-Object { $_.Message -match 'OUTLOOK\.EXE|olk\.exe|ms-teams|Teams\.exe' })
            ''
            if ($cr.Count) { "Abstürze von Outlook/Teams (7 Tage): $($cr.Count) gefunden."; EvTop $cr 3; F "$($cr.Count) Abstürze von Outlook/Teams in 7 Tagen." 'Add-ins deaktivieren, Office reparieren und Updates installieren.' } else { 'Abstürze von Outlook/Teams (7 Tage): keine gefunden.' }
        } },
    @{ k = 'Drucker'; t = 'Drucker und Spooler'; c = 'ARBEITSPLATZ'; f = {
            $spl = Get-Service Spooler
            KV 'Druckspooler' "$($spl.Status)"
            $fnd = @()
            if ($spl.Status -ne 'Running') { $fnd += (FS 'Druckspooler läuft nicht.' 'Druckspooler-Dienst starten; bei Wiederholung Warteschlange leeren und Treiber prüfen (PaperJamZero aus den Siptools kann den Spooler reparieren).') }
            $def = (Get-CimInstance Win32_Printer | Where-Object { $_.Default }).Name
            ''
            'Drucker (Name | Standard | Port | Status):'
            $tot = 0
            foreach ($p in Get-Printer) {
                $jobs = @(Get-PrintJob -PrinterName $p.Name); $tot += $jobs.Count
                $stt = "$($p.PrinterStatus)"; if ($stt -in 'Normal', 'Idle', '0') { $stt = 'bereit' }
                '  {0} | {1} | {2} | {3}' -f $p.Name, $(if ($p.Name -eq $def) { 'Standard' } else { '-' }), $p.PortName, $stt
                if ($stt -ne 'bereit') { $fnd += (F "Drucker $($p.Name): Status $stt." 'Drucker prüfen (Netzteil, Papier, Verbindung) und Status am Gerät klären.') }
                foreach ($j in $jobs | Where-Object { $_.JobStatus -match 'Error|Blocked|Offline' }) { $fnd += (F "Hängender Auftrag $($j.Id) bei $($p.Name) ($($j.JobStatus))." 'Druckauftrag löschen und Warteschlange neu starten.') }
            }
            ''
            "Druckaufträge in der Warteschlange: $tot"
            foreach ($pt in Get-PrinterPort | Where-Object { $_.PrinterHostAddress } | Select-Object -First 8) { if (-not (Test-Connection $pt.PrinterHostAddress -Count 1 -Quiet)) { $fnd += (F "Druckerport $($pt.PrinterHostAddress) antwortet nicht." 'Netzwerkverbindung und IP-Adresse des Druckers prüfen.') } }
            $pe = @(Ev 'Microsoft-Windows-PrintService/Admin' 7 2 $null); if ($pe.Count) { $fnd += (F "$($pe.Count) Druckdienst-Fehler (7 Tage)." 'Druckdienst-Ereignisse prüfen und Druckertreiber aktualisieren.') }
            $fnd
        } },
    @{ k = 'Ablauf'; t = 'Zertifikate, Kennwortablauf und BitLocker'; c = 'ARBEITSPLATZ'; f = {
            $ceNow = Get-Date
            foreach ($ceSt in @(@('CurrentUser', 'Benutzer'), @('LocalMachine', 'Computer'))) {
                $ceList = @(Get-ChildItem "Cert:\$($ceSt[0])\My" -ErrorAction SilentlyContinue | Where-Object { $_.NotAfter })
                KV "Zertifikate $($ceSt[1])" "$($ceList.Count) im persönlichen Speicher"
                foreach ($ceC in $ceList | Sort-Object NotAfter) {
                    $ceDays = [int][math]::Floor(($ceC.NotAfter - $ceNow).TotalDays)
                    $ceName = Cut ($ceC.Subject -replace '^CN=', '') 60
                    $ceDate = $ceC.NotAfter.ToString('dd.MM.yyyy')
                    if ($ceDays -lt 0) { "  $ceName | abgelaufen seit $ceDate"; F "Zertifikat '$ceName' ($($ceSt[1])) ist seit dem $ceDate abgelaufen." 'Zertifikat erneuern bzw. nicht mehr benötigtes Zertifikat entfernen.' }
                    elseif ($ceDays -le 30) { "  $ceName | gültig bis $ceDate ($ceDays Tage)"; F "Zertifikat '$ceName' ($($ceSt[1])) läuft in $ceDays Tagen ab ($ceDate)." 'Zertifikat rechtzeitig erneuern (Zertifizierungsstelle bzw. automatische Registrierung prüfen).' }
                    else { "  $ceName | gültig bis $ceDate ($ceDays Tage)" }
                }
            }
            ''
            # Kennwortablauf des angemeldeten Kontos (Domäne per Active Directory, sonst lokales Konto)
            $pwDays = $null; $pwNever = $false; $pwTxt = 'nicht ermittelbar'
            try {
                if ((Get-CimInstance Win32_ComputerSystem).PartOfDomain) {
                    $pwS = [adsisearcher]"(&(objectCategory=person)(objectClass=user)(sAMAccountName=$env:USERNAME))"
                    [void]$pwS.PropertiesToLoad.Add('msds-userpasswordexpirytimecomputed')
                    $pwR = $pwS.FindOne()
                    if ($pwR) {
                        $pwV = [int64]$pwR.Properties['msds-userpasswordexpirytimecomputed'][0]
                        if ($pwV -eq 9223372036854775807 -or $pwV -eq 0) { $pwNever = $true }
                        else { $pwEnd = [DateTime]::FromFileTime($pwV); $pwDays = [int][math]::Floor(($pwEnd - $ceNow).TotalDays); $pwTxt = "läuft am $($pwEnd.ToString('dd.MM.yyyy')) ab ($pwDays Tage)" }
                    }
                } else {
                    $pwL = Get-LocalUser -Name $env:USERNAME -ErrorAction Stop
                    if ($pwL.PasswordExpires) { $pwDays = [int][math]::Floor(($pwL.PasswordExpires - $ceNow).TotalDays); $pwTxt = "läuft am $($pwL.PasswordExpires.ToString('dd.MM.yyyy')) ab ($pwDays Tage)" } else { $pwNever = $true }
                }
            } catch {}
            if ($pwNever) { $pwTxt = 'läuft nicht ab' }
            KV 'Kennwort' "$env:USERNAME : $pwTxt"
            if ($null -ne $pwDays) {
                if ($pwDays -lt 0) { FS 'Das Kennwort des angemeldeten Kontos ist abgelaufen.' 'Kennwort sofort ändern (Strg+Alt+Entf, Kennwort ändern) bzw. durch den Administrator zurücksetzen lassen.' }
                elseif ($pwDays -le 14) { F "Das Kennwort des angemeldeten Kontos läuft in $pwDays Tagen ab." 'Kennwort rechtzeitig ändern, damit Anmeldung, Outlook und VPN nicht ausfallen.' }
            }
            ''
            if ($isAdmin) {
                $blVols = @(Get-BitLockerVolume -ErrorAction SilentlyContinue)
                if ($blVols.Count) {
                    'BitLocker (Laufwerk | Zustand | Schutz | Verschlüsselt):'
                    foreach ($blV in $blVols) { '  {0} | {1} | {2} | {3} %' -f $blV.MountPoint, $blV.VolumeStatus, $blV.ProtectionStatus, $blV.EncryptionPercentage }
                } else { 'Hinweis: BitLocker-Status nicht abrufbar (Funktion nicht verfügbar).' }
            } else { 'Hinweis: Der BitLocker-Status ist nur mit Administratorrechten abrufbar (Bewertung im Bereich Backup und Verschlüsselung).' }
        } },
    @{ k = 'NetTools'; t = 'Netzwerk-Werkzeuge (Gateway-Test, Trace, Speedtest)'; c = 'NETZWERK'; f = {
            $ntGw = $null
            try { $ntGw = (Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction Stop | Where-Object { $_.NextHop -ne '0.0.0.0' } | Sort-Object { $_.RouteMetric + $_.InterfaceMetric } | Select-Object -First 1).NextHop } catch {}
            if (-not $ntGw) { FS 'Kein Standardgateway gefunden.' 'Netzwerkkabel bzw. WLAN und IP-Konfiguration prüfen.'; return }
            KV 'Gateway' $ntGw
            # Gateway-Test: 8 Pings, Antwortzeit und Verlust
            $ntP = @()
            for ($ntI = 0; $ntI -lt 8; $ntI++) {
                $ntR = Test-Connection $ntGw -Count 1 -ErrorAction SilentlyContinue
                if ($ntR) { $ntP += $ntR }
                [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 120
            }
            if ($ntP.Count) {
                $ntAvg = [math]::Round(($ntP | Measure-Object ResponseTime -Average).Average, 1); $ntMax = ($ntP | Measure-Object ResponseTime -Maximum).Maximum
                KV 'Ping Gateway' "8 gesendet, $($ntP.Count) beantwortet, Ø $ntAvg ms, max. $ntMax ms"
                if ($ntP.Count -lt 8) { F "Paketverlust zum Gateway ($(8 - $ntP.Count) von 8 Pings ohne Antwort)." 'Kabel, WLAN-Signal, Switch-Port und Gateway prüfen; Verbindung auf Störungen untersuchen.' }
                if ($ntAvg -gt 50) { F "Hohe Antwortzeit zum Gateway (Ø $ntAvg ms)." 'WLAN-Signal und Auslastung des Netzes prüfen; möglichst per Kabel testen.' }
            } else { KV 'Ping Gateway' 'KEINE ANTWORT'; FS "Gateway $ntGw antwortet nicht auf Ping." 'Netzwerkkabel bzw. WLAN, Switch und Router prüfen.' }
            ''
            # Trace in das Internet (maximal 8 Sprünge)
            Msg 'Trace läuft ...' $null
            $ntTr = @(RunTool 'Trace' "$env:windir\System32\tracert.exe" '-d -h 8 -w 800 1.1.1.1' $script:oemEnc)
            'Trace zu 1.1.1.1 (höchstens 8 Sprünge):'
            foreach ($ntL in $ntTr | Where-Object { $_ -match '^\s*\d+\s' }) { "  $($ntL.Trim())" }
            if (-not ($ntTr -match '1\.1\.1\.1\s*$' | Where-Object { $_ -match '^\s*\d+\s' })) { 'Hinweis: Das Ziel wurde innerhalb von 8 Sprüngen nicht erreicht (ICMP kann gefiltert sein; kein Fehler für sich).' }
            ''
            # Speedtest: Download von 25 MB (Cloudflare), zeigt die nutzbare Bandbreite
            Msg 'Speedtest läuft (Download, ca. 25 MB) ...' $null
            try {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                $ntRq = [Net.HttpWebRequest]::Create('https://speed.cloudflare.com/__down?bytes=25000000'); $ntRq.Timeout = 8000; $ntRq.ReadWriteTimeout = 8000
                $ntRq.Proxy = [Net.WebRequest]::GetSystemWebProxy(); $ntRq.Proxy.Credentials = [Net.CredentialCache]::DefaultCredentials
                $ntSw = [Diagnostics.Stopwatch]::StartNew(); $ntRs = $ntRq.GetResponse(); $ntStm = $ntRs.GetResponseStream()
                $ntBuf = New-Object byte[] 65536; $ntTot = 0L; $ntK = 0
                while ($true) {
                    $ntN = $ntStm.Read($ntBuf, 0, $ntBuf.Length); if ($ntN -le 0) { break }
                    $ntTot += $ntN; $ntK++
                    if ($ntK % 8 -eq 0) { [Windows.Forms.Application]::DoEvents() }
                    if ($ntSw.Elapsed.TotalSeconds -gt 15) { break }
                }
                $ntSw.Stop(); $ntStm.Close(); $ntRs.Close()
                $ntSec = [math]::Max(0.1, $ntSw.Elapsed.TotalSeconds)
                $ntMbit = [math]::Round(($ntTot * 8 / 1000000) / $ntSec, 1)
                KV 'Download' "$ntMbit Mbit/s ($([math]::Round($ntTot / 1MB, 1)) MB in $([math]::Round($ntSec, 1)) s)"
                if ($ntMbit -lt 5) { F "Sehr langsame Internetverbindung ($ntMbit Mbit/s Download)." 'Anschluss, WLAN-Signal, VPN und Auslastung durch andere Geräte prüfen; Provider kontaktieren.' }
                elseif ($ntMbit -lt 20) { FLow "Geringe Bandbreite ($ntMbit Mbit/s Download)." 'Bei langsamen Anwendungen WLAN, VPN und gleichzeitige Downloads prüfen.' }
            } catch {
                KV 'Download' "FEHLER ($(Cut $_.Exception.Message 80))"
                F 'Speedtest war nicht möglich (Internet oder Proxy blockiert speed.cloudflare.com).' 'Internetverbindung, Proxy und Firewall prüfen; der Test ist nur eine Orientierung.'
            }
            ''
            # Cisco-VPN: Kurzprüfung (Details in der Kachel VPN (Cisco))
            $ntVpn = @(Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.InterfaceDescription -match 'Cisco|AnyConnect' })
            if ($ntVpn.Count) { foreach ($ntA in $ntVpn) { KV 'Cisco-VPN-Adapter' "$($ntA.InterfaceDescription) : $($ntA.Status)" } }
            else { KV 'Cisco-VPN-Adapter' 'nicht vorhanden' }
            ''
            'Hinweis: Subnetz-Scan, DNS-Fingerprinting und SSL/TLS-Prüfung bietet PingMeMaybe aus den Siptools: https://ncscript.xyz/Siptools'
        } },
    @{ k = 'PacketCapture'; t = 'Paketmitschnitt (pktmon, ganze Pakete, 1 Minute)'; c = 'WERKZEUGE'; n = $true; f = {
            # Aufnahme mit den Bordmitteln von Windows (pktmon, ersatzweise netsh trace); die Auswertung liest die pcapng-Datei selbst.
            # Es werden weder Wireshark/TShark noch Npcap benötigt.
            if (-not $isAdmin) { NeedAdmin 'Mitschnitt'; return }
            if (-not (NcInit)) { FS 'Die eingebaute Mitschnitt-Auswertung konnte nicht gestartet werden (C#-Compiler von Windows nicht verfügbar).' 'Windows-PowerShell 5.1 mit .NET Framework 4 prüfen; der Mitschnitt selbst ist auch ohne Auswertung möglich.' }
            if (-not (SipBox "Es wird 1 Minute lang der Netzwerkverkehr dieses PCs mitgeschnitten (ganze Pakete, auch Inhalte; Ringpuffer 1 GB).`r`n`r`nDie Aufzeichnung kann vertrauliche Angaben enthalten (Adressen, Namen, unverschlüsselte Inhalte). Sie wird nur lokal gespeichert (C:\SippicomInstall\mitschnitt, Zugriff beschränkt) und sollte nach der Analyse sicher gelöscht werden.`r`n`r`nJetzt starten?" 'Paketmitschnitt bestätigen' $true)) { 'Hinweis: Mitschnitt abgebrochen.'; return }
            NcCapture 60
            $pcFile = $script:ncFile
            if (-not $pcFile) { return }
            KV 'Datei' $pcFile
            KV 'Ergebnis' "OK - Mitschnitt gespeichert ($(NcSize (Get-Item -LiteralPath $pcFile).Length))"
            if ($pcFile -notlike '*.pcapng') { 'Hinweis: Das Ergebnis ist eine .etl-Datei (netsh trace); eine automatische Auswertung ist dafür nicht möglich.'; try { Start-Process explorer.exe "/select,`"$pcFile`"" } catch {}; return }
            ''
            $pcSt = NcStat $pcFile
            if (-not $pcSt -or ($pcSt.Error -and $pcSt.Packets -eq 0)) {
                $pcErr = ''; if ($pcSt) { $pcErr = $pcSt.Error }
                F "Der Mitschnitt konnte nicht ausgewertet werden ($pcErr)." 'Datei in Wireshark öffnen oder den Mitschnitt wiederholen.'
                try { Start-Process explorer.exe "/select,`"$pcFile`"" } catch {}
                return
            }
            KV 'Pakete' ('{0:N0} ({1})' -f $pcSt.Packets, (NcSize $pcSt.Bytes))
            if ($pcSt.Packets -eq 0) { FS 'Im Mitschnitt befinden sich keine Pakete.' 'Schnittstelle prüfen (WLAN oder LAN, VPN-Adapter) und den Mitschnitt wiederholen.'; return }
            $pcPct = 0.0; if ($pcSt.TcpPackets -gt 0) { $pcPct = [math]::Round(100.0 * $pcSt.Retrans / $pcSt.TcpPackets, 1) }
            KV 'Neuübertragungen' "$($pcSt.Retrans) ($pcPct % der TCP-Pakete)"
            KV 'TCP-Resets' "$($pcSt.Rst)"
            KV 'DNS-Fehler' "$($pcSt.DnsErrors) von $($pcSt.DnsResponses) Antworten"
            KV 'ICMP unreachable' "$($pcSt.IcmpUnreach)"
            if ($pcSt.Retrans -gt 20 -and $pcPct -gt 2) { F "Viele TCP-Neuübertragungen im Mitschnitt ($($pcSt.Retrans), $pcPct % der TCP-Pakete)." 'Paketverlust oder Überlastung suchen: WLAN-Signal, Kabel, Switch-Port, VPN und Gegenstelle prüfen.' }
            if ($pcSt.Rst -gt 30) { FLow "Viele TCP-Resets im Mitschnitt ($($pcSt.Rst))." 'Firewall, Proxy, Zielserver und Anwendungen prüfen, die Verbindungen abbrechen.' }
            if ($pcSt.DnsErrors -gt 5) { F "DNS-Antworten mit Fehlercode im Mitschnitt ($($pcSt.DnsErrors))." 'DNS-Server und Namen prüfen (nicht auflösbare Hosts, falsche Suchdomäne).' }
            if ($pcSt.IcmpUnreach -gt 5) { FLow "ICMP 'Ziel nicht erreichbar' im Mitschnitt ($($pcSt.IcmpUnreach))." 'Routing, Firewall und Zieladressen prüfen.' }
            ''
            'Protokolle (Pakete | Datenmenge):'
            foreach ($pcE in @($pcSt.Protos.GetEnumerator() | Sort-Object { $_.Value[1] } -Descending | Select-Object -First 8)) { '  {0,-44} {1,9:N0} | {2}' -f $pcE.Key, $pcE.Value[0], (NcSize $pcE.Value[1]) }
            ''
            'Größte Verbindungen (Datenmenge | Pakete | Neuübertragungen):'
            foreach ($pcF in @($pcSt.Flows.Values | Sort-Object Bytes -Descending | Select-Object -First 8)) { '  {0} | {1} | {2:N0} | {3:N0}' -f $pcF.Key, (NcSize $pcF.Bytes), $pcF.Packets, $pcF.Retrans }
            ''
            # Ausführliche Analyse als Textdatei; kommt mit dem Mitschnitt ins ZIP-Paket und in die Support-ZIP
            Msg 'Erstelle ausführliche Analyse ...' $null
            $pcAna = ($pcFile -replace '\.pcapng$', '') + '_Analyse.txt'
            $script:ncAna = $null
            try { [void](NcAnalyseText $pcSt $pcFile $pcAna); if ($script:ncAna) { KV 'Analyse' $pcAna } } catch { 'Hinweis: Die ausführliche Analyse konnte nicht erstellt werden.' }
            Msg 'Packe Mitschnitt in ein ZIP-Archiv ...' $null; [Windows.Forms.Application]::DoEvents()
            try {
                $pcZip = ($pcFile -replace '\.pcapng$', '') + '.zip'
                $pcPack = @($pcFile); if ($script:ncAna) { $pcPack += $script:ncAna }
                Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
                if (Test-Path -LiteralPath $pcZip) { Remove-Item -LiteralPath $pcZip -Force }
                $pcZ = [IO.Compression.ZipFile]::Open($pcZip, [IO.Compression.ZipArchiveMode]::Create)
                try { foreach ($pcX in $pcPack) { [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($pcZ, $pcX, (Split-Path $pcX -Leaf), [IO.Compression.CompressionLevel]::Fastest); [Windows.Forms.Application]::DoEvents() } } finally { $pcZ.Dispose() }
                KV 'Archiv' $pcZip
            } catch { 'Hinweis: Das ZIP-Archiv konnte nicht erstellt werden.' }
            ''
            'Hinweis: Mitschnitt und Analyse liegen im Ordner und in der ZIP; die Analyse geht auch in die Support-ZIP ein. Die Dateien können vertrauliche Daten enthalten - nach Gebrauch sicher löschen.'
            'Hinweis: Neuübertragungen werden aus den TCP-Folgenummern geschätzt (kein vollständiges Wireshark-Expert); verschlüsselte Inhalte werden nicht gelesen.'
            try { Start-Process explorer.exe "/select,`"$pcFile`"" } catch {}
        } },
    # ---------- Reiter REPARATUR ----------
    @{ k = 'SFC'; t = 'Reparatur: Systemdateien prüfen (SFC)'; c = 'WINDOWS'; r = $true; f = {
            KV 'Befehl' 'sfc /scannow (prüft alle geschützten Systemdateien und repariert sie)'
            if (-not $isAdmin) { NeedAdmin 'SFC'; return }
            RpCreate 'SFC'
            $sfSw = [Diagnostics.Stopwatch]::StartNew()
            $sfOut = @(RunTool 'SFC' "$env:windir\System32\sfc.exe" '/scannow' ([Text.Encoding]::Unicode))
            KV 'Dauer' (Dur $sfSw.Elapsed)
            foreach ($sfL in $sfOut | Select-Object -First 12) { "  $sfL" }
            $sfJ = $sfOut -join ' '
            if ($sfJ -match 'konnte (aber )?(einige|nicht)|nicht reparieren|unable to fix|could not repair|could not perform') {
                KV 'Ergebnis' 'FEHLER - nicht alle Probleme behoben'
                FS 'SFC hat beschädigte Systemdateien gefunden, konnte aber nicht alle reparieren.' 'DISM /RestoreHealth ausführen, danach SFC wiederholen; Details in C:\Windows\Logs\CBS\CBS.log.'
            } elseif ($sfJ -match 'erfolgreich repariert|successfully repaired') {
                KV 'Ergebnis' 'OK - beschädigte Dateien repariert'
                FLow 'SFC hat beschädigte Systemdateien repariert.' 'Rechner neu starten und SFC zur Kontrolle erneut ausführen.'
            } elseif ($sfJ -match 'keine Integritätsverletzungen|did not find any integrity') {
                KV 'Ergebnis' 'OK - keine Integritätsverletzungen gefunden'
            } else {
                KV 'Ergebnis' 'unklar (Ausgabe prüfen)'
                F 'SFC-Ergebnis konnte nicht eindeutig ausgewertet werden.' 'Ausgabe prüfen und SFC bei Bedarf erneut als Administrator ausführen.'
            }
        } },
    @{ k = 'DISM'; t = 'Reparatur: Windows-Abbild (DISM RestoreHealth)'; c = 'WINDOWS'; r = $true; f = {
            KV 'Befehl' 'dism /online /cleanup-image /restorehealth'
            if (-not $isAdmin) { NeedAdmin 'DISM'; return }
            RpCreate 'DISM'
            $dsSw = [Diagnostics.Stopwatch]::StartNew()
            $dsOut = @(RunTool 'DISM' "$env:windir\System32\dism.exe" '/Online /Cleanup-Image /RestoreHealth' $script:oemEnc)
            $dsCode = $script:toolCode
            KV 'Dauer' (Dur $dsSw.Elapsed)
            foreach ($dsL in $dsOut | Select-Object -Last 8) { "  $dsL" }
            if ($dsCode -eq 0) { KV 'Ergebnis' 'OK - Vorgang erfolgreich abgeschlossen' }
            else {
                KV 'Ergebnis' "FEHLER - Exitcode $dsCode"
                FS "DISM RestoreHealth ist mit Fehlercode $dsCode beendet worden." 'Internetverbindung und Windows Update prüfen; alternativ DISM mit /Source (install.wim) ausführen. Log: C:\Windows\Logs\DISM\dism.log.'
            }
        } },
    @{ k = 'CHKDSK'; t = 'Reparatur: Dateisystem prüfen (CHKDSK, nur lesend)'; c = 'WINDOWS'; r = $true; f = {
            $ckDrv = $env:SystemDrive
            KV 'Befehl' "chkdsk $ckDrv (Online-Prüfung ohne /f, es wird nichts repariert)"
            if (-not $isAdmin) { NeedAdmin 'CHKDSK'; return }
            $ckSw = [Diagnostics.Stopwatch]::StartNew()
            $ckOut = @(RunTool 'CHKDSK' "$env:windir\System32\chkdsk.exe" $ckDrv $script:oemEnc)
            $ckCode = $script:toolCode
            KV 'Dauer' (Dur $ckSw.Elapsed)
            foreach ($ckL in $ckOut | Select-Object -Last 12) { "  $ckL" }
            if ($ckCode -eq 0) { KV 'Ergebnis' 'OK - keine Fehler gefunden' }
            elseif ($ckCode -eq 3) { KV 'Ergebnis' 'FEHLER - Prüfung nicht möglich'; F "CHKDSK konnte Laufwerk $ckDrv nicht prüfen." 'Als Administrator erneut ausführen oder Prüfung beim Neustart ansetzen (chkdsk /f).' }
            else { KV 'Ergebnis' "FEHLER - Exitcode $ckCode"; FS "CHKDSK meldet Dateisystemfehler auf $ckDrv (Exitcode $ckCode)." 'Datensicherung sicherstellen und Reparatur ansetzen (chkdsk C: /f, Prüfung läuft beim Neustart); Datenträger-SMART prüfen.' }
        } },
    @{ k = 'WUReset'; t = 'Reparatur: Windows-Update-Komponenten zurücksetzen'; c = 'WINDOWS'; r = $true; f = {
            KV 'Befehl' 'Update-Dienste stoppen, SoftwareDistribution und catroot2 umbenennen, Dienste starten'
            if (-not $isAdmin) { NeedAdmin 'Update-Reset'; return }
            RpCreate 'Update-Reset'
            $wuBad = 0
            foreach ($wuS in 'wuauserv', 'bits', 'cryptsvc', 'msiserver') {
                try { Stop-Service $wuS -Force -ErrorAction Stop; "Dienst $wuS gestoppt : OK" } catch { $wuBad++; "Dienst $wuS gestoppt : FEHLER ($($_.Exception.Message))" }
            }
            $wuStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
            foreach ($wuP in "$env:windir\SoftwareDistribution", "$env:windir\System32\catroot2") {
                $wuLeaf = Split-Path $wuP -Leaf
                if (Test-Path $wuP) {
                    try { Rename-Item -Path $wuP -NewName "$wuLeaf.bak_$wuStamp" -ErrorAction Stop; "Ordner $wuLeaf umbenannt : OK" } catch { $wuBad++; "Ordner $wuLeaf umbenannt : FEHLER ($($_.Exception.Message))" }
                } else { "Ordner $wuLeaf : nicht vorhanden" }
            }
            foreach ($wuS in 'cryptsvc', 'bits', 'wuauserv', 'msiserver') {
                try { Start-Service $wuS -ErrorAction Stop; "Dienst $wuS gestartet : OK" } catch { "Dienst $wuS gestartet : FEHLER ($($_.Exception.Message))" }
            }
            if ($wuBad) { F 'Update-Komponenten konnten nicht vollständig zurückgesetzt werden.' 'Rechner neu starten und den Vorgang wiederholen; laufende Update-Installationen vorher abwarten.' }
            else { 'Hinweis: Neustart empfehlen, danach Windows-Update erneut ausführen (die .bak-Ordner können später gelöscht werden).' }
        } },
    @{ k = 'DNSFlush'; t = 'Reparatur: DNS-Cache leeren'; c = 'NETZ UND DRUCKER'; r = $true; f = {
            KV 'Befehl' 'ipconfig /flushdns und ipconfig /registerdns'
            if (-not $isAdmin) { NeedAdmin 'DNS leeren'; return }
            [void](RunTool 'DNS' "$env:windir\System32\ipconfig.exe" '/flushdns' $script:oemEnc); $dnC1 = $script:toolCode
            "DNS-Cache leeren : $(if ($dnC1 -eq 0) { 'OK' } else { "FEHLER (Exitcode $dnC1)" })"
            [void](RunTool 'DNS' "$env:windir\System32\ipconfig.exe" '/registerdns' $script:oemEnc); $dnC2 = $script:toolCode
            "DNS neu registrieren : $(if ($dnC2 -eq 0) { 'OK' } else { "FEHLER (Exitcode $dnC2)" })"
            if ($dnC1 -ne 0) { F 'DNS-Cache konnte nicht geleert werden.' 'Als Administrator erneut ausführen; DNS-Client-Dienst (Dnscache) prüfen.' }
        } },
    @{ k = 'SpoolerFix'; t = 'Reparatur: Druckwarteschlange leeren'; c = 'NETZ UND DRUCKER'; r = $true; f = {
            KV 'Befehl' 'Spooler stoppen, Warteschlange (spool\PRINTERS) leeren, Spooler starten'
            if (-not $isAdmin) { NeedAdmin 'Spooler leeren'; return }
            $spBad = 0
            try { Stop-Service Spooler -Force -ErrorAction Stop; 'Druckspooler gestoppt : OK' } catch { $spBad++; "Druckspooler gestoppt : FEHLER ($($_.Exception.Message))" }
            $spDir = "$env:windir\System32\spool\PRINTERS"
            $spFiles = @(Get-ChildItem $spDir -File -ErrorAction SilentlyContinue)
            try { $spFiles | Remove-Item -Force -ErrorAction Stop; "Warteschlange geleert : OK ($($spFiles.Count) Dateien)" } catch { $spBad++; "Warteschlange geleert : FEHLER ($($_.Exception.Message))" }
            try { Start-Service Spooler -ErrorAction Stop; 'Druckspooler gestartet : OK' } catch { $spBad++; "Druckspooler gestartet : FEHLER ($($_.Exception.Message))" }
            if ($spBad) { F 'Druckspooler konnte nicht vollständig zurückgesetzt werden.' 'Druckspooler-Dienst manuell starten und Warteschlange prüfen (PaperJamZero aus den Siptools kann helfen).' }
        } },
    @{ k = 'OneAuthBackup'; t = 'Anmeldung: OneAuth und Anmeldeinformationen sichern'; c = 'ANMELDUNG UND OUTLOOK'; x = $true; f = {
            KV 'Benutzer' "$env:USERDOMAIN\$env:USERNAME"
            KV 'Quelle' 'OneAuth, IdentityCache, Office-Identität, Namen der Windows-Anmeldeinformationen'
            OaBackup
            'Hinweis: Kennwörter selbst werden nicht gesichert (Windows speichert sie verschlüsselt); nach einem Zurücksetzen meldet man sich neu an.'
            if (-not $script:oaDir) { F 'Sicherung von OneAuth und Anmeldeinformationen nicht vollständig.' 'Zielordner C:\SippicomInstall\backup prüfen (Rechte, Speicherplatz); geöffnete Office-Programme beenden und erneut versuchen.' }
        } },
    @{ k = 'OneAuthReset'; t = 'Reparatur: OneAuth und Anmeldeinformationen zurücksetzen'; c = 'ANMELDUNG UND OUTLOOK'; r = $true; f = {
            KV 'Befehl' 'Sicherung anlegen, OneAuth und IdentityCache umbenennen, Office-Identität und gespeicherte Office-Anmeldeinformationen löschen'
            KV 'Benutzer' "$env:USERDOMAIN\$env:USERNAME"
            $oaRun = @(Get-Process -Name 'OUTLOOK', 'WINWORD', 'EXCEL', 'POWERPNT', 'ONENOTE', 'MSACCESS', 'MSPUB', 'VISIO', 'WINPROJ', 'ms-teams', 'Teams', 'olk', 'OneDrive' -ErrorAction SilentlyContinue | Select-Object -ExpandProperty ProcessName -Unique)
            if ($oaRun.Count) {
                'Hinweis: Bitte zuerst speichern und schließen: ' + ($oaRun -join ', ')
                F 'OneAuth-Reset nicht ausgeführt: Office, Teams oder OneDrive sind noch geöffnet.' 'Programme speichern und beenden, dann das Werkzeug erneut starten.'
                return
            }
            OaBackup
            if (-not $script:oaDir) {
                F 'OneAuth-Reset abgebrochen: Sicherung fehlgeschlagen.' 'Zielordner C:\SippicomInstall\backup prüfen (Rechte, Speicherplatz) und erneut versuchen.'
                return
            }
            ''
            $oaBad = 0; $oaStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
            foreach ($oaF in OaFolders) {
                if (Test-Path $oaF.P) {
                    try { Rename-Item -Path $oaF.P -NewName "$($oaF.N).bak_$oaStamp" -ErrorAction Stop; "Ordner $($oaF.N) zurückgesetzt : OK" } catch { $oaBad++; "Ordner $($oaF.N) zurückgesetzt : FEHLER ($($_.Exception.Message))" }
                } else { "Ordner $($oaF.N) : nicht vorhanden" }
            }
            $oaK = 'HKCU:\Software\Microsoft\Office\16.0\Common\Identity\Identities'
            if (Test-Path $oaK) {
                try { Remove-Item -Path $oaK -Recurse -Force -ErrorAction Stop; 'Office-Identität zurückgesetzt : OK' } catch { $oaBad++; "Office-Identität zurückgesetzt : FEHLER ($($_.Exception.Message))" }
            } else { 'Office-Identität : nicht vorhanden' }
            $oaNames = @(OaCredNames @(RunTool 'Anmeldeinformationen' "$env:windir\System32\cmdkey.exe" '/list' $script:oemEnc))
            if ($oaNames.Count -eq 0) { 'Office-Anmeldeinformationen : keine gefunden' }
            foreach ($oaX in $oaNames) {
                [void](RunTool 'Anmeldeinformationen' "$env:windir\System32\cmdkey.exe" "/delete:`"$oaX`"" $script:oemEnc)
                if ($script:toolCode -eq 0) { "Anmeldeinformation gelöscht : OK  ($oaX)" } else { $oaBad++; "Anmeldeinformation gelöscht : FEHLER  ($oaX)" }
            }
            if ($oaBad) {
                KV 'Ergebnis' 'FEHLER - nicht alles zurückgesetzt'
                F 'OneAuth-Reset ist unvollständig.' ("Alle Office-, Teams- und OneDrive-Prozesse im Task-Manager beenden, Rechner neu starten und erneut ausführen. Sicherung: $($script:oaDir)")
            } else {
                KV 'Ergebnis' 'OK - zurückgesetzt'
                "Hinweis: Office, Teams und OneDrive neu starten und mit dem Konto neu anmelden. Sicherung: $($script:oaDir)"
            }
        } },
    @{ k = 'WlanBackup'; t = 'WLAN: Profile sichern'; c = 'SICHERUNG'; x = $true; f = {
            KV 'Befehl' 'netsh wlan export profile (alle gespeicherten WLAN-Profile als XML)'
            if (-not $isAdmin) { 'Hinweis: Ohne Administratorrechte werden die WLAN-Kennwörter nicht im Klartext gesichert.' }
            WlBackup
            if (-not $script:wlDir) { F 'WLAN-Sicherung nicht vollständig oder keine Profile vorhanden.' 'Zielordner C:\SippicomInstall\backup prüfen und erneut ausführen; für Kennwörter als Administrator starten.' }
        } },
    @{ k = 'WlanRestore'; t = 'Reparatur: WLAN-Profile wiederherstellen'; c = 'SICHERUNG'; r = $true; f = {
            KV 'Befehl' 'netsh wlan add profile (neueste Sicherung aus C:\SippicomInstall\backup\WLAN_*)'
            if (-not $isAdmin) { NeedAdmin 'WLAN-Restore'; return }
            WlRestore
        } },
    @{ k = 'BrowserBackup'; t = 'Sicherung: Browser-Favoriten, Favoritenleiste und Kennwortdateien (Edge, Chrome, Firefox)'; c = 'SICHERUNG'; x = $true; f = {
            KV 'Benutzer' "$env:USERDOMAIN\$env:USERNAME"
            KV 'Quelle' 'Favoriten inkl. Favoritenleiste (als HTML) und Kennwortdateien (verschlüsselt) von Edge, Chrome und Firefox'
            BwBackup
            if (-not $script:bwOk) { F 'Browser-Sicherung nicht vollständig.' 'Browser schließen und erneut ausführen; als betroffener Benutzer starten (nicht als fremder Administrator).' }
            # Optionaler Kennwort-Export als CSV: wird im Browser selbst bestätigt (Dialog mit Anleitung)
            PwExportDialog $script:bkLast
            if ($script:pxOk -and $script:pxPath) {
                'Kennwort-Export : bestätigt (OK)'
                KV 'CSV' $script:pxPath
                'Hinweis: Die CSV enthält Kennwörter im Klartext - nach dem Import sicher löschen.'
            } elseif ($script:pxOk) { 'Kennwort-Export : OK - keine Kennwörter vorhanden' }
            else { 'Hinweis: Kennwort-Export wurde nicht bestätigt (optional); alternativ Browser-Synchronisierung mit dem Konto nutzen.' }
        } },
    @{ k = 'NetDriveBackup'; t = 'Sicherung: Netzlaufwerke und Mappings'; c = 'SICHERUNG'; x = $true; f = {
            KV 'Benutzer' "$env:USERDOMAIN\$env:USERNAME"
            KV 'Quelle' 'Dauerhafte Netzlaufwerke, Netzwerkdrucker, Registry HKCU\Network'
            NlBackup
            if (-not $script:nlOk) { F 'Sicherung der Netzlaufwerke nicht vollständig.' 'Zielordner C:\SippicomInstall\backup prüfen (Rechte, Speicherplatz) und erneut ausführen.' }
        } },
    @{ k = 'OutlookBackup'; t = 'Outlook: Profil, Signaturen und Vorlagen sichern'; c = 'ANMELDUNG UND OUTLOOK'; x = $true; f = {
            KV 'Benutzer' "$env:USERDOMAIN\$env:USERNAME"
            KV 'Quelle' 'Outlook-Profile (Registrierung), Signaturen, Vorlagen, Autovervollständigen'
            OxBackup
            if (-not $script:oxOk) { F 'Outlook-Sicherung nicht vollständig.' 'Outlook schließen, Zielordner C:\SippicomInstall\backup prüfen und erneut ausführen.' }
        } },
    @{ k = 'OstReset'; t = 'Reparatur: Outlook-OST neu aufbauen'; c = 'ANMELDUNG UND OUTLOOK'; r = $true; f = {
            KV 'Befehl' 'Outlook-OST-Dateien umbenennen (.bak), Outlook baut sie beim nächsten Start neu auf'
            KV 'Benutzer' "$env:USERDOMAIN\$env:USERNAME"
            $osRun = @(Get-Process -Name 'OUTLOOK' -ErrorAction SilentlyContinue)
            if ($osRun.Count) {
                'Hinweis: Outlook ist noch geöffnet - bitte speichern und schließen.'
                F 'OST-Neuaufbau nicht ausgeführt: Outlook läuft noch.' 'Outlook beenden (auch im Task-Manager prüfen) und das Werkzeug erneut starten.'
                return
            }
            $osDir = "$env:LOCALAPPDATA\Microsoft\Outlook"
            $osFiles = @(Get-ChildItem -LiteralPath $osDir -Filter *.ost -File -ErrorAction SilentlyContinue)
            if ($osFiles.Count -eq 0) { 'OST-Dateien : keine gefunden (kein Exchange-/Microsoft-365-Cache vorhanden)'; return }
            $osBad = 0; $osStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
            foreach ($osF in $osFiles) {
                $osGb = [math]::Round($osF.Length / 1GB, 2)
                try { Rename-Item -LiteralPath $osF.FullName -NewName "$($osF.Name).bak_$osStamp" -ErrorAction Stop; "OST $($osF.Name) ($osGb GB) umbenannt : OK" } catch { $osBad++; "OST $($osF.Name) umbenannt : FEHLER ($($_.Exception.Message))" }
            }
            if ($osBad) {
                KV 'Ergebnis' 'FEHLER - nicht alle OST-Dateien umbenannt'
                F 'OST-Neuaufbau ist unvollständig.' 'Outlook und Hintergrundprozesse (OUTLOOK.EXE) beenden, ggf. Rechner neu starten und erneut ausführen.'
            } else {
                KV 'Ergebnis' 'OK - OST umbenannt'
                'Hinweis: Outlook jetzt starten; das Postfach wird neu vom Server geladen (kann je nach Größe dauern).'
                'Hinweis: Lokale Daten, die nur in der OST lagen (z. B. IMAP-/POP-Offlineelemente), gehen verloren; PST-Dateien bleiben unberührt.'
                'Hinweis: Die .bak-Dateien können nach erfolgreichem Neuaufbau gelöscht werden (Speicherplatz).'
            }
        } },
    @{ k = 'TempClean'; t = 'Reparatur: Temp-Dateien bereinigen'; c = 'WINDOWS'; r = $true; f = {
            KV 'Befehl' 'Temp-Dateien (älter als 1 Tag) löschen und Papierkorb leeren'
            KV 'Benutzer' "$env:USERDOMAIN\$env:USERNAME"
            TcClean
        } },
    @{ k = 'StoreReg'; t = 'Reparatur: Microsoft-Store-Apps neu registrieren'; c = 'WINDOWS'; r = $true; f = {
            KV 'Befehl' 'Add-AppxPackage -DisableDevelopmentMode -Register (alle Apps des angemeldeten Benutzers)'
            KV 'Benutzer' "$env:USERDOMAIN\$env:USERNAME"
            SaRegister
        } },
    @{ k = 'DHCPRenew'; t = 'Reparatur: DHCP-Lease erneuern'; c = 'NETZ UND DRUCKER'; r = $true; f = {
            KV 'Befehl' 'ipconfig /release und ipconfig /renew'
            if (-not $isAdmin) { NeedAdmin 'DHCP erneuern'; return }
            'Hinweis: Die Netzwerkverbindung wird kurz getrennt (Fernzugriff/RDP kann abbrechen).'
            DcRenew
        } },
    @{ k = 'TimeSync'; t = 'Reparatur: Uhrzeit neu synchronisieren'; c = 'NETZ UND DRUCKER'; r = $true; f = {
            KV 'Befehl' 'Zeitdienst prüfen und w32tm /resync /force'
            if (-not $isAdmin) { NeedAdmin 'Zeit-Sync'; return }
            ZtSync
        } },
    @{ k = 'AltDaten'; t = 'Aufräumen: alte Sicherungen, Mitschnitte und Berichte in C:\SippicomInstall löschen'; c = 'SICHERUNG'; r = $true; n = $true; f = {
            $adRoot = 'C:\SippicomInstall'
            KV 'Befehl' 'Dateien und Ordner in C:\SippicomInstall löschen, die älter sind als 30 Tage (Berichte im Ordner diagnose: älter als 90 Tage)'
            if (-not (Test-Path -LiteralPath $adRoot)) { 'Ordner C:\SippicomInstall : nicht vorhanden'; return }
            $adFree = 0; $adBad = 0; $adCnt = 0
            foreach ($adDir in @(Get-ChildItem -LiteralPath $adRoot -Directory -ErrorAction SilentlyContinue)) {
                $adDays = 30; if ($adDir.Name -eq 'diagnose') { $adDays = 90 }
                $adLimit = (Get-Date).AddDays(-$adDays)
                $adAll = @(Get-ChildItem -LiteralPath $adDir.FullName -Recurse -File -Force -ErrorAction SilentlyContinue)
                $adSize = [math]::Round((($adAll | Measure-Object -Property Length -Sum).Sum) / 1MB, 1)
                $adOld = @(Get-ChildItem -LiteralPath $adDir.FullName -Force -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $adLimit })
                KV ('Ordner ' + $adDir.Name) "$adSize MB gesamt, $($adOld.Count) Einträge älter als $adDays Tage"
                foreach ($adItem in $adOld) {
                    $adLen = 0
                    if ($adItem.PSIsContainer) { $adLen = (Get-ChildItem -LiteralPath $adItem.FullName -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum } else { $adLen = $adItem.Length }
                    try { Remove-Item -LiteralPath $adItem.FullName -Recurse -Force -ErrorAction Stop; $adFree += $adLen; $adCnt++ } catch { $adBad++; "Nicht gelöscht : $($adItem.Name) ($($_.Exception.Message))" }
                }
            }
            KV 'Gelöscht' "$adCnt Einträge, $([math]::Round($adFree / 1MB, 1)) MB frei"
            if ($adBad) { F "Aufräumen unvollständig: $adBad Einträge ließen sich nicht löschen." 'Programme schließen, die Dateien verwenden (z. B. Wireshark, Explorer), und erneut ausführen.' }
            else { KV 'Ergebnis' 'OK' }
            'Hinweis: Skriptkopie, Symbol und Verknüpfungsdateien direkt in C:\SippicomInstall bleiben erhalten.'
        } }
)

# ---------- Startbildschirm ----------
$sp = New-Object Windows.Forms.Form
$sp.FormBorderStyle = 'None'; $sp.StartPosition = 'CenterScreen'; $sp.Size = New-Object Drawing.Size(460, 300); $sp.BackColor = $sb
$sp.TopMost = $true; $sp.ShowInTaskbar = $false; $sp.Opacity = 0
Rnd $sp 16
$sp.Add_Paint({ param($s, $e)
        $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
        $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 0, 0, 460, 4)
        $g.DrawImage($logoImg, 190, 34, 80, 80)
        DTC $g 'SIPPICOM IT-Solutions' $fH $or (New-Object Drawing.Rectangle(0, 126, 460, 36))
        DTC $g $appName $fL $cWhite (New-Object Drawing.Rectangle(0, 160, 460, 40))
        DTC $g 'wird gestartet ...' $fN $mu (New-Object Drawing.Rectangle(0, 206, 460, 30))
        DTC $g "$cpy  |  Tel. $telefon  |  www.sippicom.com" $fS $mu (New-Object Drawing.Rectangle(0, 262, 460, 24))
    })
$sp.Show()
for ($o = 0.0; $o -le 1.0; $o += 0.1) { $sp.Opacity = [math]::Min($o, 1); [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 25 }
$t0 = Get-Date; while (((Get-Date) - $t0).TotalMilliseconds -lt 900) { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 40 }
for ($o = 1.0; $o -ge 0.0; $o -= 0.1) { $sp.Opacity = [math]::Max($o, 0); [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 20 }
$sp.Close()

# ---------- Hauptfenster ----------
$form = New-Object Windows.Forms.Form
$form.Text = "Sippicom IT-Solutions - $appName"; $form.FormBorderStyle = 'None'; $form.Size = New-Object Drawing.Size(1100, (780 + $dh))
$form.StartPosition = 'CenterScreen'; $form.BackColor = $bg; $form.ForeColor = $tx; $form.Font = $fN; $form.Opacity = 0
DB $form
if ($ico) { $form.Icon = $ico }
# Eigene Anwendungskennung: Die Taskleiste zeigt dann das Fenster-Icon (Sippicom-Logo) statt des PowerShell-Symbols
try {
    Add-Type -Namespace Sip -Name Shell -MemberDefinition '[DllImport("shell32.dll", CharSet = CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string id);'
    [void][Sip.Shell]::SetCurrentProcessExplicitAppUserModelID('Sippicom.Diagnosezentrum')
} catch {}
$fade =New-Object Windows.Forms.Timer; $fade.Interval = 15
$fade.Add_Tick({ $form.Opacity = [math]::Min(1.0, $form.Opacity + 0.08); if ($form.Opacity -ge 1.0) { $fade.Stop() } })
$form.Add_Shown({ DwmRound $form.Handle; $fade.Start(); if ($updTm) { $updTm.Start() } })
$script:siMain = @{}
function MainBg([bool]$mbLight, [int]$mbW, [int]$mbH) {
    $mbKey = "$mbLight|$mbW|$mbH"
    if (-not $script:siMain.ContainsKey($mbKey)) {
        $script:siMain.Clear(); $script:siMain[$mbKey] = $null
        $mbName = 'C3a'; if ($mbLight) { $mbName = 'C3b' }
        $mbF = AssetPath $mbName
        if ($mbF -and $script:imgOk) { try { $script:siMain[$mbKey] = [Sip.Img]::Cover($mbF, $mbW, $mbH, [single]0.5, [single]0.5) } catch {} }
    }
    return $script:siMain[$mbKey]
}
$form.Add_Paint({ param($s, $e)
        $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
        $mbImg = MainBg ([bool]$script:light) $s.ClientSize.Width $s.ClientSize.Height
        if ($mbImg) { $g.DrawImage($mbImg, 0, 0, $s.ClientSize.Width, $s.ClientSize.Height); return }
        $gp = New-Object Drawing.Drawing2D.GraphicsPath; $gp.AddEllipse(560, -240, 820, 560)
        $pg = New-Object Drawing.Drawing2D.PathGradientBrush($gp)
        $pg.CenterColor = [Drawing.Color]::FromArgb(40, 242, 140, 40)
        $pg.SurroundColors = [Drawing.Color[]]@([Drawing.Color]::FromArgb(0, 242, 140, 40))
        $g.FillPath($pg, $gp); $pg.Dispose(); $gp.Dispose()
    })
$drag = { [void][Sip.Win]::ReleaseCapture(); [void][Sip.Win]::SendMessage($form.Handle, 0xA1, 2, 0) }

# Titelleiste
$tbar = New-Object Windows.Forms.Panel; $tbar.SetBounds(0, 0, 1100, 40); $tbar.BackColor = $tb; DB $tbar; $form.Controls.Add($tbar)
$tbar.Add_Paint({ param($s, $e)
        $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
        $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 0, 0, 1100, 3)
        $g.DrawImage($logoImg, 14, 10, 22, 22)
        DT $g "Sippicom IT-Solutions  -  $appName" $fS $mu 44 12
        # Kunde bzw. Ticket (aus der Abfrage beim Programmstart oder dem Feld KUNDE / TICKET) steht oben in der Titelleiste
        $tbKt = ''; if ($tkb) { $tbKt = $tkb.Text.Trim() }
        if ($tbKt) { $tbW = TW $g "Sippicom IT-Solutions  -  $appName" $fS; DT $g ('|   Kunde / Ticket: ' + (Cut $tbKt 50)) $fSB $or (44 + $tbW + 12) 12 }
    })
$tbar.Add_MouseDown($drag)
$tip = New-Object Windows.Forms.ToolTip
function NewTb($glyph, $x, $tipText, $hov, $act, $nm) {
    $l = New-Object Windows.Forms.Label; $l.Text = $glyph; $l.SetBounds($x, 3, 50, 37); $l.AutoSize = $false; $l.TextAlign = 'MiddleCenter'
    $l.Font = $fG; $l.ForeColor = $tx; $l.BackColor = $tb; $l.Cursor = 'Hand'; $l.Tag = $hov; $l.Name = $nm
    $l.Add_MouseEnter({ param($s, $e) $s.BackColor = $s.Tag; if ($s.Name -eq 'close') { $s.ForeColor = $cWhite } else { $s.ForeColor = $cTxt } })
    $l.Add_MouseLeave({ param($s, $e) $s.BackColor = $tb; $s.ForeColor = $tx })
    $l.Add_Click($act); if ($tipText) { $tip.SetToolTip($l, $tipText) }
    $tbar.Controls.Add($l); $script:lastTb = $l
}
NewTb ([string][char]0xE8BB) 1050 'Schließen' $rd { for ($o = 1.0; $o -gt 0.0; $o -= 0.12) { $form.Opacity = [math]::Max($o, 0.0); [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 12 }; $form.Close() } 'close'
NewTb ([string][char]0xE921) 1000 'Minimieren' $cOffHv { $form.WindowState = 'Minimized' } 'min'
# Titelleisten-Icons (C2, 4 x 2): 0 Diagnosen, 1 Reparatur, 2 Hilfe, 3 Sonne, 4 Mond, 5 Pin, 6 Blitz, 7 Kundenbericht
$script:siTb = @{}
function TbIcon($tbL, [int]$tbK) {
    if (-not $script:siTb.ContainsKey($tbK)) {
        $script:siTb[$tbK] = $null
        $tbF = AssetPath 'C2'
        if ($tbF -and $script:imgOk) { try { $script:siTb[$tbK] = [Sip.Img]::Cell($tbF, 4, 2, $tbK, 22, $true) } catch {} }
    }
    if ($script:siTb[$tbK]) { $tbL.Text = ''; $tbL.Image = $script:siTb[$tbK]; $tbL.ImageAlign = 'MiddleCenter' }
}
NewTb ([string][char]0xE718) 950 'Desktop-Verknüpfung mit Sippicom-Logo erstellen' $cOffHv { NewDesktopLink } 'pin'
TbIcon $script:lastTb 5
NewTb ([string][char]0xE706) 900 'Zwischen dunklem und hellem Modus wechseln' $cOffHv { ApplyTheme (-not $script:light); RefreshTheme } 'theme'
$tgl = $script:lastTb
NewTb ([string][char]0xE897) 850 'Hilfe und Erklärung zu allen Kategorien' $cOffHv { ShowHelp } 'help'
TbIcon $script:lastTb 2
NewTb ([string][char]0xE945) 800 'Schnell-Check: nur System, Netzwerk, Updates und Sicherheit prüfen' $cOffHv { QuickCheck } 'quick'
TbIcon $script:lastTb 6
NewTb ([string][char]0xE8A5) 750 'Kundenbericht: leicht verständliche, druckbare Zusammenfassung des letzten Laufs' $cOffHv { CustomerReport } 'cust'
TbIcon $script:lastTb 7

# Seitenleiste mit Reitern DIAGNOSEN / REPARATUR
$side = New-Object Windows.Forms.Panel; $side.SetBounds(0, 40, 264, (740 + $dh)); $side.BackColor = $sb; DB $side; $form.Controls.Add($side)
# Gruppen: N = Name (muss mit c der Einträge übereinstimmen), Y = Überschrift y, T = Reiter
$gdef = @(
    @{ N = 'GERÄT'; Y = 162; T = 'diag' },
    @{ N = 'NETZWERK'; Y = 294; T = 'diag' },
    @{ N = 'ARBEITSPLATZ'; Y = 460; T = 'diag' },
    @{ N = 'WERKZEUGE'; Y = 558; T = 'diag' },
    @{ N = 'WINDOWS'; Y = 162; T = 'rep' },
    @{ N = 'NETZ UND DRUCKER'; Y = 288; T = 'rep' },
    @{ N = 'ANMELDUNG UND OUTLOOK'; Y = 380; T = 'rep' },
    @{ N = 'SICHERUNG'; Y = 472; T = 'rep' }
)
# Kategorien der Seitenleiste (Version 1.9.0) und Zuordnung der Kacheln (Schlüssel = $d.k, klein geschrieben)
$script:ncList = @('Schnellstart', 'System', 'Netzwerk', 'Anmeldung und M365', 'Sicherheit', 'Drucker', 'Mitschnitt', 'Sichern')
$script:ncIco = @{ 'Schnellstart' = 3; 'System' = 6; 'Netzwerk' = 1; 'Anmeldung und M365' = 2; 'Sicherheit' = 8; 'Drucker' = 7; 'Mitschnitt' = 4; 'Sichern' = 5 }
$script:ncMap = @{
    'system' = 'System'; 'hardware' = 'System'; 'updates' = 'System'; 'eventlogs' = 'System'; 'sfc' = 'System'; 'dism' = 'System'; 'chkdsk' = 'System'; 'wureset' = 'System'; 'tempclean' = 'System'; 'storereg' = 'System'
    'netzwerk' = 'Netzwerk'; 'wlan' = 'Netzwerk'; 'vpn' = 'Netzwerk'; 'proxy' = 'Netzwerk'; 'zeit' = 'Netzwerk'; 'web' = 'Netzwerk'; 'nettools' = 'Netzwerk'; 'dnsflush' = 'Netzwerk'; 'dhcprenew' = 'Netzwerk'; 'timesync' = 'Netzwerk'
    'm365' = 'Anmeldung und M365'; 'office' = 'Anmeldung und M365'; 'oneauthbackup' = 'Anmeldung und M365'; 'oneauthreset' = 'Anmeldung und M365'; 'outlookbackup' = 'Anmeldung und M365'; 'ostreset' = 'Anmeldung und M365'
    'sicherheit' = 'Sicherheit'; 'security' = 'Sicherheit'; 'ablauf' = 'Sicherheit'
    'drucker' = 'Drucker'; 'spoolerfix' = 'Drucker'
    'packetcapture' = 'Mitschnitt'
    'backup' = 'Sichern'; 'wlanbackup' = 'Sichern'; 'wlanrestore' = 'Sichern'; 'browserbackup' = 'Sichern'; 'netdrivebackup' = 'Sichern'; 'altdaten' = 'Sichern'
}
# Kacheln, die im Schnellstart immer erscheinen (zusätzlich alle bereits gewählten)
$script:ncFav = @('system', 'netzwerk', 'updates', 'sicherheit', 'security', 'm365', 'office', 'drucker', 'ablauf')
# Doppelt breite Kacheln (wichtige Funktionen, mehr Platz für die Beschreibung)
$script:ncWide = @('system', 'netzwerk', 'm365', 'packetcapture')
# Kurzbeschreibung je Kachel
$script:ncDesc = @{
    'system' = 'Windows, Laufwerke, Speicher und Neustart'; 'hardware' = 'Prozessor, Arbeitsspeicher, Datenträger, Akku'; 'sicherheit' = 'Defender, Firewall und Schutzstatus'; 'security' = 'Defender, Firewall und Schutzstatus'
    'updates' = 'Windows Update und ausstehende Neustarts'; 'backup' = 'Zustand der Datensicherung prüfen'; 'eventlogs' = 'Fehler, Abstürze und Neustarts der letzten Tage'
    'netzwerk' = 'Adapter, IP-Adresse, DNS, Gateway und Internet'; 'wlan' = 'Signal, Profile und Verbindung'; 'vpn' = 'Cisco-VPN: Client, Dienste und Gateway'; 'proxy' = 'System-Proxy, PAC und WPAD'
    'zeit' = 'Uhrzeit und Zeitsynchronisierung'; 'm365' = 'Microsoft 365: Version, Kanal und Anmeldung'; 'office' = 'Outlook, Teams, Add-ins und WebView2'; 'drucker' = 'Drucker, Warteschlange und Spooler'
    'ablauf' = 'Zertifikate, Kennwortablauf und BitLocker'; 'nettools' = 'Gateway-Ping, Trace, Speedtest, Cisco-Adapter'; 'web' = 'Webseiten prüfen: DNS, TLS und HTTP je Ziel'; 'packetcapture' = 'Netzwerk-Mitschnitt (pktmon) mit Auswertung'
    'sfc' = 'Systemdateien prüfen und reparieren'; 'dism' = 'Windows-Abbild reparieren (RestoreHealth)'; 'chkdsk' = 'Dateisystem prüfen, nur lesend'; 'wureset' = 'Windows-Update-Komponenten zurücksetzen'
    'tempclean' = 'Temporäre Dateien bereinigen'; 'storereg' = 'Store-Apps neu registrieren'; 'dnsflush' = 'DNS-Zwischenspeicher leeren'; 'spoolerfix' = 'Druckwarteschlange leeren, Spooler neu starten'
    'dhcprenew' = 'IP-Adresse per DHCP erneuern'; 'timesync' = 'Uhrzeit mit der Zeitquelle abgleichen'; 'oneauthbackup' = 'Anmeldedaten der Office-Konten sichern'; 'oneauthreset' = 'Office-Anmeldung zurücksetzen (OneAuth)'
    'outlookbackup' = 'Outlook-Profile und Einstellungen sichern'; 'ostreset' = 'OST-Datei neu aufbauen lassen'; 'wlanbackup' = 'WLAN-Profile sichern'; 'wlanrestore' = 'WLAN-Profile wiederherstellen'
    'browserbackup' = 'Favoriten von Edge und Chrome sichern'; 'netdrivebackup' = 'Netzlaufwerke sichern'; 'altdaten' = 'Alte Berichte und Sicherungen löschen'
}
$script:cat = 'Schnellstart'; $script:mode = 'alle'; $script:view = 'sel'
$script:links = @(
    @{ Key = 'all'; Text = 'Alle wählen'; X = 24; Y = 432; R = (New-Object Drawing.Rectangle(20, 430, 92, 20)); Fnt = $fSB; Col = $mu; Tab = '*' },
    @{ Key = 'none'; Text = 'Keine'; X = 122; Y = 432; R = (New-Object Drawing.Rectangle(118, 430, 50, 20)); Fnt = $fSB; Col = $mu; Tab = '*' }
)
for ($gi = 0; $gi -lt $script:ncList.Count; $gi++) {
    $script:links += @{ Key = "cat$gi"; Text = ''; X = 0; Y = 0; R = (New-Object Drawing.Rectangle(14, (148 + 34 * $gi), 236, 30)); Fnt = $fS; Col = $mu; Tab = '*' }
}
$sub = "NUR LESEND  $([char]0xB7)  REPARATUR OPTIONAL"
$f1 = New-Object Drawing.Font('Segoe UI Semibold', 22); $f2 = New-Object Drawing.Font('Segoe UI Light', 22); $f3 = New-Object Drawing.Font('Segoe UI Semibold', 8)
$fU = New-Object Drawing.Font('Segoe UI Semibold', 9, [Drawing.FontStyle]::Underline)
$side.Add_Paint({ param($s, $e)
        $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'; $g.InterpolationMode = 'HighQualityBicubic'
        $r = New-Object Drawing.Rectangle(0, 0, $s.Width, $s.Height)
        $lg = New-Object Drawing.Drawing2D.LinearGradientBrush($r, $script:sbA, $script:sbB, [single]90)
        $g.FillRectangle($lg, $r); $lg.Dispose()
        if (-not $script:siSideTried) {
            $script:siSideTried = $true
            $siP = AssetPath 'A1'
            if ($siP -and $script:imgOk) {
                try {
                    $script:siSide = [Sip.Img]::Cover($siP, $s.Width, $s.Height, 0.0, 1.0)
                    $siM = New-Object Drawing.Imaging.ColorMatrix; $siM.Matrix33 = 0.85
                    $script:siSideAttr = New-Object Drawing.Imaging.ImageAttributes; $script:siSideAttr.SetColorMatrix($siM)
                } catch { $script:siSide = $null }
            }
        }
        if ($script:light -and -not $script:siSideLTried) {
            $script:siSideLTried = $true
            $siPL = AssetPath 'B5b'
            if ($siPL -and $script:imgOk) { try { $script:siSideL = [Sip.Img]::Cover($siPL, $s.Width, $s.Height, 0.0, 1.0) } catch {} }
        }
        if ($script:light -and $script:siSideL) {
            $g.DrawImage($script:siSideL, 0, 0, $s.Width, $s.Height)
        } elseif ($script:siSide -and -not $script:light) {
            $g.DrawImage($script:siSide, $r, 0, 0, $script:siSide.Width, $script:siSide.Height, [Drawing.GraphicsUnit]::Pixel, $script:siSideAttr)
        } else {
            $gp = New-Object Drawing.Drawing2D.GraphicsPath; $gp.AddEllipse(-120, ($s.Height - 170), 500, 340)
            $pg = New-Object Drawing.Drawing2D.PathGradientBrush($gp)
            $pg.CenterColor = [Drawing.Color]::FromArgb(70, 242, 140, 40)
            $pg.SurroundColors = [Drawing.Color[]]@([Drawing.Color]::FromArgb(0, 242, 140, 40))
            $g.FillPath($pg, $gp); $pg.Dispose(); $gp.Dispose()
        }
        $g.FillRectangle((New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(60, 242, 140, 40))), ($s.Width - 1), 0, 1, $s.Height)
        if ($script:light) { $g.FillPath((New-Object Drawing.SolidBrush((Hx '#1F1F21'))), (RR (New-Object Drawing.Rectangle(12, 8, 218, 62)) 12)) }
        $g.DrawImage($wideImg, 22, 12, 200, 60)
        $w1 = TW $g $appA $f1
        DT $g $appA $f1 $cTxt 22 66
        DT $g $appB $f2 $or (22 + $w1) 66
        DT $g $sub $f3 $mu 24 106
        $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 24, 126, 34, 3)
        # Kategorienliste (ein Klick zeigt die Kacheln der Kategorie im Hauptbereich)
        $sbkCnt = @{}; $sbkTot = 0
        foreach ($sbkD in $diag) { if ($sbkD.pn -and $sbkD.pn.Tag.On) { $sbkCnt[$sbkD.pn.Tag.Cat] = 1 + [int]$sbkCnt[$sbkD.pn.Tag.Cat]; $sbkTot++ } }
        for ($sbkI = 0; $sbkI -lt $script:ncList.Count; $sbkI++) {
            $sbkN = $script:ncList[$sbkI]; $sbkY = 148 + 34 * $sbkI
            $sbkAct = ($script:cat -eq $sbkN)
            if ($sbkAct -or $script:hot -eq "cat$sbkI") {
                $sbkA = 18; if ($sbkAct) { $sbkA = 44 }
                $g.FillPath((New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb($sbkA, 242, 140, 40))), (RR (New-Object Drawing.Rectangle(14, $sbkY, 236, 30)) 8))
            }
            if ($sbkAct) { $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 14, ($sbkY + 6), 3, 18) }
            $sbkImg = GroupImg ([int]$script:ncIco[$sbkN])
            if ($sbkImg) { $g.InterpolationMode = 'HighQualityBicubic'; $g.DrawImage($sbkImg, 26, ($sbkY + 6), 18, 18) }
            $sbkF = $fN; $sbkC = $mu; if ($sbkAct) { $sbkF = $fSB; $sbkC = $cTxt }
            DT $g $sbkN $sbkF $sbkC 52 ($sbkY + 7)
            $sbkNum = $sbkTot; if ($sbkN -ne 'Schnellstart') { $sbkNum = [int]$sbkCnt[$sbkN] }
            if ($sbkNum -gt 0) { $sbkTxt = "$sbkNum"; DT $g $sbkTxt $fSB $or (242 - (TW $g $sbkTxt $fSB)) ($sbkY + 7) }
        }
        foreach ($l in $script:links) {
            if ($l.Text -eq '') { continue }
            $col = $l.Col; if ($script:hot -eq $l.Key) { $col = $cTxt }
            DT $g $l.Text $l.Fnt $col $l.X ($l.Y - 1)
        }
        # Zusammenfassung der Auswahl (über alle Kategorien)
        $g.FillRectangle((New-Object Drawing.SolidBrush($script:sepCol)), 22, 456, 220, 1)
        $sbkMax = [int][math]::Min(9, [math]::Floor((516 + $dh - 492) / 17))
        if ($sbkTot -gt 0 -and $sbkMax -gt 0) {
            DT $g "AUSGEWÄHLT ($sbkTot)" $fSB $or 24 464
            $sbkL = 0
            foreach ($sbkD in $diag) {
                if ($sbkD.pn.Tag.On) {
                    if ($sbkL -lt $sbkMax) { DT $g (Cut $sbkD.pn.Tag.T 26) $fS $cTxt 24 (486 + 17 * $sbkL) }
                    $sbkL++
                }
            }
            if ($sbkL -gt $sbkMax) { DT $g ('+ ' + ($sbkL - $sbkMax) + ' weitere') $fS $mu 24 (486 + 17 * $sbkMax) }
        } elseif ($sbkTot -eq 0) { DT $g 'Noch nichts gewählt.' $fS $mu 24 464 }
        # (Hinweise zu Reparaturen stehen seit 1.9.0 im Auswahlbereich)
        $fy = $script:fy
        $g.FillRectangle((New-Object Drawing.SolidBrush($script:sepCol)), 22, ($fy - 10), 220, 1)
        DT $g $cpy $fSB $cTxt 22 ($fy - 1)
        $rows = @(@([string][char]0xE717, "Tel. $telefon", ($fy + 22)), @([string][char]0xE774, 'www.sippicom.com', ($fy + 41)))
        foreach ($rw in $rows) { DT $g $rw[0] $fG $or 22 ($rw[2] + 1); DT $g $rw[1] $fS $mu 42 ($rw[2] - 1) }
        $my = $fy + 60
        DT $g ([string][char]0xE715) $fG $or 22 ($my + 1)
        if ($script:hot -eq 'mail') { DT $g $mail $fU $orH 42 ($my - 1) } else { DT $g $mail $fSB $or 42 ($my - 1) }
    })
$script:links += @{ Key = 'mail'; Text = ''; X = 0; Y = 0; R = (New-Object Drawing.Rectangle(20, ($script:fy + 58), 190, 22)); Fnt = $fS; Col = $mu; Tab = '*' }
function HitKey($pt) {
    foreach ($l in $script:links) {
        if ($l.Tab -ne '*' -and $l.Tab -ne $script:tab) { continue }
        if ($l.R.Contains($pt)) { return $l.Key }
    }
    return $null
}
$side.Add_MouseMove({ param($s, $e)
        $k = HitKey $e.Location
        if ($k -ne $script:hot) { $script:hot = $k; if ($k) { $s.Cursor = [Windows.Forms.Cursors]::Hand } else { $s.Cursor = [Windows.Forms.Cursors]::Default }; $s.Invalidate() }
    })
$side.Add_MouseLeave({ param($s, $e) if ($script:hot) { $script:hot = $null; $s.Cursor = [Windows.Forms.Cursors]::Default; $s.Invalidate() } })
$side.Add_MouseDown({ param($s, $e)
        $k = HitKey $e.Location
        switch -Regex ($k) {
            '^cat(\d)$' { SetCat $script:ncList[[int]$Matches[1]] }
            '^all$' { SetAll $null $true }
            '^none$' { SetAll $null $false }
            '^mail$' { SendSupportMail }
            default { & $drag }
        }
    })
# Reiter wechseln: nur die Kacheln des aktiven Reiters sind sichtbar (Auswahl bleibt erhalten)
function SetTab($t) {
    # Kompatibilität (Schnell-Check): 'diag' = Schnellstart mit allen Kacheln, 'rep' = nur Reparaturen
    $script:tab = $t
    $script:mode = 'alle'; $script:cat = 'Schnellstart'
    if ($t -eq 'rep') { $script:mode = 'reparieren' }
    if ($gsb) { ClearSearch }
    if ($script:view -ne 'sel') { SetView 'sel' }
    LayoutTiles; $script:hot = $null; $side.Invalidate()
}
# "Alle" wählt die sichtbaren Kacheln der aktuellen Ansicht (im Modus Reparieren nur Reparaturen, sonst nur Prüfungen); "Keine" leert die gesamte Auswahl
function SetAll($cat, $on) {
    $saRep = ($script:mode -eq 'reparieren')
    foreach ($d in $diag) {
        $dRep = [bool]($d.r -or $d.x)
        if ($cat) { if ($d.c -ne $cat) { continue }; $d.pn.Tag.On = ([bool]$on -and -not ($d.n -and $dRep)) }
        elseif (-not $on) { $d.pn.Tag.On = $false }
        elseif ((TileVisible $d) -and ($dRep -eq $saRep) -and -not ($d.n -and $dRep)) { $d.pn.Tag.On = $true }
        $d.pn.Invalidate()
    }
    $side.Invalidate(); if ($viewBar) { $viewBar.Invalidate() }; if ($gridP) { LayoutTiles }
}
function ToggleCat($cat) {
    $allOn = (@($diag | Where-Object { $_.c -eq $cat -and -not $_.pn.Tag.On }).Count -eq 0)
    SetAll $cat (-not $allOn)
}

# Kachel-Hintergründe (C5: links normal, rechts gewählt), nur im dunklen Modus; aus der Datei zugeschnitten auf 216 x 60
$script:siTileBg = $null
function TileBg([int]$tbgK) {
    if ($null -eq $script:siTileBg) {
        $script:siTileBg = New-Object object[] 2
        $tbgF = AssetPath 'C5'
        if ($tbgF -and $script:imgOk) {
            try {
                $tbgSrc = New-Object Drawing.Bitmap($tbgF)
                $tbgSw = $tbgSrc.Width / 1024.0; $tbgSh = $tbgSrc.Height / 254.0
                $tbgR = @((New-Object Drawing.RectangleF((44 * $tbgSw), (52 * $tbgSh), (440 * $tbgSw), (150 * $tbgSh))), (New-Object Drawing.RectangleF((552 * $tbgSw), (52 * $tbgSh), (430 * $tbgSw), (150 * $tbgSh))))
                for ($tbgI = 0; $tbgI -lt 2; $tbgI++) {
                    $tbgB = New-Object Drawing.Bitmap(216, 60)
                    $tbgG = [Drawing.Graphics]::FromImage($tbgB)
                    $tbgG.InterpolationMode = 'HighQualityBicubic'
                    $tbgG.DrawImage($tbgSrc, (New-Object Drawing.Rectangle(0, 0, 216, 60)), $tbgR[$tbgI], [Drawing.GraphicsUnit]::Pixel)
                    $tbgG.Dispose(); $script:siTileBg[$tbgI] = $tbgB
                }
                $tbgSrc.Dispose()
            } catch {}
        }
    }
    return $script:siTileBg[$tbgK]
}
# Auswahl-Kacheln (Rahmen liegt 1 px innerhalb der Fläche; zu langer Text wird automatisch kleiner gesetzt)
for ($gi = 0; $gi -lt $gdef.Count; $gi++) {
    $i = 0
    foreach ($d in $diag | Where-Object { $_.c -eq $gdef[$gi].N }) {
        $cx = 22 + ($i % 2) * 114; $cy = $gdef[$gi].Y + 22 + 34 * [int][math]::Floor($i / 2)
        $p = New-Object Windows.Forms.Panel; $p.SetBounds($cx, $cy, 108, 30); $p.BackColor = $sb; $p.Cursor = 'Hand'; DB $p
        $lbl = $d.k; if ($lbl -eq 'Eventlogs') { $lbl = 'Ereignisse' }; if ($lbl -eq 'VPN') { $lbl = 'VPN (Cisco)' }; if ($lbl -eq 'Zeit') { $lbl = 'Uhrzeit' }; if ($lbl -eq 'M365') { $lbl = 'Microsoft 365' }; if ($lbl -eq 'Office') { $lbl = 'Outlook/Teams' }
        if ($lbl -eq 'DNSFlush') { $lbl = 'DNS leeren' }; if ($lbl -eq 'WUReset') { $lbl = 'Update-Reset' }; if ($lbl -eq 'SpoolerFix') { $lbl = 'Spooler leeren' }
        if ($lbl -eq 'OneAuthBackup') { $lbl = 'OneAuth sichern' }; if ($lbl -eq 'OneAuthReset') { $lbl = 'OneAuth-Reset' }
        if ($lbl -eq 'WlanBackup') { $lbl = 'WLAN sichern' }; if ($lbl -eq 'WlanRestore') { $lbl = 'WLAN-Restore' }
        if ($lbl -eq 'Ablauf') { $lbl = 'Zertifikate' }; if ($lbl -eq 'NetTools') { $lbl = 'Netz-Tools' }; if ($lbl -eq 'PacketCapture') { $lbl = 'Mitschnitt' }
        if ($lbl -eq 'TempClean') { $lbl = 'Temp bereinigen' }; if ($lbl -eq 'StoreReg') { $lbl = 'Store-Apps' }
        if ($lbl -eq 'DHCPRenew') { $lbl = 'DHCP erneuern' }; if ($lbl -eq 'TimeSync') { $lbl = 'Zeit-Sync' }
        if ($lbl -eq 'OutlookBackup') { $lbl = 'Outlook sichern' }; if ($lbl -eq 'OstReset') { $lbl = 'OST neu aufbauen' }
        if ($lbl -eq 'BrowserBackup') { $lbl = 'Browser sichern' }; if ($lbl -eq 'NetDriveBackup') { $lbl = 'Laufwerke sichern' }; if ($lbl -eq 'AltDaten') { $lbl = 'Altdaten löschen' }
        $ncK = ([string]$d.k).ToLower()
        $ncC = $script:ncMap[$ncK]
        if (-not $ncC) { $ncC = 'System'; switch ([string]$d.c) { 'NETZWERK' { $ncC = 'Netzwerk' } 'ARBEITSPLATZ' { $ncC = 'Anmeldung und M365' } 'SICHERUNG' { $ncC = 'Sichern' } 'WERKZEUGE' { $ncC = 'Sichern' } } }
        $ncTg = ''; if ($d.r) { $ncTg = 'Reparatur' } elseif ($d.x) { $ncTg = 'Sicherung' }
        $p.Tag = @{ T = $lbl; On = $false; Hot = $false; Ico = $script:siTileMap[$ncK]; Cat = $ncC; Fav = [bool]($script:ncFav -contains $ncK); W = [bool]($script:ncWide -contains $ncK); D =[string]$script:ncDesc[$ncK]; Tg = $ncTg }
        $p.Visible = $false
        $p.Add_MouseEnter({ param($s, $e) $s.Tag.Hot = $true; $s.Invalidate() })
        $p.Add_MouseLeave({ param($s, $e) $s.Tag.Hot = $false; $s.Invalidate() })
        $p.Add_Click({ param($s, $e) $s.Tag.On = -not $s.Tag.On; $s.Invalidate(); $side.Invalidate(); if ($viewBar) { $viewBar.Invalidate() } })
        $p.Add_Paint({ param($s, $e)
                $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
                $t = $s.Tag; $r = New-Object Drawing.Rectangle(1, 1, ($s.Width - 3), ($s.Height - 3))
                $c1 = $script:tileA; $c2 = $script:tileB
                if ($t.Hot) { $c1 = $script:tileHot }
                if ($t.On) {
                    if ($script:light) { $c1 = [Drawing.Color]::FromArgb(255, 244, 228); $c2 = [Drawing.Color]::FromArgb(250, 232, 205) }
                    else { $c1 = [Drawing.Color]::FromArgb(62, 46, 30); $c2 = [Drawing.Color]::FromArgb(44, 34, 24) }
                }
                $path = RR $r 10
                $g.FillPath((New-Object Drawing.Drawing2D.LinearGradientBrush($r, $c1, $c2, 90)), $path)
                if ($t.On) { $pen = New-Object Drawing.Pen($or, 1.6) }
                elseif ($t.Hot) { $pen = New-Object Drawing.Pen([Drawing.Color]::FromArgb(150, 242, 140, 40), 1.2) }
                else { $pen = New-Object Drawing.Pen($script:tileBd) }
                $g.DrawPath($pen, $path)
                $tIco = TileImg ([string]$t.Ico)
                $tIx = 12; $tIy = 11
                if ($tIco) {
                    $g.InterpolationMode = 'HighQualityBicubic'
                    $tDst = New-Object Drawing.Rectangle($tIx, $tIy, 34, 34)
                    if ($t.On -or $t.Hot) { $g.DrawImage($tIco, $tDst) }
                    else { $g.DrawImage($tIco, $tDst, 0, 0, $tIco.Width, $tIco.Height, [Drawing.GraphicsUnit]::Pixel, (DimAttr)) }
                } else {
                    $g.FillEllipse((New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(40, 242, 140, 40))), $tIx, $tIy, 34, 34)
                    DTC $g (([string]$t.T).Substring(0, 1)) $fH $or (New-Object Drawing.Rectangle($tIx, $tIy, 34, 34))
                }
                $tNm = $fB
                if ((TW $g $t.T $fB) -gt ($s.Width - 56 - 26)) { $tNm = $fSm }
                DT $g $t.T $tNm $cTxt 54 12
                if ($t.Tg) {
                    $tgW = (TW $g $t.Tg $fXs) + 12
                    $g.FillPath((New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(48, 242, 140, 40))), (RR (New-Object Drawing.Rectangle(54, 33, $tgW, 15)) 6))
                    DT $g $t.Tg $fXs $or 60 33
                }
                $tdFl = [Windows.Forms.TextFormatFlags]'WordBreak, NoPadding, NoPrefix, EndEllipsis'
                [Windows.Forms.TextRenderer]::DrawText($g, [string]$t.D, $fSm, (New-Object Drawing.Rectangle(12, 54, ($s.Width - 24), ($s.Height - 58))), $mu, $tdFl)
                if ($t.On) {
                    $tcx = $s.Width - 26
                    $g.FillEllipse((New-Object Drawing.SolidBrush($or)), $tcx, 9, 18, 18)
                    $cpn = New-Object Drawing.Pen($cWhite, 2)
                    $g.DrawLines($cpn, [Drawing.Point[]]@((New-Object Drawing.Point(($tcx + 4), 18)), (New-Object Drawing.Point(($tcx + 8), 22)), (New-Object Drawing.Point(($tcx + 14), 14))))
                }
            })
        Rnd $p 10; $d.pn = $p; $i++
    }
}

# Schaltflächen der Seitenleiste
function NewOBtn($text, $x, $y, $w, $h, $prim, $act) {
    $p = New-Object Windows.Forms.Panel; $p.SetBounds($x, $y, $w, $h); $p.BackColor = (SideBg $y); $p.Cursor = 'Hand'; DB $p
    $p.Tag = @{ T = $text; Hot = $false; Prim = $prim; On = $true }
    $p.Add_MouseEnter({ param($s, $e) $s.Tag.Hot = $true; $s.Invalidate() })
    $p.Add_MouseLeave({ param($s, $e) $s.Tag.Hot = $false; $s.Invalidate() })
    $p.Add_Paint({ param($s, $e)
            $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
            $t = $s.Tag; $r = New-Object Drawing.Rectangle(1, 1, ($s.Width - 3), ($s.Height - 3))
            $rc = New-Object Drawing.Rectangle(0, 0, $s.Width, $s.Height)
            if ($t.Prim) {
                $c1 = [Drawing.Color]::FromArgb(250, 156, 46); $c2 = [Drawing.Color]::FromArgb(230, 124, 14)
                if ($t.Hot) { $c1 = $orH }
                if (-not $t.On) { $c1 = [Drawing.Color]::FromArgb(120, 84, 40); $c2 = [Drawing.Color]::FromArgb(100, 70, 34) }
                $g.FillPath((New-Object Drawing.Drawing2D.LinearGradientBrush($r, $c1, $c2, 90)), (RR $r 9))
                DTC $g $t.T $fB $cWhite $rc
            } else {
                $c1 = $script:btnBg; if ($t.Hot) { $c1 = $or }
                $g.FillPath((New-Object Drawing.SolidBrush($c1)), (RR $r 7))
                $op = New-Object Drawing.Pen($or, 1.3)
                $g.DrawLine($op, 1, 7, 1, ($s.Height - 8)); $g.DrawLine($op, ($s.Width - 2), 7, ($s.Width - 2), ($s.Height - 8))
                $bt1 = $cTxt; if ($t.Hot) { $bt1 = $cWhite }
                DTC $g $t.T $fT $bt1 $rc
            }
        })
    Rnd $p 8; $p.Add_Click($act); $side.Controls.Add($p); $script:obtns += $p; $p
}
$btnStart = NewOBtn 'Diagnose starten' 22 (526 + $dh) 220 44 $true { if (-not $script:busy) { RunDiag } }
Rnd $btnStart 10
[void](NewOBtn 'Ordner öffnen' 22 (578 + $dh) 108 30 $false { OpenFolder })
[void](NewOBtn 'Bericht öffnen' 134 (578 + $dh) 108 30 $false { OpenReport })
[void](NewOBtn 'Kopieren' 22 (612 + $dh) 108 30 $false { CopyReport })
[void](NewOBtn 'Support-ZIP' 134 (612 + $dh) 108 30 $false { MakeZip })

# Karten
$hdr = New-Object Windows.Forms.Panel; $hdr.SetBounds(284, 56, 566, 64); $hdr.BackColor = $pn; DB $hdr
$hdr.Tag = @{ Val = 'Bereit'; Sub = 'Wähle die Kacheln aus und starte links die Diagnose.'; Col = $null; Ico = 0 }
$hdr.Add_Paint({ param($s, $e)
        $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
        $r = New-Object Drawing.Rectangle(0, 0, $s.Width, $s.Height)
        $lg = New-Object Drawing.Drawing2D.LinearGradientBrush($r, $script:hdrA, $script:hdrB, [single]0)
        $g.FillRectangle($lg, $r); $lg.Dispose()
        $g.FillRectangle((New-Object Drawing.SolidBrush($script:acc)), 0, 0, 6, $s.Height)
        $gl = New-Object Drawing.Drawing2D.LinearGradientBrush((New-Object Drawing.Rectangle(6, 0, 120, $s.Height)), [Drawing.Color]::FromArgb(50, $script:acc.R, $script:acc.G, $script:acc.B), [Drawing.Color]::FromArgb(0, $script:acc.R, $script:acc.G, $script:acc.B), [single]0)
        $g.FillRectangle($gl, 6, 0, 120, $s.Height); $gl.Dispose()
        $vcol = $s.Tag.Col; if (-not $vcol) { $vcol = $cTxt }
        $hdX = 24
        $hdImg = StatusImg ([int]$s.Tag.Ico)
        if ($hdImg) { $g.InterpolationMode = 'HighQualityBicubic'; $g.DrawImage($hdImg, 16, 4, 56, 56); $hdX = 84 }
        DT $g $s.Tag.Val $fH $vcol $hdX 8
        DT $g $s.Tag.Sub $fT $mu ($hdX + 2) 38
    })
Rnd $hdr 12; $form.Controls.Add($hdr)
function SetState($col, [string]$t, [string]$subT, $tcol) {
    $script:acc = $col; $hdr.Tag.Val = $t; $hdr.Tag.Sub = $subT; $hdr.Tag.Col = $tcol
    # Statusbild: 0 Bereit, 1 Läuft, 2 Alles in Ordnung, 3 Auffälligkeit
    if ($t -match '^(?i)Keine') { $hdr.Tag.Ico = 2 } elseif ($t -match '(?i)Auffälligkeit') { $hdr.Tag.Ico = 3 } elseif ($t -match '(?i)^Bereit') { $hdr.Tag.Ico = 0 } else { $hdr.Tag.Ico = 1 }
    $hdr.Invalidate()
}

$cardPaint = { param($s, $e)
    $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
    $r = New-Object Drawing.Rectangle(0, 0, $s.Width, $s.Height)
    $lg = New-Object Drawing.Drawing2D.LinearGradientBrush($r, $script:cardA, $script:cardB, [single]90)
    $g.FillRectangle($lg, $r); $lg.Dispose()
    $tl = New-Object Drawing.Drawing2D.LinearGradientBrush((New-Object Drawing.Rectangle(0, 0, $s.Width, 3)), [Drawing.Color]::FromArgb(230, 242, 140, 40), [Drawing.Color]::FromArgb(0, 242, 140, 40), [single]0)
    $g.FillRectangle($tl, 0, 0, $s.Width, 3); $tl.Dispose()
    DT $g $s.Tag.Cap $fSB $mu 16 8
    if ($s.Tag.K -eq 'stat') { $vcol = $s.Tag.Col; if (-not $vcol) { $vcol = $cTxt }; DT $g $s.Tag.Val $fX $vcol 15 24 }
}
function MkCard($x, $cap) {
    $p = New-Object Windows.Forms.Panel; $p.SetBounds($x, 130, 252, 62); $p.BackColor = $pn; DB $p
    $p.Tag = @{ K = 'stat'; Cap = $cap; Val = $dash; Col = $null }
    $p.Add_Paint($cardPaint); Rnd $p 12; $form.Controls.Add($p); $p
}
function SetCard($c, $val, $col) { $c.Tag.Val = $val; $c.Tag.Col = $col; $c.Invalidate() }
$cD = MkCard 284 'DIAGNOSEN'; $cA = MkCard 544 'AUFFÄLLIGKEITEN'; $cT = MkCard 804 'DAUER'
$tkp = New-Object Windows.Forms.Panel; $tkp.SetBounds(866, 56, 214, 64); $tkp.BackColor = $pn; DB $tkp
$tkp.Tag = @{ K = 'cust'; Cap = 'KUNDE / TICKET' }; $tkp.Add_Paint($cardPaint); Rnd $tkp 12; $form.Controls.Add($tkp)
$tkw = New-Object Windows.Forms.Panel; $tkw.SetBounds(12, 30, 190, 26); $tkw.BackColor = $cOffBg; Rnd $tkw 6; $tkp.Controls.Add($tkw)
$tkb = New-Object Windows.Forms.TextBox; $tkb.SetBounds(8, 4, 174, 20); $tkb.BorderStyle = 'None'; $tkb.BackColor = $cOffBg
$tkb.ForeColor = $cTxt; $tkb.Font = $fT; $tkw.Controls.Add($tkb)

function NewMainLabel($t, $x, $y, $col, $font) {
    $l = New-Object Windows.Forms.Label; $l.Text = $t; $l.AutoSize = $true; $l.Location = New-Object Drawing.Point($x, $y)
    $l.BackColor = $bg; $l.ForeColor = $col; $l.Font = $font
    if ($col -eq $or) { $l.Tag = 'or' } else { $l.Tag = 'mu' }
    $form.Controls.Add($l); $script:lbls += $l; $l
}
[void](NewMainLabel 'AUFFÄLLIGKEITEN' 284 204 $or $fSB)
# Auffälligkeiten-Liste (Text in Standard-Schriftfarbe; Schweregrad im Präfix ! bzw. !!; lange Zeilen werden gekürzt, keine Bildlaufleiste)
$lb = New-Object Windows.Forms.ListBox; $lb.SetBounds(284, 224, 796, 100); $lb.BackColor = $pn; $lb.ForeColor = $tx; $lb.BorderStyle = 'None'
$lb.DrawMode = 'OwnerDrawFixed'; $lb.ItemHeight = 20; $lb.HorizontalScrollbar = $false; $lb.Font = $fN
$lb.Add_DrawItem({ param($s, $e)
        if ($e.Index -lt 0) { return }
        $it = $s.Items[$e.Index]
        $e.Graphics.FillRectangle((New-Object Drawing.SolidBrush($pn)), $e.Bounds)
        $lbTxt = [string]$it.T; $lbX = $e.Bounds.X + 4
        $lbK = 0; if ($lbTxt -match '^!! ') { $lbK = 2 } elseif ($lbTxt -match '^! ') { $lbK = 1 }
        $lbImg = SevImg $lbK
        if ($lbImg -and $lbK -gt 0) {
            $e.Graphics.InterpolationMode = 'HighQualityBicubic'
            $e.Graphics.DrawImage($lbImg, ($e.Bounds.X + 4), ($e.Bounds.Y + 2), 16, 16)
            $lbTxt = $lbTxt -replace '^!{1,2} ', ''; $lbX = $e.Bounds.X + 26
        }
        [Windows.Forms.TextRenderer]::DrawText($e.Graphics, $lbTxt, $fN, (New-Object Drawing.Point($lbX, ($e.Bounds.Y + 2))), $cTxt, $tf)
    })
$form.Controls.Add($lb)

# Fortschrittsleiste
$pgBg = New-Object Windows.Forms.Panel; $pgBg.SetBounds(284, 336, 796, 8); $pgBg.BackColor = $pn; DB $pgBg
$pgBg.Add_Paint({ param($s, $e)
        $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
        $w = [int]($s.Width * $script:cur)
        if ($w -gt 2) {
            $r = New-Object Drawing.Rectangle(0, 0, $w, $s.Height)
            $lg = New-Object Drawing.Drawing2D.LinearGradientBrush($r, $or, $orH, [single]0); $g.FillRectangle($lg, $r); $lg.Dispose()
            if ($script:run) {
                $x = [int](($script:ph * 35) % ($w + 140)) - 140
                $sr = New-Object Drawing.Rectangle($x, 0, 140, $s.Height)
                $sbr = New-Object Drawing.Drawing2D.LinearGradientBrush($sr, [Drawing.Color]::Transparent, [Drawing.Color]::White, [single]0)
                $cbd = New-Object Drawing.Drawing2D.ColorBlend(3)
                $cbd.Colors = [Drawing.Color[]]@([Drawing.Color]::FromArgb(0, 255, 255, 255), [Drawing.Color]::FromArgb(110, 255, 255, 255), [Drawing.Color]::FromArgb(0, 255, 255, 255))
                $cbd.Positions = [single[]]@(0, 0.5, 1); $sbr.InterpolationColors = $cbd
                $g.SetClip($r); $g.FillRectangle($sbr, $sr); $g.ResetClip(); $sbr.Dispose()
            }
        }
    })
Rnd $pgBg 4; $form.Controls.Add($pgBg)
function SetProg([double]$f) { $script:prog = $f; if ($f -le 0) { $script:cur = 0.0 }; $pgBg.Invalidate(); [Windows.Forms.Application]::DoEvents() }

# Status-Chip und Meldung
$stT = New-Object Windows.Forms.Panel; $stT.SetBounds(284, 349, 96, 20); $stT.BackColor = $cOffBg; DB $stT
$stT.Add_Paint({ param($s, $e)
        $g = $e.Graphics
        DTC $g ([string][char]0x25CF + ' ' + $script:tagTxt) $fSB $script:tagCol (New-Object Drawing.Rectangle(0, 0, $s.Width, $s.Height))
    })
Rnd $stT 8; $form.Controls.Add($stT)
function SetTag([string]$t, $col) { $script:tagTxt = $t; $script:tagCol = $col; $stT.Invalidate() }
$st = New-Object Windows.Forms.Label; $st.SetBounds(392, 349, 548, 20); $st.AutoSize = $false; $st.AutoEllipsis = $true; $st.TextAlign = 'MiddleLeft'
$st.ForeColor = $mu; $st.Font = $fT; $st.BackColor = $bg; $form.Controls.Add($st)
# Knopf zum vorzeitigen Beenden eines Paketmitschnitts (nur während der Aufnahme sichtbar)
$script:ncStop = $false; $script:ncLen = 0
$btnStop = New-Object Windows.Forms.Button; $btnStop.Text = 'Mitschnitt stoppen'; $btnStop.SetBounds(948, 345, 132, 28)
$btnStop.FlatStyle = 'Flat'; $btnStop.FlatAppearance.BorderSize = 0; $btnStop.BackColor = $rd; $btnStop.ForeColor = $cWhite
$btnStop.FlatAppearance.MouseOverBackColor = $rd; $btnStop.FlatAppearance.MouseDownBackColor = $rd
$btnStop.Font = $fB; $btnStop.Cursor = 'Hand'; $btnStop.Visible = $false; Rnd $btnStop 8
$btnStop.Add_Click({ $script:ncStop = $true; $btnStop.Enabled = $false; $btnStop.Text = 'Wird gestoppt ...' })
$form.Controls.Add($btnStop)
function Msg([string]$t, $col) { $st.Text = $t; $script:msgAm = [bool]$col; if ($col) { $st.ForeColor = $col } else { $st.ForeColor = $mu } }
if ($isAdmin) { Msg 'Administratorrechte vorhanden - alle Prüfungen und Reparaturen verfügbar.' $null }
else { Msg 'Hinweis: Ohne Administratorrechte keine Reparatur und eingeschränkte Prüfungen.' $am }

$box = New-Object Windows.Forms.RichTextBox; $box.SetBounds(284, 402, 796, (320 + $dh)); $box.BackColor = $sb; $box.ForeColor = $tx
$box.BorderStyle = 'None'; $box.ReadOnly = $true; $box.WordWrap = $true; $box.Font = $fM; $box.DetectUrls = $false; $form.Controls.Add($box)
# Leerzustand (A6): liegt über dem Protokollfeld, solange noch nichts ausgegeben wurde
$script:siEmpty = $null; $script:siEmptyTried = $false
$emptyP = New-Object Windows.Forms.Panel; $emptyP.SetBounds(284, 402, 796, (320 + $dh)); $emptyP.BackColor = $sb; DB $emptyP
$emptyP.Add_Paint({ param($s, $e)
        $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'; $g.InterpolationMode = 'HighQualityBicubic'
        $g.Clear($sb)
        if (-not $script:siEmptyTried) {
            $script:siEmptyTried = $true
            $emP = AssetPath 'A6'
            if ($emP -and $script:imgOk) { try { $script:siEmpty = [Sip.Img]::Cell($emP, 1, 1, 0, 300, $true) } catch {} }
        }
        $emY = [int](($s.Height - 360) / 2); if ($emY -lt 8) { $emY = 8 }
        if ($script:siEmpty) { $g.DrawImage($script:siEmpty, [int](($s.Width - 300) / 2), $emY, 300, 300); $emY += 306 } else { $emY += 120 }
        DTC $g 'Noch keine Diagnose gestartet' $fH $cTxt (New-Object Drawing.Rectangle(0, $emY, $s.Width, 30))
        DTC $g 'Wähle im Reiter AUSWAHL die Kacheln und klicke links auf "Diagnose starten".' $fN $mu (New-Object Drawing.Rectangle(0, ($emY + 32), $s.Width, 22))
    })
$form.Controls.Add($emptyP); $emptyP.BringToFront()

# ---------- Auswahlbereich (1.9.0): Kachelraster, Modus-Umschalter und Profile; liegt über dem Protokollfeld ----------
$script:profiles = @(
    @{ Key = 'p_outlook'; Text = 'Outlook-Problem'; K = @('m365', 'office', 'netzwerk', 'zeit') },
    @{ Key = 'p_inet'; Text = 'Internet langsam'; K = @('netzwerk', 'wlan', 'proxy', 'web', 'nettools') },
    @{ Key = 'p_pc'; Text = 'PC langsam'; K = @('system', 'hardware', 'updates', 'eventlogs') },
    @{ Key = 'p_anm'; Text = 'Anmeldung'; K = @('m365', 'office', 'ablauf', 'zeit') },
    @{ Key = 'p_druck'; Text = 'Drucker'; K = @('drucker') }
)
$script:gpTitle = 'Schnellstart'; $script:gpSub = ''; $script:gpHits = @(); $script:gpHot = $null; $script:vbHits = @()
$gridP = New-Object Windows.Forms.Panel; $gridP.SetBounds(284, 402, 796, (320 + $dh)); $gridP.BackColor = $sb; DB $gridP
foreach ($gpD in $diag) { $gridP.Controls.Add($gpD.pn) }
$form.Controls.Add($gridP)
$viewBar = New-Object Windows.Forms.Panel; $viewBar.SetBounds(284, 372, 796, 28); $viewBar.BackColor = $sb; $viewBar.Cursor = 'Hand'; DB $viewBar
$form.Controls.Add($viewBar)

# Sichtbar ist eine Kachel, wenn Modus (Alle/Prüfen/Reparieren) und Kategorie passen; der Schnellstart zeigt Favoriten und alles bereits Gewählte
function TileVisible($tvD) {
    $tvT = $tvD.pn.Tag
    $tvRep = [bool]($tvD.r -or $tvD.x)
    if ($script:mode -eq 'pruefen' -and $tvRep) { return $false }
    if ($script:mode -eq 'reparieren' -and -not $tvRep) { return $false }
    if ($script:gsq) { return [bool]((([string]$tvT.T + ' ' + [string]$tvT.D + ' ' + [string]$tvT.Cat + ' ' + [string]$tvD.k).ToLower()).Contains($script:gsq)) }
    if ($script:cat -eq 'Schnellstart') { return [bool]($tvT.Fav -or $tvT.On) }
    return ($tvT.Cat -eq $script:cat)
}
# Ordnet die sichtbaren Kacheln im Raster an (4 Spalten, Höhe passt sich der Zeilenzahl an)
function LayoutTiles {
    $ltW = $gridP.Width; $ltH = $gridP.Height
    $ltVis = @($diag | Where-Object { TileVisible $_ })
    # Doppelt breite Kacheln zuerst, damit in den Reihen keine Lücken entstehen
    $ltVis = @(@($ltVis | Where-Object { $_.pn.Tag.W }) + @($ltVis | Where-Object { -not $_.pn.Tag.W }))
    $ltCols = 4; $ltGap = 10; $ltTop = 76
    $ltTw = [int](($ltW - ($ltCols - 1) * $ltGap) / $ltCols)
    $ltRows = 1; $ltCol0 = 0
    foreach ($ltD in $ltVis) { $ltU0 = 1; if ($ltD.pn.Tag.W) { $ltU0 = 2 }; if (($ltCol0 + $ltU0) -gt $ltCols) { $ltRows++; $ltCol0 = 0 }; $ltCol0 += $ltU0 }
    $ltAvail = $ltH - $ltTop - 26
    $ltTh = [int][math]::Min(88.0, [double][math]::Floor(($ltAvail - ($ltRows - 1) * $ltGap) / $ltRows))
    if ($ltTh -lt 60) { $ltTh = 60 }
    $gridP.SuspendLayout()
    foreach ($ltD in $diag) { $ltD.pn.Visible = $false }
    $ltOn = 0; $ltRow = 0; $ltCol = 0
    foreach ($ltD in $ltVis) {
        $ltP = $ltD.pn
        $ltU = 1; if ($ltP.Tag.W) { $ltU = 2 }
        if (($ltCol + $ltU) -gt $ltCols) { $ltRow++; $ltCol = 0 }
        $ltP.SetBounds(($ltCol * ($ltTw + $ltGap)), ($ltTop + $ltRow * ($ltTh + $ltGap)), ($ltU * $ltTw + ($ltU - 1) * $ltGap), $ltTh)
        Rnd $ltP 10; $ltP.Visible = $true
        if ($ltP.Tag.On) { $ltOn++ }
        $ltCol += $ltU
    }
    $gridP.ResumeLayout()
    if ($script:gsq) { $script:gpTitle = 'Suche' } else { $script:gpTitle = $script:cat }
    $script:gpSub = "$($ltVis.Count) Kacheln, davon $ltOn gewählt"
    $gridP.Invalidate(); $viewBar.Invalidate(); $side.Invalidate()
}
function SetView([string]$svV) {
    $script:view = $svV
    if ($svV -eq 'sel') { $box.Visible = $false; $emptyP.Visible = $false; $gridP.Visible = $true; $gridP.BringToFront() }
    else { $gridP.Visible = $false; $box.Visible = $true; $emptyP.Visible = ($box.TextLength -eq 0); if ($emptyP.Visible) { $emptyP.BringToFront() } }
    $viewBar.Invalidate()
}
function SetCat([string]$scC) {
    if ($gsb) { ClearSearch }
    $script:cat = $scC
    if ($script:view -ne 'sel') { SetView 'sel' }
    LayoutTiles
}
# Profil: wählt typische Prüfungen für ein Fehlerbild vor (nur Prüfungen, keine Reparaturen)
function ApplyProfile([string]$apKey) {
    $apP = @($script:profiles | Where-Object { $_.Key -eq $apKey })[0]
    if (-not $apP) { return }
    foreach ($apD in $diag) { $apD.pn.Tag.On = [bool](@($apP.K) -contains ([string]$apD.k).ToLower()); $apD.pn.Invalidate() }
    $script:cat = 'Schnellstart'; $script:mode = 'alle'
    if ($gsb) { ClearSearch }
    if ($script:view -ne 'sel') { SetView 'sel' }
    LayoutTiles
    $apN = @($diag | Where-Object { $_.pn.Tag.On }).Count
    Msg "Profil gewählt: $($apP.Text) ($apN Kacheln). Mit Diagnose starten ausführen." $null
}
$gridP.Add_Paint({ param($s, $e)
        $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
        $script:gpHits = @()
        DT $g $script:gpTitle $fH $cTxt 2 0
        $gpTw = TW $g $script:gpTitle $fH
        DT $g $script:gpSub $fS $mu (12 + $gpTw) 9
        # Umschalter Alle | Prüfen | Reparieren
        $gpX = $s.Width - 212 - 2
        $g.FillPath((New-Object Drawing.SolidBrush($cOffBg)), (RR (New-Object Drawing.Rectangle($gpX, 3, 212, 26)) 9))
        foreach ($gpM in @(@('m_alle', 'Alle', 56), @('m_pruefen', 'Prüfen', 66), @('m_reparieren', 'Reparieren', 90))) {
            $gpR = New-Object Drawing.Rectangle($gpX, 3, $gpM[2], 26)
            $gpAct = ("m_$($script:mode)" -eq $gpM[0])
            $gpCol = $mu; if ($script:gpHot -eq $gpM[0]) { $gpCol = $cTxt }
            if ($gpAct) { $g.FillPath((New-Object Drawing.SolidBrush($or)), (RR (New-Object Drawing.Rectangle(($gpX + 2), 5, ($gpM[2] - 4), 22)) 8)); $gpCol = $cWhite }
            DTC $g $gpM[1] $fSB $gpCol $gpR
            $script:gpHits += @{ Key = $gpM[0]; R = $gpR }
            $gpX += $gpM[2]
        }
        # Profile
        DT $g 'Profile:' $fS $mu 2 47
        $gpX = 62
        foreach ($gpPr in $script:profiles) {
            $gpW = (TW $g $gpPr.Text $fS) + 26
            $gpR = New-Object Drawing.Rectangle($gpX, 40, $gpW, 26)
            $g.FillPath((New-Object Drawing.SolidBrush($cOffBg)), (RR $gpR 12))
            if ($script:gpHot -eq $gpPr.Key) { $gpPen = New-Object Drawing.Pen($or, 1.3) } else { $gpPen = New-Object Drawing.Pen($script:tileBd) }
            $g.DrawPath($gpPen, (RR $gpR 12))
            DTC $g $gpPr.Text $fS $cTxt $gpR
            $script:gpHits += @{ Key = $gpPr.Key; R = $gpR }
            $gpX += $gpW + 8
        }
        if ($script:mode -ne 'pruefen') { DT $g 'Reparaturen verändern das System und brauchen meist Administratorrechte. Sicherungen enthalten vertrauliche Daten.' $fSm $mu 2 ($s.Height - 20) }
    })
# Suchfeld (Karte oben rechts, anstelle von Kunde / Ticket): filtert alle Kategorien nach Name, Beschreibung und Schlüssel; leeres Feld zeigt wieder die gewählte Kategorie
$script:gsq = ''; $script:gsHint = $true; $script:gsSet = $false
$gsc = New-Object Windows.Forms.Panel; $gsc.SetBounds(866, 56, 214, 64); $gsc.BackColor = $pn; DB $gsc
$gsc.Tag = @{ K = 'cust'; Cap = 'SUCHE' }; $gsc.Add_Paint($cardPaint); Rnd $gsc 12; $form.Controls.Add($gsc)
# Die Karte Kunde / Ticket ist ausgeblendet (die Eingabe erfolgt beim Programmstart und steht in der Titelleiste); das Feld $tkb bleibt für Berichte erhalten
$tkp.Visible = $false
$gsw = New-Object Windows.Forms.Panel; $gsw.SetBounds(12, 30, 190, 26); $gsw.BackColor = $cOffBg; DB $gsw
$gsb = New-Object Windows.Forms.TextBox; $gsb.SetBounds(30, 5, 154, 18); $gsb.BorderStyle = 'None'; $gsb.BackColor = $cOffBg
$gsb.ForeColor = $mu; $gsb.Font = $fT; $gsb.Text = 'Suchen ...'
$gsw.Controls.Add($gsb); $gsc.Controls.Add($gsw); Rnd $gsw 10
$gsw.Add_Paint({ param($s, $e) DT $e.Graphics ([string][char]0xE721) $fG $mu 9 5 })
$gsw.Add_Click({ $gsb.Focus() })
function ClearSearch {
    $script:gsSet = $true; $gsb.Text = 'Suchen ...'; $gsb.ForeColor = $mu; $script:gsq = ''; $script:gsHint = $true; $script:gsSet = $false
}
$gsb.Add_GotFocus({ if ($script:gsHint) { $script:gsSet = $true; $gsb.Text = ''; $gsb.ForeColor = $cTxt; $script:gsHint = $false; $script:gsSet = $false } })
$gsb.Add_LostFocus({ if ($gsb.Text.Trim() -eq '') { ClearSearch; LayoutTiles } })
$gsb.Add_TextChanged({ if (-not $script:gsSet) { $script:gsq = $gsb.Text.Trim().ToLower(); if ($script:gsq -and $script:view -ne 'sel') { SetView 'sel' }; LayoutTiles } })
$gridP.Add_MouseMove({ param($s, $e)
        $gpK = $null
        foreach ($gpH in @($script:gpHits)) { if ($gpH.R.Contains($e.Location)) { $gpK = $gpH.Key; break } }
        if ($gpK -ne $script:gpHot) {
            $script:gpHot = $gpK
            if ($gpK) { $s.Cursor = [Windows.Forms.Cursors]::Hand } else { $s.Cursor = [Windows.Forms.Cursors]::Default }
            $s.Invalidate()
        }
    })
$gridP.Add_MouseLeave({ param($s, $e) if ($script:gpHot) { $script:gpHot = $null; $s.Invalidate() } })
$gridP.Add_MouseDown({ param($s, $e)
        foreach ($gpH in @($script:gpHits)) {
            if ($gpH.R.Contains($e.Location)) {
                if ($gpH.Key -like 'm_*') { $script:mode = $gpH.Key.Substring(2); LayoutTiles }
                elseif ($gpH.Key -like 'p_*') { ApplyProfile $gpH.Key }
                break
            }
        }
    })
$viewBar.Add_Paint({ param($s, $e)
        $g = $e.Graphics
        $script:vbHits = @()
        $vbX = 4
        foreach ($vbT in @(@('sel', 'AUSWAHL'), @('log', 'PROTOKOLL'))) {
            $vbW = TW $g $vbT[1] $fSB
            $vbAct = ($script:view -eq $vbT[0]); $vbCol = $mu; if ($vbAct) { $vbCol = $cTxt }
            DT $g $vbT[1] $fSB $vbCol $vbX 5
            if ($vbAct) { $g.FillRectangle((New-Object Drawing.SolidBrush($or)), $vbX, 24, $vbW, 2) }
            $script:vbHits += @{ Key = $vbT[0]; R = (New-Object Drawing.Rectangle(($vbX - 4), 0, ($vbW + 8), 28)) }
            $vbX += $vbW + 28
        }
        $vbN = @($diag | Where-Object { $_.pn.Tag.On }).Count
        $vbTxt = 'Nichts gewählt'; if ($vbN -gt 0) { $vbTxt = "$vbN gewählt" }
        DT $g $vbTxt $fS $or ($s.Width - 6 - (TW $g $vbTxt $fS)) 6
    })
$viewBar.Add_MouseDown({ param($s, $e)
        foreach ($vbH in @($script:vbHits)) { if ($vbH.R.Contains($e.Location)) { SetView $vbH.Key; break } }
    })
LayoutTiles
SetView 'sel'
$script:verLbl = NewMainLabel "$cpy  |  Tel. $telefon  |  $mail  |  $appName $appVer - Reparatur nur nach Bestätigung" 284 (744 + $dh) $mu $fS
# Protokoll: Farben werden als Schlüssel gespeichert, damit sie beim Designwechsel neu gezeichnet werden können
function ColOf($k) {
    switch ($k) { 'mu' { $mu } 'or' { $or } 'am' { $am } 'rd' { $rd } 'gr' { $gr } default { $tx } }
}
function DrawLog([string]$x, $k, $b) {
    if ($emptyP.Visible) { $emptyP.Visible = $false }
    $box.SelectionStart = $box.TextLength; $box.SelectionLength = 0; $box.SelectionColor = (ColOf $k)
    if ($b) { $box.SelectionFont = $fMB } else { $box.SelectionFont = $fM }
    $box.AppendText($x + "`n"); $box.SelectionStart = $box.TextLength; $box.ScrollToCaret()
}
function Say([string]$x, $k, $b) { [void]$script:logBuf.Add([pscustomobject]@{ X = $x; K = $k; B = $b }); DrawLog $x $k $b }
function Rerender { $box.Clear(); foreach ($lg1 in @($script:logBuf)) { DrawLog $lg1.X $lg1.K $lg1.B } }

# Designwechsel auf alle vorhandenen Steuerelemente anwenden
function RefreshTheme {
    $form.BackColor = $bg; $form.ForeColor = $tx; $tbar.BackColor = $tb
    foreach ($tl1 in @($tbar.Controls)) {
        $tl1.BackColor = $tb; $tl1.ForeColor = $tx
        if ($tl1.Name -eq 'close') { $tl1.Tag = $rd } else { $tl1.Tag = $cOffHv }
    }
    if ($script:light) { $tgl.Text = [string][char]0xE708 } else { $tgl.Text = [string][char]0xE706 }
    $side.BackColor = $sb
    foreach ($d1 in $diag) { $d1.pn.BackColor = $sb; $d1.pn.Invalidate() }
    $gridP.BackColor = $sb; $gridP.Invalidate(); $viewBar.BackColor = $sb; $viewBar.Invalidate()
    foreach ($ob1 in $script:obtns) { $ob1.BackColor = (SideBg $ob1.Top); $ob1.Invalidate() }
    foreach ($lk1 in $script:links) { if ($lk1.Key -eq 'all' -or $lk1.Key -eq 'none' -or $lk1.Key -eq 'mail' -or $lk1.Key -like 'tab_*') { $lk1.Col = $mu } }
    $hdr.BackColor = $pn; $hdr.Invalidate()
    foreach ($cc1 in @($cD, $cA, $cT, $tkp, $gsc)) { $cc1.BackColor = $pn; $cc1.Invalidate() }
    $tkw.BackColor = $cOffBg; $tkb.BackColor = $cOffBg; $tkb.ForeColor = $cTxt
    $gsw.BackColor = $cOffBg; $gsb.BackColor = $cOffBg; if ($script:gsHint) { $gsb.ForeColor = $mu } else { $gsb.ForeColor = $cTxt }; $gsw.Invalidate()
    $lb.BackColor = $pn; $lb.ForeColor = $tx; $lb.Invalidate()
    $pgBg.BackColor = $pn; $pgBg.Invalidate()
    $stT.BackColor = $cOffBg; $stT.Invalidate()
    $st.BackColor = $bg; if ($script:msgAm) { $st.ForeColor = $am } else { $st.ForeColor = $mu }
    foreach ($lbl1 in $script:lbls) { $lbl1.BackColor = $bg; if ($lbl1.Tag -eq 'or') { $lbl1.ForeColor = $or } else { $lbl1.ForeColor = $mu } }
    $box.BackColor = $sb; $box.ForeColor = $tx; Rerender
    $form.Invalidate($true); $side.Invalidate(); $tbar.Invalidate()
}

# Animations-Timer
$tm = New-Object Windows.Forms.Timer; $tm.Interval = 30
$tm.Add_Tick({
        $script:ph += 0.18
        if ($script:run) { $t = (([math]::Sin($script:ph) + 1) / 2); $script:acc = [Drawing.Color]::FromArgb(255, [int](242 + 13 * $t), [int](140 + 25 * $t), [int](40 + 34 * $t)); $hdr.Invalidate() }
        $d2 = $script:prog - $script:cur
        if ([math]::Abs($d2) -gt 0.001) { $script:cur += $d2 * 0.2; $pgBg.Invalidate() } elseif ($script:run) { $pgBg.Invalidate() }
    })
$tm.Start()
$form.Add_FormClosed({ $tm.Stop(); $fade.Stop() })

# ---------- Ablauf ----------
# ACHTUNG Namenskollision: PowerShell unterscheidet Variablen nicht nach Groß-/Kleinschreibung.
# In RunDiag daher KEINE lokalen Variablen verwenden, die wie Skriptvariablen heißen ($fT, $fN, $tx, $or, $am, $rd ...).
# SevColor liefert $null bei "kein Befund" (Standard-Schriftfarbe des Designs), SevKey den Farbschlüssel fürs Protokoll.
function SevColor($sv) { if ($sv -eq 2) { $rd } elseif ($sv -eq 1) { $am } else { $null } }
function SevKey($sv) { if ($sv -eq 2) { 'rd' } else { 'am' } }
# Verarbeitet eine Ausgabezeile einer Prüfung: Auffälligkeit (Präfix [!!], [!], [~]) oder normale Zeile, sofort im Protokoll anzeigen
$script:curVis = $null; $script:curSec = ''
function ProcLine([string]$plLine) {
    if ($plLine -match '^\[(!!|!|~)\]\s*(.*)$') {
        $mk1 = $Matches[1]; $rest1 = $Matches[2]
        $parts1 = $rest1 -split '\|\|', 2
        $finTxt = $parts1[0].Trim(); $finRec = ''; if ($parts1.Count -gt 1) { $finRec = $parts1[1].Trim() }
        $sev1 = 1; $lvl1 = 'MITTEL'; $pre1 = '! '
        if ($mk1 -eq '!!') { $sev1 = 2; $lvl1 = 'HOCH'; $pre1 = '!! ' } elseif ($mk1 -eq '~') { $lvl1 = 'NIEDRIG' }
        $script:lastNf++; if ($sev1 -gt $script:sevMax) { $script:sevMax = $sev1 }
        Say "$pre1$finTxt" (SevKey $sev1) $true
        [void]$lb.Items.Add([pscustomobject]@{ T = (Cut "$pre1$($script:curSec): $finTxt" 120); S = $sev1 })
        $script:finds += [pscustomobject]@{ Sec = $script:curSec; T = $finTxt; R = $finRec; L = $lvl1; S = $sev1 }
        [void]$script:curVis.Add("$pre1$finTxt")
        return
    }
    [void]$script:curVis.Add($plLine)
    # Protokollfarben: OK = grün, Probleme = rot, Hinweis = orange, sonst Standard
    if ($plLine -match '^\s*Hinweis:') { Say $plLine 'am' $false }
    elseif ($plLine -cmatch 'KEINE ANTWORT|NICHT ERREICHBAR|FEHLER|REAGIERT NICHT') { Say $plLine 'rd' $false }
    elseif ($plLine -cmatch '\bOK\b') { Say $plLine 'gr' $false }
    else { Say $plLine 'tx' $false }
    [Windows.Forms.Application]::DoEvents()
}
function RunDiag {
    $sel = @($diag | Where-Object { $_.pn.Tag.On })
    if ($sel.Count -eq 0) { [void](SipBox 'Bitte wählen Sie mindestens eine Diagnose oder ein Werkzeug aus.' 'Keine Auswahl'); return }
    # Reparatur-Werkzeuge verändern das System: vorher ausdrücklich bestätigen lassen
    $rep1 = @($sel | Where-Object { $_.r })
    if ($rep1.Count) {
        $txt2 = "Es sind Reparatur-Werkzeuge ausgewählt. Diese VERÄNDERN das System (anders als die Diagnosen):`r`n`r`n" + (($rep1 | ForEach-Object { '- ' + $_.t }) -join "`r`n") + "`r`n`r`nSie benötigen teils Administratorrechte und können mehrere Minuten dauern. Jetzt ausführen?"
        if (-not (SipBox $txt2 'Reparatur bestätigen' $true)) {
            $sel = @($sel | Where-Object { -not $_.r })
            if ($sel.Count -eq 0) { Msg 'Reparatur abgebrochen.' $null; return }
        }
    }
    SetView 'log'
    $script:busy = $true; $script:run = $true; $btnStart.Tag.On = $false; $btnStart.Invalidate()
    $box.Clear(); $script:logBuf.Clear(); $lb.Items.Clear(); $script:sections = @(); $script:lastNf = 0; $script:sevMax = 0; $script:finds = @(); $script:rpRun = $false
    $script:checked = @($sel | ForEach-Object { $_.t })
    $script:hdrLine = "Sippicom IT-Solutions  -  $appName  |  $env:COMPUTERNAME  |  $(Get-Date -Format 'dd.MM.yyyy HH:mm')"
    Say $script:hdrLine 'tx' $false
    $sw = [Diagnostics.Stopwatch]::StartNew()
    SetTag 'LÄUFT' $or; SetProg 0
    SetState $or 'Läuft' 'Diagnose wird ausgeführt ...' $null
    SetCard $cD "0 / $($sel.Count)" $null; SetCard $cA '0' $null; SetCard $cT '0 s' $null
    $n = 0
    foreach ($dg1 in $sel) {
        $n++; Msg "Prüfe $($dg1.t) ($n von $($sel.Count)) ..." $null; SetProg (($n - 1) / $sel.Count)
        SetState $or 'Läuft' "Prüfe $($dg1.t) ($n von $($sel.Count)) ..." $null
        # Überschrift sofort anzeigen, damit man im Protokoll sieht, welcher Abschnitt gerade läuft
        Say '' 'tx' $false; Say $dg1.t.ToUpper() 'or' $true; Say ('-' * 70) 'mu' $false
        if ($dg1.r -or $dg1.x) { Say "Gestartet um $(Get-Date -Format 'HH:mm:ss') - bitte warten, das kann einige Minuten dauern." 'or' $false }
        [Windows.Forms.Application]::DoEvents()
        # Zeilen werden sofort beim Entstehen ausgegeben (Streaming), damit eine Live-Zeile langer Werkzeuge immer ganz unten steht
        $script:curVis = New-Object Collections.ArrayList; $script:curSec = $dg1.t
        try { & $dg1.f | ForEach-Object { ProcLine "$_" } } catch { ProcLine "[!] Prüfung fehlgeschlagen: $($_.Exception.Message)||Prüfung erneut ausführen; bei Wiederholung die Meldung an den Support schicken." }
        $script:sections += [pscustomobject]@{ T = $dg1.t.ToUpper(); L = @($script:curVis) }
        SetCard $cD "$n / $($sel.Count)" $null; SetCard $cA "$($script:lastNf)" (SevColor $script:sevMax)
        SetCard $cT (Dur $sw.Elapsed) $null
        [Windows.Forms.Application]::DoEvents()
    }
    $ns1 = @($diag | Where-Object { -not $_.pn.Tag.On -and -not $_.r -and -not $_.x -and -not $_.n } | ForEach-Object { $_.pn.Tag.T })
    # Die Zeile "Nicht ausgewählt" nur zeigen, wenn überhaupt Diagnosen liefen (bei reinen Reparaturen oder Sicherungen wäre sie irreführend)
    $script:notSel = ''; if ($ns1.Count -and @($sel | Where-Object { -not $_.r -and -not $_.x }).Count) { $script:notSel = 'Nicht ausgewählt (fehlt im Bericht): ' + ($ns1 -join ', '); Say '' 'tx' $false; Say $script:notSel 'mu' $false }
    # Vergleich mit dem letzten gespeicherten Lauf dieses PCs (neue und behobene Auffälligkeiten, Platz, Updates)
    Msg 'Vergleiche mit dem letzten Lauf ...' $null; [Windows.Forms.Application]::DoEvents()
    $hcL = @(); try { $hcL = @(HistCompare) } catch {}
    if ($hcL.Count) {
        Say '' 'tx' $false; Say 'VERGLEICH MIT DEM LETZTEN LAUF' 'or' $true; Say ('-' * 70) 'mu' $false
        foreach ($hcX in $hcL) { Say $hcX 'tx' $false }
        $script:sections += [pscustomobject]@{ T = 'VERGLEICH MIT DEM LETZTEN LAUF'; L = $hcL }
    }
    SetProg 1; SaveReport
    try { HistSave } catch {}
    Say '' 'tx' $false
    Say "Bericht gespeichert: $script:lastTxt" 'or' $false
    Say "HTML-Bericht gespeichert: $script:lastHtml" 'or' $false
    $accC = SevColor $script:sevMax
    if ($script:lastNf -eq 0) {
        [void]$lb.Items.Add([pscustomobject]@{ T = 'Keine Auffälligkeiten festgestellt.'; S = 0 })
        SetState $gr 'Keine Auffälligkeiten' 'Alle ausgewählten Prüfungen ohne Befund.' $gr
    } else {
        $ttl1 = "$($script:lastNf) Auffälligkeiten gefunden"; if ($script:lastNf -eq 1) { $ttl1 = '1 Auffälligkeit gefunden' }
        SetState $accC $ttl1 'Details in der Liste und im Protokoll unten.' $accC
    }
    SetCard $cD "$($sel.Count)" $null; SetCard $cA "$($script:lastNf)" $accC; SetCard $cT (Dur $sw.Elapsed) $null
    $script:run = $false; SetTag 'FERTIG' $gr
    Msg "Bericht gespeichert: $script:lastTxt" $null
    $btnStart.Tag.On = $true; $btnStart.Invalidate(); $script:busy = $false
}

# ---------- Bericht (TXT + HTML im Sippicom-Design) ----------
function SaveReport {
    if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
    $kt1 = $tkb.Text.Trim()
    # Kunde/Ticket fließt (bereinigt) in den Dateinamen ein
    $ktFile = ($kt1 -replace '[^\p{L}\p{Nd}\-]+', '_').Trim('_'); if ($ktFile.Length -gt 40) { $ktFile = $ktFile.Substring(0, 40) }
    if ($ktFile) { $ktFile = "_$ktFile" }
    $ts1 = Get-Date -Format 'yyyyMMdd_HHmmss'; $base1 = Join-Path $outDir "Diagnosebericht_${env:COMPUTERNAME}${ktFile}_$ts1"
    $adm1 = 'nein (einige Prüfungen eingeschränkt)'; if ($isAdmin) { $adm1 = 'ja' }
    # ----- Vergleich mit dem letzten Lauf auf diesem Rechner (Befunde liegen als JSON im Berichtsordner) -----
    $cmpFile = Join-Path $outDir "Befunde_$($env:COMPUTERNAME).json"
    $cmpRows = New-Object Collections.Generic.List[object]; $cmpWhen = ''
    $cmpCur = @($script:finds | ForEach-Object { [pscustomobject]@{ sec = [string]$_.Sec; t = [string]$_.T } })
    try {
        if (Test-Path -LiteralPath $cmpFile) {
            $cmpJ = Get-Content -LiteralPath $cmpFile -Raw -Encoding UTF8 | ConvertFrom-Json
            $cmpWhen = [string]$cmpJ.date
            $cmpOld = @($cmpJ.finds | Where-Object { $_ })
            $cmpSecs = @($script:sections | ForEach-Object { [string]$_.T })
            $cmpCurKeys = @($cmpCur | ForEach-Object { "$($_.sec)|$($_.t)" })
            $cmpOldKeys = @($cmpOld | ForEach-Object { "$($_.sec)|$($_.t)" })
            foreach ($cmpO in $cmpOld) {
                $cmpK = "$($cmpO.sec)|$($cmpO.t)"
                if ($cmpCurKeys -contains $cmpK) { $cmpRows.Add(@{ s = 'besteht weiterhin'; x = "$($cmpO.sec): $($cmpO.t)" }) }
                elseif ($cmpSecs -contains [string]$cmpO.sec) { $cmpRows.Add(@{ s = 'behoben'; x = "$($cmpO.sec): $($cmpO.t)" }) }
            }
            foreach ($cmpC in $cmpCur) { if ($cmpOldKeys -notcontains "$($cmpC.sec)|$($cmpC.t)") { $cmpRows.Add(@{ s = 'neu'; x = "$($cmpC.sec): $($cmpC.t)" }) } }
        }
    } catch { $cmpWhen = '' }
    # ----- TXT -----
    $head1 = @($script:hdrLine)
    if ($kt1) { $head1 += "Kunde/Ticket: $kt1" }
    if ($script:privAt) { $head1 += "Datenschutzerklärung (Stand $privStand) bestätigt am $($script:privAt)" }
    $head1 += @("Administratorrechte: $(JN $isAdmin)  |  Auffälligkeiten: $($script:lastNf)  |  Support: $mail  |  Version $appVer")
    $txt1 = New-Object Collections.Generic.List[string]; foreach ($hl in $head1) { $txt1.Add($hl) }
    if ($script:finds.Count) {
        $txt1.Add(''); $txt1.Add('AUFFÄLLIGKEITEN UND EMPFEHLUNGEN (HOCH / MITTEL / NIEDRIG)'); $txt1.Add('-' * 70)
        foreach ($fi in $script:finds) { $txt1.Add("  [$($fi.L)] $($fi.Sec): $($fi.T)"); if ($fi.R) { $txt1.Add("           Empfehlung: $($fi.R)") } }
    }
    if ($cmpWhen) {
        $txt1.Add(''); $txt1.Add("VERGLEICH MIT DEM LETZTEN LAUF ($cmpWhen)"); $txt1.Add('-' * 70)
        if ($cmpRows.Count -eq 0) { $txt1.Add('  Keine Auffälligkeiten damals und heute.') }
        foreach ($cmpR in $cmpRows) { $txt1.Add(('  ' + $cmpR.s.PadRight(18) + ' ' + $cmpR.x)) }
    }
    foreach ($sc1 in $script:sections) { $txt1.Add(''); $txt1.Add($sc1.T); $txt1.Add('-' * 70); foreach ($ln in $sc1.L) { $txt1.Add($ln) } }
    if ($script:notSel) { $txt1.Add(''); $txt1.Add($script:notSel) }
    # ----- HTML -----
    $msl = New-Object IO.MemoryStream; $wideImg.Save($msl, [Drawing.Imaging.ImageFormat]::Png); $logo64 = [Convert]::ToBase64String($msl.ToArray())
    # Kopfbild des Berichts (A5): auf Bannergröße zugeschnitten, als JPEG eingebettet; ohne Bild bleibt der Farbverlauf
    $topStyle = ''
    try {
        $a5P = AssetPath 'A5'
        if ($a5P -and $script:imgOk) {
            $a5B = [Sip.Img]::Cover($a5P, 1600, 190, 0.5, 0.5)
            $a5Codec = [Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' } | Select-Object -First 1
            $a5Par = New-Object Drawing.Imaging.EncoderParameters(1)
            $a5Par.Param[0] = New-Object Drawing.Imaging.EncoderParameter([Drawing.Imaging.Encoder]::Quality, [long]78)
            $a5Ms = New-Object IO.MemoryStream; $a5B.Save($a5Ms, $a5Codec, $a5Par); $a5B.Dispose()
            $topStyle = " style='background:linear-gradient(90deg,rgba(16,16,17,.94) 0%,rgba(16,16,17,.62) 50%,rgba(16,16,17,.08) 100%),url(data:image/jpeg;base64,$([Convert]::ToBase64String($a5Ms.ToArray()))) center/cover'"
        }
    } catch { $topStyle = '' }
    $css = @'
body{margin:0;background:#f3f3f5;font-family:"Segoe UI",Arial,sans-serif;color:#1c1c1e}
.top{background:linear-gradient(90deg,#101011,#2b2018);border-bottom:4px solid #f28c28;padding:20px 36px;display:flex;align-items:center;gap:24px;color:#fff}
.top img{height:48px}.top h1{margin:0;font-size:26px}.top p{margin:4px 0 0;font-size:13px;color:#ddd}
.wrap{max-width:1000px;margin:26px auto;padding:0 16px}
.tiles{display:grid;grid-template-columns:repeat(5,1fr);gap:12px}
.tile{background:#fff;border-radius:10px;padding:14px;box-shadow:0 1px 4px rgba(0,0,0,.08)}
.tile span{display:block;font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px}
.tile b{font-size:14px}
.banner{margin:18px 0;padding:16px 20px;border-radius:10px;color:#fff;font-size:18px;font-weight:600}
h2{border-left:5px solid #f28c28;padding-left:10px;font-size:18px;margin:28px 0 12px}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.08)}
th{background:#1c1c1e;color:#fff;text-align:left;padding:10px 12px;font-size:13px}
td{padding:10px 12px;border-bottom:1px solid #eee;font-size:13px;vertical-align:top}
.pill{display:inline-block;padding:3px 10px;border-radius:12px;color:#fff;font-size:11px;font-weight:700}
.card{background:#fff;border-radius:10px;overflow:hidden;margin-bottom:14px;box-shadow:0 1px 4px rgba(0,0,0,.08)}
.card h3{background:#1c1c1e;color:#f28c28;margin:0;padding:11px 16px;font-size:13px;text-transform:uppercase;letter-spacing:.4px}
.card pre{margin:0;padding:14px 16px;font:12px/1.4 Consolas,"Courier New",monospace;white-space:pre-wrap;color:#1c1c1e}
.r{color:#d0524f;font-weight:700}.o{color:#e08a00;font-weight:700}
.foot{text-align:center;color:#777;font-size:12px;margin:28px 0 20px;line-height:1.6}.foot a{color:#e08a00;text-decoration:none}
'@
    $h1 = New-Object Text.StringBuilder
    [void]$h1.Append("<!DOCTYPE html><html lang='de'><head><meta charset='utf-8'><title>Diagnosebericht $env:COMPUTERNAME</title><style>$css</style></head><body>")
    [void]$h1.Append("<div class='top'$topStyle><img src='data:image/png;base64,$logo64' alt='Sippicom'><div><h1>Diagnosebericht</h1><p>Sippicom IT-Solutions - $appName</p></div></div><div class='wrap'>")
    $kt1Show = '-'; if ($kt1) { $kt1Show = $kt1 }
    [void]$h1.Append("<div class='tiles'>")
    foreach ($tl in @(@('Computer', $env:COMPUTERNAME), @('Benutzer', "$env:USERDOMAIN\$env:USERNAME"), @('Datum', (Get-Date -Format 'dd.MM.yyyy HH:mm')), @('Kunde / Ticket', $kt1Show), @('Administratorrechte', $adm1), @('Geprüfte Bereiche', ($script:checked -join ', ')))) {
        [void]$h1.Append("<div class='tile'><span>$(Hz $tl[0])</span><b>$(Hz $tl[1])</b></div>")
    }
    [void]$h1.Append('</div>')
    if ($script:lastNf -eq 0) { $bc1 = '#3fa05a'; $bt1 = 'Alles in Ordnung - keine Auffälligkeiten erkannt.' }
    else { $bc1 = '#e08a00'; if ($script:sevMax -eq 2) { $bc1 = '#d0524f' }; $bt1 = "$($script:lastNf) Auffälligkeiten gefunden"; if ($script:lastNf -eq 1) { $bt1 = '1 Auffälligkeit gefunden' } }
    [void]$h1.Append("<div class='banner' style='background:$bc1'>$(Hz $bt1)</div>")
    if ($script:finds.Count) {
        [void]$h1.Append("<h2>Auffälligkeiten und Empfehlungen</h2><table><tr><th style='width:110px'>Priorität</th><th>Befund</th><th>Empfehlung</th></tr>")
        $ord1 = @{ 'HOCH' = 0; 'MITTEL' = 1; 'NIEDRIG' = 2 }; $pc1 = @{ 'HOCH' = '#d0524f'; 'MITTEL' = '#e08a00'; 'NIEDRIG' = '#4a7fb5' }
        foreach ($fi in @($script:finds | Sort-Object { $ord1[$_.L] })) {
            [void]$h1.Append("<tr><td><span class='pill' style='background:$($pc1[$fi.L])'>$($fi.L)</span></td><td>$(Hz $fi.T)</td><td>$(Hz $fi.R)</td></tr>")
        }
        [void]$h1.Append('</table>')
    }
    if ($cmpWhen) {
        [void]$h1.Append("<h2>Vergleich mit dem letzten Lauf ($(Hz $cmpWhen))</h2>")
        if ($cmpRows.Count -eq 0) { [void]$h1.Append("<div class='card'><pre>Keine Auffälligkeiten damals und heute.</pre></div>") }
        else {
            [void]$h1.Append("<table><tr><th style='width:150px'>Status</th><th>Befund</th></tr>")
            $cmpCol = @{ 'behoben' = '#3fa05a'; 'neu' = '#d0524f'; 'besteht weiterhin' = '#e08a00' }
            foreach ($cmpR in $cmpRows) { [void]$h1.Append("<tr><td><span class='pill' style='background:$($cmpCol[$cmpR.s])'>$(Hz $cmpR.s)</span></td><td>$(Hz $cmpR.x)</td></tr>") }
            [void]$h1.Append('</table>')
        }
    }
    [void]$h1.Append('<h2>Protokoll</h2>')
    $nSec1 = $script:sections.Count; $ix1 = 0
    foreach ($sc1 in $script:sections) {
        $ix1++
        [void]$h1.Append("<div class='card'><h3>$(Hz $sc1.T)</h3><pre>")
        $lines1 = @($sc1.L); if ($ix1 -eq $nSec1 -and $script:notSel) { $lines1 += $script:notSel }
        foreach ($ln in $lines1) {
            $e1 = Hz $ln
            if ($ln -match '^!! ') { $e1 = "<span class='r'>$e1</span>" } elseif ($ln -match '^! ' -or $ln -match '^\s*Hinweis:') { $e1 = "<span class='o'>$e1</span>" }
            [void]$h1.Append($e1 + "`n")
        }
        [void]$h1.Append('</pre></div>')
    }
    [void]$h1.Append("<div class='foot'>$(Hz $cpy) | Tel. $telefon | www.sippicom.com | <a href='mailto:$mail'>$mail</a><br>Erstellt mit dem $appName, Version $appVer (Diagnosen nur lesend; Reparatur-Werkzeuge nur nach Bestätigung)</div></div></body></html>")
    [IO.File]::WriteAllLines("$base1.txt", $txt1, (New-Object Text.UTF8Encoding($true)))
    [IO.File]::WriteAllText("$base1.html", $h1.ToString(), (New-Object Text.UTF8Encoding($true)))
    $script:lastTxt = "$base1.txt"; $script:lastHtml = "$base1.html"; $script:lastBody = ($txt1 -join "`r`n")
    # Befunde dieses Laufs als Grundlage für den nächsten Vergleich merken
    try {
        $cmpOut = [pscustomobject]@{ date = (Get-Date -Format 'dd.MM.yyyy HH:mm'); finds = @($cmpCur) }
        [IO.File]::WriteAllText($cmpFile, ($cmpOut | ConvertTo-Json -Depth 4), (New-Object Text.UTF8Encoding($true)))
    } catch {}
}
# Datenschutz: Berichte enthalten Computer-, Benutzer- und Domänennamen. Vor dem Versand wird gefragt, ob Kopien mit Platzhaltern
# versendet werden sollen (Ja = anonymisierte Kopien im Temp-Ordner, Nein = Originale). Liefert die zu versendenden Dateien.
$script:anonOn = $false
function AnonText([string]$anT) {
    foreach ($anP in @(@($env:COMPUTERNAME, 'PC-ANONYM'), @($env:USERNAME, 'BENUTZER'), @($env:USERDOMAIN, 'DOMAENE'))) {
        if ($anP[0] -and $anP[0].Length -ge 3) { $anT = [regex]::Replace($anT, [regex]::Escape($anP[0]), $anP[1], 'IgnoreCase') }
    }
    return $anT
}
function AnonReportFiles([string[]]$anFiles) {
    $script:anonOn = $false
    $anAsk = SipBox "Der Bericht enthält Computername, Benutzername und Domäne.`r`nBitte nur mit Einverständnis des Kunden versenden.`r`n`r`nSollen diese Namen in den versendeten Kopien durch Platzhalter ersetzt werden?`r`n(Ja = anonymisierte Kopien, Nein = Originale)" 'Datenschutz' $true
    if (-not $anAsk) { return @($anFiles | Where-Object { $_ -and (Test-Path -LiteralPath $_) }) }
    $anOut = New-Object Collections.Generic.List[string]
    foreach ($anF in $anFiles) {
        if (-not ($anF -and (Test-Path -LiteralPath $anF))) { continue }
        try {
            $anNew = Join-Path $env:TEMP (AnonText (Split-Path $anF -Leaf))
            $anRaw = [IO.File]::ReadAllText($anF, [Text.Encoding]::UTF8)
            [IO.File]::WriteAllText($anNew, (AnonText $anRaw), (New-Object Text.UTF8Encoding($true)))
            $anOut.Add($anNew)
        } catch { $anOut.Add($anF) }
    }
    $script:anonOn = $true
    return $anOut.ToArray()
}
function HaveReport {
    if (-not $script:lastTxt -or -not (Test-Path $script:lastTxt)) { [void](SipBox 'Es liegt noch kein Bericht vor. Bitte führen Sie zuerst eine Diagnose aus.' 'Kein Bericht vorhanden'); return $false }
    return $true
}
function OpenFolder { if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }; Start-Process explorer.exe "`"$outDir`"" }
function OpenReport { if (HaveReport) { Start-Process $script:lastHtml } }
function CopyReport {
    if (-not (HaveReport)) { return }
    try { [Windows.Forms.Clipboard]::SetText($script:lastBody); Msg 'Bericht wurde in die Zwischenablage kopiert.' $null }
    catch { [void](SipBox "Kopieren fehlgeschlagen: $($_.Exception.Message)" 'Fehler') }
}
function MakeZip {
    if (-not (HaveReport)) { return }
    $z = [IO.Path]::ChangeExtension($script:lastTxt, '.zip')
    try {
        # Bericht (TXT, HTML) und, falls vorhanden, die Analyse des letzten Paketmitschnitts (ohne den Mitschnitt selbst, er kann vertrauliche Daten enthalten)
        $zFiles = @(AnonReportFiles @($script:lastTxt, $script:lastHtml))
        if ($script:ncAna -and (Test-Path -LiteralPath $script:ncAna)) { $zFiles += $script:ncAna }
        Compress-Archive -LiteralPath $zFiles -DestinationPath $z -Force -ErrorAction Stop
        Start-Process explorer.exe "/select,`"$z`""; Msg "Support-ZIP erstellt: $z" $null
        $zClip = ''
        try { $zl = New-Object Collections.Specialized.StringCollection; [void]$zl.Add($z); [Windows.Forms.Clipboard]::SetFileDropList($zl); $zClip = ' Die ZIP liegt außerdem in der Zwischenablage: Mit Strg+V lässt sie sich direkt im Ticket oder in einer E-Mail einfügen.' } catch {}
        [void](SipBox "Die Support-ZIP wurde erstellt und im Ordner markiert. Senden Sie sie bitte an $mail.$zClip" 'Support-ZIP')
    } catch { [void](SipBox "ZIP konnte nicht erstellt werden: $($_.Exception.Message)" 'Fehler') }
}
function SendSupportMail {
    if (-not (HaveReport)) { return }
    $kt1 = $tkb.Text.Trim(); $subj = "Diagnosebericht $env:COMPUTERNAME"; if ($kt1) { $subj += " - $kt1" }
    $body = "Guten Tag,`r`n`r`nanbei der Diagnosebericht.`r`n`r`nPC: $env:COMPUTERNAME`r`nBenutzer: $env:USERNAME`r`nDatum: $(Get-Date -Format 'dd.MM.yyyy HH:mm')`r`nAuffälligkeiten: $($script:lastNf)`r`n`r`nViele Grüße"
    # Datenschutz: auf Wunsch anonymisierte Kopien versenden (Namen in Betreff, Text und Anhängen durch Platzhalter ersetzt)
    $smFiles = @(AnonReportFiles @($script:lastTxt, $script:lastHtml))
    if ($script:anonOn) { $subj = AnonText $subj; $body = AnonText $body }
    # 1. Weg: klassisches Outlook per COM (laufende Instanz zuerst, dann neu starten)
    $smErr = ''
    try {
        $ol = $null
        try { $ol = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') } catch {}
        if (-not $ol) { $ol = New-Object -ComObject Outlook.Application -ErrorAction Stop }
        $m = $ol.CreateItem(0); $m.To = $mail; $m.Subject = $subj; $m.Body = $body
        foreach ($fa in $smFiles) { if (Test-Path $fa) { [void]$m.Attachments.Add($fa) } }
        $m.Display()
        return
    } catch { $smErr = $_.Exception.Message }
    # 2. Weg: E-Mail-Entwurf als .eml-Datei mit eingebetteten Anhängen (X-Unsent) im Standard-Mailprogramm öffnen.
    # Das ist zuverlässiger als mailto: (dort landete der gesamte Text im Feld An) und braucht kein COM.
    try {
        $smNl = "`r`n"; $smBd = 'SIPBND' + [guid]::NewGuid().ToString('N')
        $smU8 = New-Object Text.UTF8Encoding($false)
        $smB64 = { param([byte[]]$b) [Convert]::ToBase64String($b, [Base64FormattingOptions]::InsertLineBreaks) }
        $smEml = New-Object Text.StringBuilder
        [void]$smEml.Append("To: $mail$smNl")
        [void]$smEml.Append('Subject: =?UTF-8?B?' + [Convert]::ToBase64String($smU8.GetBytes($subj)) + "?=$smNl")
        [void]$smEml.Append("X-Unsent: 1$($smNl)MIME-Version: 1.0$($smNl)Content-Type: multipart/mixed; boundary=`"$smBd`"$smNl$smNl")
        [void]$smEml.Append("--$smBd$($smNl)Content-Type: text/plain; charset=utf-8$($smNl)Content-Transfer-Encoding: base64$smNl$smNl")
        [void]$smEml.Append((& $smB64 $smU8.GetBytes($body)) + $smNl)
        foreach ($fa in $smFiles) {
            if ($fa -and (Test-Path -LiteralPath $fa)) {
                $smNm = (Split-Path $fa -Leaf) -replace '[^\w\.\-]', '_'
                [void]$smEml.Append("--$smBd$($smNl)Content-Type: application/octet-stream; name=`"$smNm`"$($smNl)Content-Disposition: attachment; filename=`"$smNm`"$($smNl)Content-Transfer-Encoding: base64$smNl$smNl")
                [void]$smEml.Append((& $smB64 ([IO.File]::ReadAllBytes($fa))) + $smNl)
            }
        }
        [void]$smEml.Append("--$smBd--$smNl")
        $smFile = Join-Path $env:TEMP "Diagnosebericht_$env:COMPUTERNAME.eml"
        [IO.File]::WriteAllText($smFile, $smEml.ToString(), (New-Object Text.UTF8Encoding($false)))
        Start-Process -FilePath $smFile
        $smHint = ''
        if ($isAdmin) { $smHint = ' Das Programm läuft mit Administratorrechten; klassisches Outlook läuft meist ohne und lässt sich dann nicht ansteuern. Für den direkten Versand mit Anhang das Programm ohne Administratorrechte starten.' }
        [void](SipBox ("Der E-Mail-Entwurf mit beiden Berichtsdateien als Anhang wurde im Standard-Mailprogramm geöffnet." + $smHint + "`r`n`r`nGrund für den Ausweichweg: " + (Cut $smErr 140)) 'E-Mail vorbereitet')
    } catch {
        try {
            $scl = New-Object Collections.Specialized.StringCollection; foreach ($smFb in $smFiles) { [void]$scl.Add($smFb) }
            [Windows.Forms.Clipboard]::SetFileDropList($scl)
            [void](SipBox "Der E-Mail-Entwurf konnte nicht erstellt werden ($($_.Exception.Message)). Die Berichtsdateien liegen in der Zwischenablage: In eine neue E-Mail an $mail mit Strg+V als Anhang einfügen." 'Anhang einfügen')
        } catch { [void](SipBox "E-Mail konnte nicht vorbereitet werden: $($_.Exception.Message)" 'Fehler') }
    }
}
# Symbol-Kachel für die Desktop-Verknüpfung: dunkle, abgerundete Kachel mit orangem Rahmen und Sippicom-Logo
# (der Rahmen hebt das Symbol auch auf schwarzem Hintergrund ab). Liefert die PNG-Bytes der gewünschten Größe.
function MkIconTile([int]$sz = 256) {
    # Programm-Symbol aus dem Ordner assets (B5a), sonst die bisherige gezeichnete Kachel
    $b5P = AssetPath 'B5a'
    if ($b5P -and $script:imgOk) {
        try {
            $b5B = [Sip.Img]::Cell($b5P, 1, 1, 0, $sz, $true)
            $b5M = New-Object IO.MemoryStream; $b5B.Save($b5M, [Drawing.Imaging.ImageFormat]::Png); $b5B.Dispose()
            return , $b5M.ToArray()
        } catch {}
    }
    $bm = New-Object Drawing.Bitmap($sz, $sz); $g = [Drawing.Graphics]::FromImage($bm)
    $g.SmoothingMode = 'AntiAlias'; $g.InterpolationMode = 'HighQualityBicubic'; $g.PixelOffsetMode = 'HighQuality'
    $g.Clear([Drawing.Color]::Transparent)
    $mg = [int][math]::Max(1, [math]::Round($sz * 0.035))
    $rad = [int][math]::Max(3, [math]::Round($sz * 0.22))
    $rect = New-Object Drawing.Rectangle($mg, $mg, ($sz - 2 * $mg - 1), ($sz - 2 * $mg - 1))
    $br = New-Object Drawing.Drawing2D.LinearGradientBrush($rect, [Drawing.Color]::FromArgb(255, 50, 50, 54), [Drawing.Color]::FromArgb(255, 24, 24, 26), 90)
    $g.FillPath($br, (RR $rect $rad))
    $pw = [single][math]::Max(1.5, $sz * 0.04)
    $pen = New-Object Drawing.Pen([Drawing.Color]::FromArgb(255, 242, 140, 40), $pw)
    $g.DrawPath($pen, (RR $rect $rad))
    $lm = [int][math]::Round($sz * 0.17)
    $g.DrawImage($logoImg, $lm, $lm, ($sz - 2 * $lm), ($sz - 2 * $lm))
    $g.Dispose()
    $ms = New-Object IO.MemoryStream; $bm.Save($ms, [Drawing.Imaging.ImageFormat]::Png)
    return , $ms.ToArray()
}
# ICO-Datei mit mehreren Größen (PNG-komprimiert) schreiben, damit Windows das Symbol zuverlässig anzeigt
function NewIcoFile([string]$icPath) {
    $icSizes = @(16, 32, 48, 64, 128, 256)
    $icPng = @()
    foreach ($icS in $icSizes) { $icPng += , ([byte[]](MkIconTile $icS)) }
    if (Test-Path -LiteralPath $icPath) { Remove-Item -LiteralPath $icPath -Force -ErrorAction SilentlyContinue }
    $icFs = [IO.File]::Create($icPath); $icBw = New-Object IO.BinaryWriter($icFs)
    $icBw.Write([uint16]0); $icBw.Write([uint16]1); $icBw.Write([uint16]$icSizes.Count)
    $icOff = 6 + 16 * $icSizes.Count
    for ($icI = 0; $icI -lt $icSizes.Count; $icI++) {
        $icW = $icSizes[$icI]; if ($icW -ge 256) { $icW = 0 }
        $icBw.Write([byte]$icW); $icBw.Write([byte]$icW); $icBw.Write([byte]0); $icBw.Write([byte]0)
        $icBw.Write([uint16]1); $icBw.Write([uint16]32)
        $icBw.Write([uint32]$icPng[$icI].Length); $icBw.Write([uint32]$icOff)
        $icOff += $icPng[$icI].Length
    }
    for ($icI = 0; $icI -lt $icSizes.Count; $icI++) { $icBw.Write([byte[]]$icPng[$icI]) }
    $icBw.Close(); $icFs.Close()
}
function NewDesktopLink {
    try {
        if (-not (Test-Path 'C:\SippicomInstall')) { New-Item -ItemType Directory -Path 'C:\SippicomInstall' -Force | Out-Null }
        $icoPath = 'C:\SippicomInstall\Sippicom_Diagnosezentrum.ico'
        NewIcoFile $icoPath
        if (-not (Test-Path -LiteralPath $icoPath)) { [void](SipBox 'Die Symboldatei konnte nicht angelegt werden (C:\SippicomInstall).' 'Fehler'); return }
        $exe = [Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        $target = $exe; $args2 = ''; $wdir = Split-Path $exe -Parent
        if ([IO.Path]::GetFileNameWithoutExtension($exe) -match '^(powershell|pwsh)$') {
            $ps1 = $null
            if ($script:selfSrc -and $script:selfSrc.Length -lt 260 -and (Test-Path $script:selfSrc)) { $ps1 = $script:selfSrc }
            elseif ($script:selfSrc -and $script:selfSrc.Length -gt 2000) {
                $ps1 = 'C:\SippicomInstall\Sippicom_Diagnosezentrum.ps1'
                [IO.File]::WriteAllText($ps1, $script:selfSrc, (New-Object Text.UTF8Encoding($true)))
            }
            if (-not $ps1) { [void](SipBox 'Die Verknüpfung ist nur in der EXE-Version oder beim Start aus einer .ps1-Datei möglich.' 'Nicht möglich'); return }
            $args2 = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ps1`""
            $wdir = Split-Path $ps1 -Parent
        }
        $lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Sippicom Diagnosezentrum.lnk'
        $sh = New-Object -ComObject WScript.Shell; $scut = $sh.CreateShortcut($lnk)
        $scut.TargetPath = $target; $scut.Arguments = $args2; $scut.WorkingDirectory = $wdir
        $scut.IconLocation = "$icoPath,0"; $scut.Description = "Sippicom IT-Solutions - $appName"; $scut.Save()
        # Symbol-Cache von Windows aktualisieren, damit das neue Symbol sofort erscheint
        try { Start-Process -FilePath "$env:windir\System32\ie4uinit.exe" -ArgumentList '-show' -WindowStyle Hidden } catch {}
        [void](SipBox 'Die Desktop-Verknüpfung "Sippicom Diagnosezentrum" wurde mit dem Sippicom-Logo erstellt (dunkle Kachel mit orangem Rahmen, auch auf schwarzem Hintergrund gut sichtbar). Zeigt der Desktop noch das alte Symbol, bitte die alte Verknüpfung löschen oder den Desktop mit F5 aktualisieren.' 'Verknüpfung erstellt')
    } catch { [void](SipBox "Verknüpfung konnte nicht erstellt werden: $($_.Exception.Message)" 'Fehler') }
}

# ---------- Schnell-Check ----------
# Wählt nur System und Datenträger, Netzwerk, Windows-Updates und Sicherheit aus und startet sofort (bisherige Auswahl wird zurückgesetzt).
function QuickCheck {
    if ($script:busy) { return }
    SetTab 'diag'
    $qkKeys = @('System', 'Netzwerk', 'Updates', 'Sicherheit')
    foreach ($qkD in $diag) { $qkD.pn.Tag.On = ($qkKeys -contains $qkD.k); $qkD.pn.Invalidate() }
    $side.Invalidate()
    Msg 'Schnell-Check: System, Netzwerk, Updates und Sicherheit ...' $null
    RunDiag
}

# ---------- Verlauf und Vergleich ----------
# Je Lauf wird ein Schnappschuss (Auffälligkeiten, freier Platz, letztes Update, Build) in Verlauf_<PC>.json gespeichert (letzte 20 Läufe).
function HistFile { Join-Path $outDir "Verlauf_$env:COMPUTERNAME.json" }
function HistKey([string]$hkT) { ($hkT -replace '\d+', '#').ToLower().Trim() }
function HistLoad {
    $hlFile = HistFile
    if (Test-Path -LiteralPath $hlFile) {
        try { $hlObj = Get-Content -LiteralPath $hlFile -Raw -Encoding UTF8 | ConvertFrom-Json; return @(@($hlObj.Runs) | Where-Object { $_ }) } catch {}
    }
    return @()
}
function HistSnap {
    $hsFree = $null; try { $hsFree = [math]::Round((Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'").FreeSpace / 1GB, 1) } catch {}
    $hsHot = ''; try { $hsH = Get-HotFix | Where-Object { $_.InstalledOn } | Sort-Object InstalledOn -Descending | Select-Object -First 1; if ($hsH) { $hsHot = "$($hsH.HotFixID) ($($hsH.InstalledOn.ToString('dd.MM.yyyy')))" } } catch {}
    $hsBuild = ''; try { $hsBuild = "$((Get-CimInstance Win32_OperatingSystem).Version)" } catch {}
    [pscustomobject]@{
        Ts = (Get-Date -Format 'dd.MM.yyyy HH:mm'); Ticket = $tkb.Text.Trim(); Ver = $appVer
        Checked = @($script:checked)
        Finds = @($script:finds | ForEach-Object { [pscustomobject]@{ Sec = "$($_.Sec)"; T = "$($_.T)"; S = [int]$_.S } })
        FreeGB = $hsFree; Hotfix = $hsHot; Build = $hsBuild
    }
}
$script:hiCur = $null
function HistCompare {
    $script:hiCur = HistSnap
    $hiRuns = @(HistLoad)
    if ($hiRuns.Count -eq 0) { 'Erster gespeicherter Lauf für diesen PC - noch kein Vergleich möglich. Ab dem nächsten Lauf erscheinen hier Veränderungen.'; return }
    $hiPrev = $hiRuns[$hiRuns.Count - 1]; $hiNow = $script:hiCur
    $hiTk = ''; if ($hiPrev.Ticket) { $hiTk = "  (Kunde/Ticket: $($hiPrev.Ticket))" }
    "Letzter Lauf       : $($hiPrev.Ts)$hiTk"
    # Nur Bereiche vergleichen, die in beiden Läufen geprüft wurden
    $hiBoth = @(@($hiNow.Checked) | Where-Object { @($hiPrev.Checked) -contains $_ })
    $hiPF = @(@($hiPrev.Finds) | Where-Object { $_ -and ($hiBoth -contains $_.Sec) })
    $hiNF = @(@($hiNow.Finds) | Where-Object { $_ -and ($hiBoth -contains $_.Sec) })
    $hiPKeys = @($hiPF | ForEach-Object { HistKey "$($_.Sec)|$($_.T)" })
    $hiNKeys = @($hiNF | ForEach-Object { HistKey "$($_.Sec)|$($_.T)" })
    $hiNew = @($hiNF | Where-Object { $hiPKeys -notcontains (HistKey "$($_.Sec)|$($_.T)") })
    $hiFix = @($hiPF | Where-Object { $hiNKeys -notcontains (HistKey "$($_.Sec)|$($_.T)") })
    $hiSame = $hiNF.Count - $hiNew.Count
    "Verglichene Bereiche: $($hiBoth.Count)"
    if ($hiNew.Count -eq 0 -and $hiFix.Count -eq 0) { 'Auffälligkeiten    : unverändert (' + $hiNF.Count + ' vorhanden)' }
    else {
        if ($hiNew.Count) { "Neu ($($hiNew.Count)):"; foreach ($hiX in $hiNew) { "  + $($hiX.Sec): $(Cut $hiX.T 100)" } }
        if ($hiFix.Count) { "Behoben ($($hiFix.Count)):"; foreach ($hiX in $hiFix) { "  - $($hiX.Sec): $(Cut $hiX.T 100)" } }
        "Unverändert        : $hiSame"
    }
    if ($null -ne $hiNow.FreeGB -and $null -ne $hiPrev.FreeGB) {
        $hiD = [math]::Round(([double]$hiNow.FreeGB - [double]$hiPrev.FreeGB), 1); $hiSg = ''; if ($hiD -gt 0) { $hiSg = '+' }
        "Freier Platz $($env:SystemDrive)   : $($hiNow.FreeGB) GB (vorher $($hiPrev.FreeGB) GB, Änderung $hiSg$hiD GB)"
    }
    if ($hiNow.Hotfix) {
        if ($hiNow.Hotfix -ne $hiPrev.Hotfix) { "Letztes Update    : $($hiNow.Hotfix) (vorher $($hiPrev.Hotfix))" } else { "Letztes Update    : unverändert ($($hiNow.Hotfix))" }
    }
    if ($hiNow.Build -and $hiPrev.Build -and $hiNow.Build -ne $hiPrev.Build) { "Windows-Build     : $($hiPrev.Build) -> $($hiNow.Build)" }
}
function HistSave {
    if (-not $script:hiCur) { return }
    $hsRuns = @(HistLoad); $hsRuns += $script:hiCur
    if ($hsRuns.Count -gt 20) { $hsRuns = @($hsRuns[($hsRuns.Count - 20)..($hsRuns.Count - 1)]) }
    $hsJson = ([pscustomobject]@{ Runs = $hsRuns } | ConvertTo-Json -Depth 6)
    [IO.File]::WriteAllText((HistFile), $hsJson, (New-Object Text.UTF8Encoding($true)))
    $script:hiCur = $null
}

# ---------- Kundenbericht (leicht verständlich, druckbar) ----------
function CustomerReport {
    if (-not (HaveReport)) { return }
    $cuTkt = $tkb.Text.Trim()
    $cuMs = New-Object IO.MemoryStream; $wideImg.Save($cuMs, [Drawing.Imaging.ImageFormat]::Png); $cuLogo = [Convert]::ToBase64String($cuMs.ToArray())
    $cuCss = @'
body{margin:0;background:#f3f3f5;font-family:"Segoe UI",Arial,sans-serif;color:#1c1c1e;font-size:15px}
.top{background:linear-gradient(90deg,#101011,#2b2018);border-bottom:4px solid #f28c28;padding:20px 36px;display:flex;align-items:center;gap:24px;color:#fff}
.top img{height:48px}.top h1{margin:0;font-size:26px}.top p{margin:4px 0 0;font-size:14px;color:#ddd}
.hero{height:230px;max-width:900px;margin:26px auto 0;border-radius:12px;background-color:#f1f0ed;background-repeat:no-repeat;background-size:auto 100%;background-position:right center;box-shadow:0 1px 4px rgba(0,0,0,.08);-webkit-print-color-adjust:exact;print-color-adjust:exact}
@media(max-width:940px){.hero{margin:18px 18px 0}}
.wrap{max-width:900px;margin:26px auto;padding:0 18px}
.meta{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:6px}
.meta div{background:#fff;border-radius:10px;padding:12px 16px;box-shadow:0 1px 4px rgba(0,0,0,.08);min-width:180px}
.meta span{display:block;font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px}
.banner{margin:18px 0;padding:18px 22px;border-radius:10px;color:#fff;font-size:19px;font-weight:600}
h2{border-left:5px solid #f28c28;padding-left:10px;font-size:19px;margin:30px 0 12px}
.item{background:#fff;border-radius:10px;padding:14px 18px;margin-bottom:12px;box-shadow:0 1px 4px rgba(0,0,0,.08)}
.pill{display:inline-block;padding:3px 12px;border-radius:12px;color:#fff;font-size:12px;font-weight:700;margin-bottom:8px}
.item p{margin:4px 0}.item .lbl{color:#666;font-size:12px;text-transform:uppercase;letter-spacing:.4px}
ul{background:#fff;border-radius:10px;padding:14px 18px 14px 36px;box-shadow:0 1px 4px rgba(0,0,0,.08)}
.next{background:#fff;border-radius:10px;padding:16px 20px;box-shadow:0 1px 4px rgba(0,0,0,.08);line-height:1.6}
.foot{text-align:center;color:#777;font-size:12px;margin:28px 0 20px;line-height:1.6}.foot a{color:#e08a00;text-decoration:none}
@media print{body{background:#fff}.item,ul,.next,.meta div{box-shadow:none;border:1px solid #ddd}.top{-webkit-print-color-adjust:exact;print-color-adjust:exact}.banner,.pill{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
'@
    $cuH = New-Object Text.StringBuilder
    [void]$cuH.Append("<!DOCTYPE html><html lang='de'><head><meta charset='utf-8'><title>Computer-Check $env:COMPUTERNAME</title><style>$cuCss</style></head><body>")
    $cuSub = 'Zusammenfassung Ihrer Computerprüfung'; if ($cuTkt) { $cuSub += " - $(Hz $cuTkt)" }
    $cuHero = ''
    try {
        $cuHf = AssetPath 'C4'
        if ($cuHf) { $cuHero = "<div class='hero' style=""background-image:url('data:image/jpeg;base64,$([Convert]::ToBase64String([IO.File]::ReadAllBytes($cuHf)))')""></div>" }
    } catch { $cuHero = '' }
    [void]$cuH.Append("<div class='top'><img src='data:image/png;base64,$cuLogo' alt='Sippicom'><div><h1>Ihr Computer-Check</h1><p>$cuSub</p></div></div>$cuHero<div class='wrap'>")
    [void]$cuH.Append("<div class='meta'><div><span>Computer</span><b>$(Hz $env:COMPUTERNAME)</b></div><div><span>Benutzer</span><b>$(Hz $env:USERNAME)</b></div><div><span>Datum</span><b>$(Get-Date -Format 'dd.MM.yyyy HH:mm')</b></div></div>")
    if ($script:lastNf -eq 0) { $cuCol = '#3fa05a'; $cuTxt = 'Alles in Ordnung: Bei der Prüfung wurden keine Auffälligkeiten festgestellt.' }
    else {
        $cuCol = '#e08a00'; if ($script:sevMax -eq 2) { $cuCol = '#d0524f' }
        if ($script:lastNf -eq 1) { $cuTxt = 'Wir haben einen Punkt gefunden, den wir Ihnen zur Behebung empfehlen.' } else { $cuTxt = "Wir haben $($script:lastNf) Punkte gefunden, die wir Ihnen zur Behebung empfehlen." }
    }
    [void]$cuH.Append("<div class='banner' style='background:$cuCol'>$(Hz $cuTxt)</div>")
    [void]$cuH.Append('<h2>Was wir geprüft haben</h2><ul>')
    foreach ($cuC in @($script:checked)) { [void]$cuH.Append("<li>$(Hz $cuC)</li>") }
    [void]$cuH.Append('</ul>')
    if ($script:finds.Count) {
        [void]$cuH.Append('<h2>Was uns aufgefallen ist</h2>')
        $cuOrd = @{ 'HOCH' = 0; 'MITTEL' = 1; 'NIEDRIG' = 2 }
        $cuNm = @{ 'HOCH' = 'Dringend'; 'MITTEL' = 'Wichtig'; 'NIEDRIG' = 'Hinweis' }; $cuPc = @{ 'HOCH' = '#d0524f'; 'MITTEL' = '#e08a00'; 'NIEDRIG' = '#4a7fb5' }
        foreach ($cuF in @($script:finds | Sort-Object { $cuOrd[$_.L] })) {
            $cuRec = ''; if ($cuF.R) { $cuRec = "<p><span class='lbl'>Unsere Empfehlung</span><br>$(Hz $cuF.R)</p>" }
            [void]$cuH.Append("<div class='item'><span class='pill' style='background:$($cuPc[$cuF.L])'>$($cuNm[$cuF.L])</span><p><span class='lbl'>Bereich: $(Hz $cuF.Sec)</span><br>$(Hz $cuF.T)</p>$cuRec</div>")
        }
    }
    [void]$cuH.Append('<h2>Wie geht es weiter?</h2><div class=''next''>')
    if ($script:lastNf -eq 0) { [void]$cuH.Append("Es ist nichts zu tun. Bei Fragen oder Problemen erreichen Sie uns jederzeit:<br>") }
    else { [void]$cuH.Append("Gerne kümmern wir uns um die genannten Punkte. Sprechen Sie uns einfach an, wir vereinbaren einen Termin oder lösen es per Fernwartung:<br>") }
    [void]$cuH.Append("Telefon $(Hz $telefon) &nbsp;|&nbsp; <a href='mailto:$mail'>$mail</a> &nbsp;|&nbsp; www.sippicom.com</div>")
    [void]$cuH.Append("<div class='foot'>$(Hz $cpy) | Sippicom IT-Solutions<br>Als PDF speichern: Datei im Browser öffnen, Strg+P drücken und &quot;Als PDF speichern&quot; wählen.<br>Technische Einzelheiten stehen im ausführlichen Diagnosebericht.</div></div></body></html>")
    $cuFile = $script:lastTxt -replace '\.txt$', '_Kundenbericht.html'
    try {
        [IO.File]::WriteAllText($cuFile, $cuH.ToString(), (New-Object Text.UTF8Encoding($true)))
        Start-Process $cuFile; Msg "Kundenbericht erstellt: $cuFile" $null
    } catch { [void](SipBox "Kundenbericht konnte nicht erstellt werden: $($_.Exception.Message)" 'Fehler') }
}

# ---------- Update-Hinweis ----------
# Liest die erste Zeile der Versionsdatei unter $updUrl; nur wenn sie eine neuere Version nennt, erscheint ein Hinweis (sonst bleibt alles still).
function UpdCheck {
    if (-not $updUrl) { return }
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $uqRq = [Net.HttpWebRequest]::Create($updUrl); $uqRq.Timeout = 2500; $uqRq.ReadWriteTimeout = 2500
        $uqRq.Proxy = [Net.WebRequest]::GetSystemWebProxy(); $uqRq.Proxy.Credentials = [Net.CredentialCache]::DefaultCredentials
        $uqRs = $uqRq.GetResponse(); $uqRd = New-Object IO.StreamReader($uqRs.GetResponseStream()); $uqLine = "$($uqRd.ReadLine())".Trim(); $uqRd.Close(); $uqRs.Close()
        if ($uqLine -match '^\d+(\.\d+){1,3}$' -and ([version]$uqLine) -gt ([version]$appVer)) {
            Msg "Neue Version $uqLine verfügbar (installiert: $appVer) - bitte aktuelle Fassung vom Support holen." $am
            $script:verLbl.Text = $script:verLbl.Text + "  |  Update verfügbar: $uqLine"
        }
    } catch {}
}
$updTm = New-Object Windows.Forms.Timer; $updTm.Interval = 1500
$updTm.Add_Tick({ $updTm.Stop(); UpdCheck })

# ---------- Datenschutzerklärung (Pflichtbestätigung beim Programmstart) ----------
# Der Dialog erscheint bei jedem Start. "Weiter" ist erst nach dem Setzen des Häkchens bedienbar; "Ablehnen" beendet das Programm.
# Die Bestätigung (Zeitpunkt) wird in den Bericht geschrieben ($script:privAt). Hinweis: Der Text ist ein Entwurf und sollte juristisch geprüft werden.
$script:privAt = ''
$privStand = '05.11.2026'
$privTexte = @(
    @('H', '1. Verantwortlicher'),
    @('T', "Sippicom IT-Solutions, Straubing`r`nTelefon $telefon  |  E-Mail $mail  |  www.sippicom.com"),
    @('H', '2. Zweck und Rechtsgrundlage'),
    @('T', 'Das Diagnosezentrum prüft Ihren Computer, um Störungen zu finden und zu beheben und um Ihnen einen Bericht darüber zu erstellen. Die Verarbeitung erfolgt zur Durchführung des Auftrags bzw. Supportvertrags (Art. 6 Abs. 1 lit. b DSGVO) und auf Grundlage Ihrer Einwilligung durch Setzen des Häkchens (Art. 6 Abs. 1 lit. a DSGVO). Ohne Einwilligung kann das Programm nicht genutzt werden.'),
    @('H', '3. Welche Daten verarbeitet werden'),
    @('T', "Je nach gewählter Prüfung werden ausgelesen: Computername, Benutzername und Domäne, Windows-Version, Hardware und Datenträger, installierte Programme und Updates, Sicherheitsstatus, Netzwerkdaten (IP-Adressen, DNS, Gateway, Proxy, WLAN-Name, VPN-Profile), Ereignisprotokolle, Zertifikate, Drucker, Konfiguration von Microsoft 365, Outlook und Teams sowie Zeitangaben. Optional geben Sie Kunde oder Ticket ein.`r`nBei den Sicherungen können vertrauliche Daten anfallen: WLAN-Profile (auf Wunsch mit Kennwort im Klartext), Browser-Favoriten und Kennwortdateien, Outlook-Profile, Netzlaufwerke. Ein Netzwerk-Mitschnitt kann Inhalte der Kommunikation enthalten."),
    @('H', '4. Speicherung und Weitergabe'),
    @('T', "Alle Ergebnisse, Sicherungen und Mitschnitte werden ausschließlich lokal auf diesem Computer unter C:\SippicomInstall gespeichert. Das Programm überträgt Berichte nicht selbstständig. Eine Weitergabe an uns erfolgt nur, wenn Sie den Bericht per E-Mail oder als ZIP versenden; vor dem Versand können Sie Computer-, Benutzer- und Domänennamen durch Platzhalter ersetzen lassen.`r`nNetzwerkzugriffe durch das Programm: Abfrage einer Versionsdatei (scripthost.ncscript.xyz, dabei wird Ihre IP-Adresse übermittelt), gewählte Webseiten-Tests und der Geschwindigkeitstest."),
    @('H', '5. Speicherdauer'),
    @('T', 'Die lokalen Dateien bleiben bis zur Löschung bestehen. Mit der Kachel "Altdaten löschen" (Reparatur, Sicherung) können Sie alte Berichte, Sicherungen und Mitschnitte entfernen. Bei uns werden übermittelte Berichte nur so lange aufbewahrt, wie es für die Bearbeitung des Auftrags erforderlich ist, oder soweit gesetzliche Aufbewahrungspflichten bestehen.'),
    @('H', '6. Ihre Rechte'),
    @('T', 'Sie haben das Recht auf Auskunft (Art. 15 DSGVO), Berichtigung (Art. 16), Löschung (Art. 17), Einschränkung der Verarbeitung (Art. 18), Datenübertragbarkeit (Art. 20) und Widerspruch (Art. 21). Eine erteilte Einwilligung können Sie jederzeit mit Wirkung für die Zukunft widerrufen. Außerdem haben Sie das Recht auf Beschwerde bei einer Datenschutz-Aufsichtsbehörde, in Bayern beim Bayerischen Landesamt für Datenschutzaufsicht (BayLDA). Wenden Sie sich zur Ausübung Ihrer Rechte an die oben genannte Adresse.'),
    @('H', '7. Freiwilligkeit'),
    @('T', 'Die Bereitstellung der Daten und die Einwilligung sind freiwillig. Ohne sie kann das Diagnosezentrum jedoch nicht verwendet werden; eine Diagnose oder Reparatur ist dann nur auf anderem Weg möglich.')
)
function AskPrivacy {
    $pvDlg = New-Object Windows.Forms.Form
    $pvDlg.FormBorderStyle = 'None'; $pvDlg.StartPosition = 'CenterParent'; $pvDlg.Size = New-Object Drawing.Size(680, 640)
    $pvDlg.BackColor = $sb; $pvDlg.ShowInTaskbar = $false; $pvDlg.TopMost = $true
    Rnd $pvDlg 14
    $pvDlg.Add_Paint({ param($s, $e)
            $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
            $g.FillRectangle((New-Object Drawing.SolidBrush($or)), 0, 0, 680, 4)
            $g.DrawImage($logoImg, 24, 20, 40, 40)
            DT $g 'Datenschutzerklärung' $fH $cTxt 76 18
            DT $g "Stand $privStand  |  Bitte vollständig lesen und bestätigen" $fS $mu 78 52
        })
    $pvDlg.Add_MouseDown({ [void][Sip.Win]::ReleaseCapture(); [void][Sip.Win]::SendMessage($pvDlg.Handle, 0xA1, 2, 0) })
    # Textbereich mit Bildlaufleiste (Absätze als einzelne Beschriftungen, damit das Aussehen zum Programm passt)
    $pvBox = New-Object Windows.Forms.Panel; $pvBox.SetBounds(26, 84, 628, 400); $pvBox.BackColor = $cOffBg; $pvBox.AutoScroll = $true; $pvDlg.Controls.Add($pvBox)
    $pvY = 12; $pvW = 580
    foreach ($pvT in $privTexte) {
        $pvFont = $fN; $pvCol = $tx; if ($pvT[0] -eq 'H') { $pvFont = $fB; $pvCol = $or; $pvY += 6 }
        $pvSz = [Windows.Forms.TextRenderer]::MeasureText($pvT[1], $pvFont, (New-Object Drawing.Size($pvW, 4000)), 'WordBreak')
        $pvL = New-Object Windows.Forms.Label; $pvL.AutoSize = $false; $pvL.Text = $pvT[1]; $pvL.Font = $pvFont; $pvL.ForeColor = $pvCol; $pvL.BackColor = $cOffBg
        $pvL.SetBounds(14, $pvY, $pvW, ([int]$pvSz.Height + 6)); $pvBox.Controls.Add($pvL)
        $pvY += [int]$pvSz.Height + 8
    }
    $pvEnd = New-Object Windows.Forms.Label; $pvEnd.AutoSize = $false; $pvEnd.SetBounds(14, $pvY, 10, 10); $pvEnd.BackColor = $cOffBg; $pvBox.Controls.Add($pvEnd)
    $pvChk = New-Object Windows.Forms.CheckBox; $pvChk.SetBounds(30, 498, 620, 44); $pvChk.BackColor = $sb; $pvChk.ForeColor = $cTxt; $pvChk.Font = $fN; $pvChk.Cursor = 'Hand'
    $pvChk.Text = 'Ich habe die Datenschutzerklärung gelesen und willige in die beschriebene Verarbeitung meiner Daten ein.'
    $pvDlg.Controls.Add($pvChk)
    $pvOk = New-Object Windows.Forms.Button; $pvOk.Text = 'Weiter'; $pvOk.SetBounds(434, 560, 110, 40); $pvOk.FlatStyle = 'Flat'; $pvOk.FlatAppearance.BorderSize = 0
    $pvOk.Font = $fB; $pvOk.DialogResult = 'OK'; $pvOk.Enabled = $false; $pvOk.BackColor = $cOffBg; $pvOk.ForeColor = $mu; Rnd $pvOk 10
    $pvNo = New-Object Windows.Forms.Button; $pvNo.Text = 'Ablehnen'; $pvNo.SetBounds(554, 560, 100, 40); $pvNo.FlatStyle = 'Flat'; $pvNo.FlatAppearance.BorderColor = $cOffBd
    $pvNo.BackColor = $cOffBg; $pvNo.ForeColor = $cOffFg; $pvNo.Font = $fN; $pvNo.Cursor = 'Hand'; $pvNo.DialogResult = 'Cancel'; Rnd $pvNo 10
    $pvNo.Add_MouseEnter({ param($s, $e) $s.BackColor = $cOffHv }); $pvNo.Add_MouseLeave({ param($s, $e) $s.BackColor = $cOffBg })
    # Weiter ist nur mit gesetztem Häkchen bedienbar (sonst ausgegraut)
    $pvChk.Add_CheckedChanged({
            if ($pvChk.Checked) { $pvOk.Enabled = $true; $pvOk.BackColor = $or; $pvOk.ForeColor = $cWhite; $pvOk.Cursor = 'Hand' }
            else { $pvOk.Enabled = $false; $pvOk.BackColor = $cOffBg; $pvOk.ForeColor = $mu; $pvOk.Cursor = 'Default' }
        })
    $pvOk.Add_MouseEnter({ param($s, $e) if ($s.Enabled) { $s.BackColor = $orH } }); $pvOk.Add_MouseLeave({ param($s, $e) if ($s.Enabled) { $s.BackColor = $or } })
    $pvDlg.Controls.Add($pvOk); $pvDlg.Controls.Add($pvNo); $pvDlg.CancelButton = $pvNo
    $pvR = $pvDlg.ShowDialog($form); $pvAcc = ($pvR -eq 'OK' -and $pvChk.Checked); $pvDlg.Dispose()
    if ($pvAcc) { $script:privAt = Get-Date -Format 'dd.MM.yyyy HH:mm' }
    return $pvAcc
}

# Beim Programmstart zuerst die Datenschutzerklärung bestätigen lassen, danach nach Kunde bzw. Ticket fragen (sobald das Fenster sichtbar ist); die Eingabe steht danach oben in der Titelleiste
$tkb.Add_TextChanged({ $tbar.Invalidate() })
$form.Add_Shown({
        if (-not (AskPrivacy)) { $form.Close(); return }
        $updTm.Start()
        AskCustomer; $tbar.Invalidate()
    })

[Windows.Forms.Application]::Run($form)

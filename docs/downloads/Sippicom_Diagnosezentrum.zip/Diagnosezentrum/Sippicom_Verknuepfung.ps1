# Sippicom IT-Solutions - Diagnosezentrum: legt die Desktop-Verknüpfung an (mit "Als Administrator ausführen")
# Copyright (c) 2026 Nick Truschin. Alle Rechte vorbehalten.
# Wird von Sippicom_Diagnosezentrum.bat aufgerufen. Fehler hier verhindern den Programmstart nie.
param([string]$Bat, [switch]$Remove)
$ErrorActionPreference = 'Stop'
# Mit -Remove: Verknüpfung vom Desktop löschen (wird von der bat nach dem Schließen des Programms aufgerufen)
if ($Remove) {
    try {
        foreach ($d in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonDesktopDirectory'))) {
            $l = Join-Path $d 'Sippicom Diagnosezentrum.lnk'
            if (Test-Path $l) { Remove-Item $l -Force }
        }
    } catch { }
    return
}
try {
    Add-Type -AssemblyName System.Drawing
    $dir = Split-Path -Parent $Bat
    $icoDir = 'C:\SippicomInstall'
    $ico = Join-Path $icoDir 'Sippicom_Diagnosezentrum.ico'

    # Symbol: das vom Programm erzeugte verwenden, sonst aus assets\B5a.jpg ein quadratisches Symbol bauen
    if (-not (Test-Path $ico)) {
        $src = Join-Path $dir 'assets\B5a.jpg'
        if (Test-Path $src) {
            if (-not (Test-Path $icoDir)) { New-Item -ItemType Directory -Path $icoDir -Force | Out-Null }
            $img = [Drawing.Image]::FromFile($src)
            $side = [Math]::Min($img.Width, $img.Height)
            $bmp = New-Object Drawing.Bitmap 256, 256
            $g = [Drawing.Graphics]::FromImage($bmp)
            $g.InterpolationMode = 'HighQualityBicubic'
            $g.DrawImage($img, (New-Object Drawing.Rectangle 0, 0, 256, 256),
                [int](($img.Width - $side) / 2), [int](($img.Height - $side) / 2), $side, $side, [Drawing.GraphicsUnit]::Pixel)
            $g.Dispose(); $img.Dispose()
            $ms = New-Object IO.MemoryStream
            $bmp.Save($ms, [Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
            $png = $ms.ToArray(); $ms.Dispose()
            $fs = [IO.File]::Create($ico)
            $bw = New-Object IO.BinaryWriter $fs
            $bw.Write([uint16]0); $bw.Write([uint16]1); $bw.Write([uint16]1)
            $bw.Write([byte]0); $bw.Write([byte]0); $bw.Write([byte]0); $bw.Write([byte]0)
            $bw.Write([uint16]1); $bw.Write([uint16]32)
            $bw.Write([uint32]$png.Length); $bw.Write([uint32]22)
            $bw.Write($png)
            $bw.Close(); $fs.Close()
        }
    }

    $desk = [Environment]::GetFolderPath('Desktop')
    $lnk = Join-Path $desk 'Sippicom Diagnosezentrum.lnk'
    $sh = New-Object -ComObject WScript.Shell
    $s = $sh.CreateShortcut($lnk)
    $s.TargetPath = $Bat
    $s.Arguments = 'run'
    $s.WorkingDirectory = $dir
    $s.WindowStyle = 7
    $s.Description = 'Sippicom Diagnosezentrum (Administrator)'
    if (Test-Path $ico) { $s.IconLocation = "$ico,0" }
    $s.Save()

    # "Als Administrator ausführen" setzen (Flag RunAsUser, Bit 0x20 im Byte 0x15 der .lnk-Datei)
    $b = [IO.File]::ReadAllBytes($lnk)
    $b[0x15] = $b[0x15] -bor 0x20
    [IO.File]::WriteAllBytes($lnk, $b)
} catch { }

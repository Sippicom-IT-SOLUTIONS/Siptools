# Copyright

Copyright (c) 2026 Nick Truschin. Alle Rechte vorbehalten.

Projekt: Sippicom Diagnosezentrum (Sippicom_Diagnosezentrum.ps1 und Sippicom_Diagnosezentrum.bat)

Dieses Werk und alle zugehörigen Dateien sind urheberrechtlich geschützt. Vervielfältigung, Weitergabe, Veröffentlichung und Änderung, auch auszugsweise, sind nur mit vorheriger ausdrücklicher schriftlicher Zustimmung des Urhebers gestattet.

Die Software wird ohne Gewähr bereitgestellt. Für Schäden, die durch die Nutzung entstehen, wird im gesetzlich zulässigen Umfang keine Haftung übernommen.
